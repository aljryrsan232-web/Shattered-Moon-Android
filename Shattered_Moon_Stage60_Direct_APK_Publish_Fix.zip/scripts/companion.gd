extends CharacterBody3D
const RIG_DRIVER = preload("res://scripts/rig_driver.gd")
const WEAPON_MOTION = preload("res://scripts/weapon_motion.gd")
## Rayan — optional ally controlled by proximity, using existing level geometry.
var hero: CharacterBody3D
var director: Node3D
var avatar: Node3D
var enabled: bool = false
var strike_timer: float = 0.5
var heal_timer: float = 16.0
var search_timer: float = 0.0
var current_target: Node3D
var anim_time: float = 0.0
var gait_phase: float = 0.0
# Stage 48: follower animation damping only, movement mechanics unchanged.
var visual_stride: float = 0.0
var rig_parts: Dictionary = {}
var attack_pose: float = 0.0
var sword_mount: Node3D

func setup(hero_body: CharacterBody3D, actor_scene: PackedScene, controller: Node3D) -> void:
    hero = hero_body
    director = controller
    collision_layer = 8
    collision_mask = 4
    var collider := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.43
    shape.height = 1.9
    collider.shape = shape
    collider.position.y = 0.98
    add_child(collider)
    avatar = actor_scene.instantiate() as Node3D
    add_child(avatar)
    rig_parts = RIG_DRIVER.get_parts(avatar)
    set_enabled(false)

func set_weapon_mount(mount: Node3D) -> void:
    sword_mount = mount

func set_enabled(value: bool) -> void:
    enabled = value
    visible = value
    set_physics_process(value)
    if value and hero != null:
        global_position = hero.global_position + Vector3(1.8,0,2.0)

func _physics_process(delta: float) -> void:
    if not enabled or not is_instance_valid(hero):
        return
    anim_time += delta
    strike_timer = maxf(0.0,strike_timer-delta)
    heal_timer = maxf(0.0,heal_timer-delta)
    search_timer -= delta
    var to_hero := hero.global_position-global_position
    to_hero.y = 0
    var distance := to_hero.length()
    if distance > 25.0:
        global_position = hero.global_position+Vector3(2.0,0,1.7)
        distance = 2.5
    var nearest: Node3D = null
    var nearby := 7.5
    if search_timer <= 0.0:
        current_target = null
        search_timer = 0.40
        # Stage 50: follow the player's lock-on when the enemy is already within
        # Rayan's normal detection range. Never chase or teleport farther.
        var locked_enemy: Node3D = null
        if is_instance_valid(director) and bool(director.get("focus_mode")):
            locked_enemy = director.get("focus_target") as Node3D
        if is_instance_valid(locked_enemy) and not bool(locked_enemy.get("dead")) and locked_enemy.is_in_group("shattered_moon_enemies"):
            if global_position.distance_to(locked_enemy.global_position) < nearby and locked_enemy.global_position.distance_to(hero.global_position) < 12.0:
                current_target = locked_enemy
        if current_target == null:
            for node in get_tree().get_nodes_in_group("shattered_moon_enemies"):
                if not is_instance_valid(node) or bool(node.get("dead")):
                    continue
                var d: float = global_position.distance_to(node.global_position)
                if d < nearby and node.global_position.distance_to(hero.global_position) < 12.0:
                    nearby = d
                    current_target = node
    if is_instance_valid(current_target) and not bool(current_target.get("dead")):
        nearest = current_target
    var goal := hero.global_position+Vector3(1.5,0,1.6)
    if nearest != null:
        goal = nearest.global_position
    var offset := goal-global_position
    offset.y = 0
    var target_distance := offset.length()
    velocity = offset.normalized()* (4.9 if nearest == null else 5.2) if target_distance > (1.65 if nearest != null else 1.9) else Vector3.ZERO
    var last_position: Vector3 = global_position
    move_and_slide()
    var traveled := global_position.distance_to(last_position)
    var ground_speed := traveled/maxf(delta,0.001)
    var moving := ground_speed > 0.14
    if moving:
        gait_phase = fposmod(gait_phase+traveled*1.46,TAU)
    var movement_blend := clampf(ground_speed/5.0,0.0,1.0) if moving else 0.0
    var stride_rate := 11.0 if movement_blend > visual_stride else 15.0
    visual_stride = lerpf(visual_stride,movement_blend,
        1.0-exp(-maxf(delta,0.0)*stride_rate))
    avatar.position.y = sin(gait_phase)*.024*visual_stride+sin(anim_time*2.0)*.010*(1.0-visual_stride)
    attack_pose = maxf(0.0,attack_pose-delta)
    # Stage 49: while in striking range, Rayan turns toward the engaged creature
    # even if his feet have stopped. This rotates only his *avatar* and equipped
    # sword; pathfinding, hit range, enemy selection and damage remain unchanged.
    var combat_facing: bool = nearest != null and target_distance < 4.5
    var desired_yaw: float = avatar.rotation.y
    if combat_facing:
        var towards_enemy: Vector3 = nearest.global_position - global_position
        towards_enemy.y = 0.0
        if towards_enemy.length_squared() > 0.001:
            desired_yaw = atan2(towards_enemy.x,towards_enemy.z)
    elif moving:
        desired_yaw = atan2(velocity.x,velocity.z)
    var turn_lean: float = sin(desired_yaw-avatar.rotation.y)*(0.65 if combat_facing else visual_stride)
    RIG_DRIVER.animate(rig_parts,gait_phase,visual_stride,attack_pose,delta,false,0.0,0.0,1,0.0,turn_lean)
    if is_instance_valid(sword_mount):
        WEAPON_MOTION.animate(sword_mount,gait_phase,
            float(rig_parts.get("walk_blend",movement_blend)),attack_pose,delta)
    if combat_facing or moving:
        avatar.rotation.y = lerp_angle(avatar.rotation.y,desired_yaw,
            minf(delta*(10.0 if combat_facing else 8.0),1.0))
    if nearest != null and target_distance < 2.85 and strike_timer <= 0.0:
        nearest.call("take_hit",11.0+float(director.get("level"))*1.7,global_position)
        director.call("_companion_strike")
        attack_pose = 0.42
        strike_timer = 2.15
    if heal_timer <= 0.0 and float(director.get("health")) < float(director.get("max_health"))*.43:
        director.call("_companion_heal",22.0)
        heal_timer = 20.0
