extends Control
## Stage 15: simple tactical guide, without textures or heavy map rendering.
## World coordinates are kept stable: east = x+, south = z+.
var director: Node3D
const MIN_X: float = -48.0
const MAX_X: float = 302.0
const MIN_Z: float = -47.0
const MAX_Z: float = 47.0

func _point(pos: Vector3) -> Vector2:
    var usable := size-Vector2(14.0,14.0)
    return Vector2(7.0+clampf((pos.x-MIN_X)/(MAX_X-MIN_X),0.0,1.0)*usable.x,
        7.0+clampf((pos.z-MIN_Z)/(MAX_Z-MIN_Z),0.0,1.0)*usable.y)

func _draw() -> void:
    if not is_instance_valid(director):
        return
    var hero: Node3D = director.get("player") as Node3D
    if not is_instance_valid(hero):
        return
    draw_rect(Rect2(Vector2.ZERO,size),Color(.055,.115,.15,.94))
    # Three distinct navigable regions and a visible main road.
    draw_rect(Rect2(_point(Vector3(-48,0,-47)),_point(Vector3(32,0,47))-_point(Vector3(-48,0,-47))),Color(.14,.26,.21,.9))
    draw_rect(Rect2(_point(Vector3(32,0,-47)),_point(Vector3(138,0,47))-_point(Vector3(32,0,-47))),Color(.11,.27,.19,.9))
    draw_rect(Rect2(_point(Vector3(138,0,-47)),_point(Vector3(206,0,47))-_point(Vector3(138,0,-47))),Color(.23,.23,.28,.9))
    draw_rect(Rect2(_point(Vector3(206,0,-43)),_point(Vector3(302,0,43))-_point(Vector3(206,0,-43))),Color(.22,.24,.35,.95))
    draw_line(_point(Vector3(-42,0,0)),_point(Vector3(301,0,0)),Color(.70,.60,.39,.5),2.0,true)
    draw_line(_point(Vector3(95,0,0)),_point(Vector3(96,0,30)),Color(.70,.60,.39,.4),1.7,true)
    draw_rect(Rect2(Vector2.ZERO,size),Color(.42,.63,.68,.8),false,1.0)
    # Stage 16: uncollected moon memories, shown as cyan diamonds for exploration.
    var memory_locations: Array[Vector3] = director.get("moon_memory_positions")
    var memory_mask: int = int(director.get("moon_memory_mask"))
    for i in range(memory_locations.size()):
        if (memory_mask & (1 << i)) == 0:
            var pos := _point(memory_locations[i])
            draw_colored_polygon(PackedVector2Array([
                pos+Vector2(0,-4.0),pos+Vector2(4,0),
                pos+Vector2(0,4),pos+Vector2(-4,0)]),Color(.45,.82,1.0))
    # Stage 17: moon rift trial location after campaign unlock.
    if int(director.get("quest_stage")) >= 5 and not bool(director.get("rift_rewarded")):
        var rift_at := _point(director.get("rift_center"))
        draw_arc(rift_at,5.8,0.0,TAU,20,Color(.35,.73,1.0),2.0,true)
        draw_circle(rift_at,2.5,Color(.71,.92,1.0))
    # Stage 18: unactivated valley glyphs and the Echo Warden altar.
    if int(director.get("quest_stage")) >= 5 and not bool(director.get("echo_rewarded")):
        var positions: Array[Vector3] = director.get("echo_glyph_positions")
        var activated: int = int(director.get("echo_glyph_mask"))
        for i in range(positions.size()):
            if (activated & (1 << i)) == 0:
                var dot := _point(positions[i])
                draw_colored_polygon(PackedVector2Array([dot+Vector2(0,-4),dot+Vector2(4,0),dot+Vector2(0,4),dot+Vector2(-4,0)]),Color(.78,.53,1.0))
        var altar_at := _point(director.get("echo_altar_pos"))
        draw_arc(altar_at,5.7,0.0,TAU,24,Color(.78,.54,1.0),1.8,true)
    # Beacons and safe village are landmarks; enemies only appear within scouting range.
    for anchor in director.get("beacon_anchors"):
        draw_circle(_point(anchor),2.8,Color(.30,.80,1.0))
    draw_circle(_point(Vector3(0,0,18)),3.6,Color(.42,.93,.64))
    for enemy in director.get("enemies"):
        if not is_instance_valid(enemy) or bool(enemy.get("dead")):
            continue
        if hero.global_position.distance_to(enemy.global_position) < 32.0:
            draw_circle(_point(enemy.global_position),2.5,Color(1.0,.34,.30))
    var objective: Vector3 = director.call("_navigation_goal")
    var player_at := _point(hero.global_position)
    var goal_at := _point(objective)
    draw_line(player_at,goal_at,Color(.97,.82,.34,.83),1.3,true)
    draw_circle(goal_at,5.8,Color(.98,.79,.25,.24))
    draw_arc(goal_at,4.9,0.0,TAU,20,Color(1.0,.86,.37),1.6,true)
    # Player heading triangle: rotate with actual movement direction.
    var face: Vector3 = director.get("hero_forward")
    var heading := Vector2(face.x,face.z).normalized()
    if heading.length_squared() < .001:
        heading = Vector2(0.0,-1.0)
    var lateral := Vector2(-heading.y,heading.x)
    var triangle := PackedVector2Array([player_at+heading*6.0,
        player_at-heading*4.0+lateral*3.9,
        player_at-heading*4.0-lateral*3.9])
    draw_colored_polygon(triangle,Color(.95,.98,1.0))
