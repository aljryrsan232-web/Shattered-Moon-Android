extends RefCounted
## Stage 32 visual-only village and ruins kit; no collision or gameplay triggers.
## Procedural props use original tileable materials and simple geometry for Compatibility renderer.

const WOOD = preload("res://assets/textures/retro_wood_planks_stage32.png")
const STONE = preload("res://assets/textures/retro_stone_blocks_stage32.png")
const WOOD_NORMAL = preload("res://assets/textures/retro_wood_normal_stage34.png")
const STONE_NORMAL = preload("res://assets/textures/retro_stone_normal_stage34.png")

static func _material(texture: Texture2D, tint: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_texture = texture
    material.albedo_color = tint
    material.roughness = .89
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    material.texture_repeat = BaseMaterial3D.TEXTURE_REPEAT_ENABLED
    if not OS.has_feature("mobile"):
        material.normal_enabled = true
        material.normal_texture = WOOD_NORMAL if texture == WOOD else STONE_NORMAL
        material.normal_scale = .30 if texture == WOOD else .43
    return material

static func _box(parent: Node3D, label: String, at: Vector3, dimensions: Vector3, material: Material) -> MeshInstance3D:
    var piece := MeshInstance3D.new()
    piece.name = label
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    piece.mesh = mesh
    piece.position = at
    piece.material_override = material
    parent.add_child(piece)
    return piece

static func make_supply_crate(parent: Node3D, at: Vector3, yaw: float, factor: float = 1.0) -> Node3D:
    var crate := Node3D.new()
    crate.name = "Stage32_WoodenSupplyCrate"
    crate.position = at
    crate.rotation.y = yaw
    crate.scale = Vector3.ONE * factor
    parent.add_child(crate)
    var wood := _material(WOOD, Color(.86,.75,.64))
    var iron := StandardMaterial3D.new()
    iron.albedo_color = Color(.30,.32,.33)
    iron.metallic = .25
    iron.roughness = .67
    _box(crate, "PlankedBox", Vector3(0,.56,0), Vector3(1.18,1.06,1.02), wood)
    for x in [-.52,.52]:
        _box(crate,"MetalCorner",Vector3(x,.57,.0),Vector3(.08,1.11,1.07),iron)
    for z in [-.47,.47]:
        _box(crate,"MetalBand",Vector3(0,.58,z),Vector3(1.24,.11,.08),iron)
    _box(crate,"TopRim",Vector3(0,1.11,0),Vector3(1.29,.13,1.15),wood)
    return crate

static func make_carved_waymarker(parent: Node3D, at: Vector3, yaw: float, factor: float = 1.0, luminous: bool = false) -> Node3D:
    var marker := Node3D.new()
    marker.name = "Stage32_CarvedStoneWaymarker"
    marker.position = at
    marker.rotation.y = yaw
    marker.scale = Vector3.ONE * factor
    parent.add_child(marker)
    var stone := _material(STONE, Color(.88,.87,.84))
    _box(marker,"MasonryBase",Vector3(0,.20,0),Vector3(1.48,.40,1.17),stone)
    _box(marker,"StandingCarvedPillar",Vector3(0,1.37,0),Vector3(.83,1.94,.66),stone)
    _box(marker,"BrokenCapstone",Vector3(0,2.39,0),Vector3(1.09,.24,.84),stone)
    var trim := StandardMaterial3D.new()
    trim.albedo_color = Color(.55,.47,.28) if luminous else Color(.45,.43,.40)
    trim.roughness = .79
    _box(marker,"InsetEngraving",Vector3(0,1.55,-.345),Vector3(.37,.14,.025),trim)
    if luminous:
        var emblem := MeshInstance3D.new()
        var gem := SphereMesh.new()
        gem.radius = .12
        gem.height = .24
        gem.radial_segments = 8
        gem.rings = 4
        emblem.mesh = gem
        emblem.position = Vector3(0,1.97,-.36)
        var glow := StandardMaterial3D.new()
        glow.albedo_color = Color(.49,.82,1.)
        glow.emission_enabled = true
        glow.emission = Color(.17,.48,.88)
        glow.emission_energy_multiplier = 1.2
        emblem.material_override = glow
        marker.add_child(emblem)
    return marker
