extends RefCounted
## Stage 38: adjusted headwear for clear facial visibility; still shares the actor GPU rig.
## Imported glTF COLOR.a is a region tag; shader writes no ALPHA and stays opaque.
## Does not alter animation timing, combat hitboxes, navigation or save data.
const MOTION_SHADER = preload("res://shaders/hero_motion.gdshader")
const HERO = preload("res://assets/stage38/hero_retro_armor_raised.glb")
const RAYAN = preload("res://assets/stage38/rayan_retro_armor_raised.glb")
const LAURA = preload("res://assets/stage38/laura_retro_jewelry_raised.glb")
const SMITH = preload("res://assets/stage37/smith_retro_apron_rigged.glb")
const MERCHANT = preload("res://assets/stage37/merchant_retro_kit_rigged.glb")
const BRIAR = preload("res://assets/stage36/briar_retro_details.glb")
const WISP = preload("res://assets/stage36/wisp_retro_details.glb")
const SENTINEL = preload("res://assets/stage36/sentinel_retro_details.glb")

static func _body_motion_material(actor: Node3D) -> ShaderMaterial:
    for mesh_node in actor.find_children("*", "MeshInstance3D", true, false):
        var mesh := mesh_node as MeshInstance3D
        if mesh == null:
            continue
        var surface_mat := mesh.get_surface_override_material(0)
        if surface_mat is ShaderMaterial:
            var shared := surface_mat as ShaderMaterial
            if shared.shader == MOTION_SHADER:
                return shared
    return null

static func attach(actor: Node3D, role: String) -> Node3D:
    if actor == null:
        return null
    var resource: PackedScene
    match role:
        "hero": resource = HERO
        "rayan": resource = RAYAN
        "laura": resource = LAURA
        "smith": resource = SMITH
        "merchant": resource = MERCHANT
        "bramble", "shade_hunter": resource = BRIAR
        "wisp", "frost_wisp": resource = WISP
        "guardian", "rift_guardian", "echo_warden": resource = SENTINEL
        _: return null
    # Resolve the animated actor's material *before* adding any new meshes.
    var motion_mat := _body_motion_material(actor) if role in ["hero","rayan","laura","smith","merchant"] else null
    var accessory := resource.instantiate() as Node3D
    accessory.name = "Stage37_" + role + "_Kit"
    actor.add_child(accessory)
    if motion_mat != null:
        for mesh_node in accessory.find_children("*", "MeshInstance3D", true, false):
            var mesh := mesh_node as MeshInstance3D
            if mesh != null and mesh.mesh != null and mesh.mesh.get_surface_count() > 0:
                mesh.set_surface_override_material(0, motion_mat)
    return accessory
