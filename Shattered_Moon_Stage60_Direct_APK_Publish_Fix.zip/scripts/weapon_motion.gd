extends RefCounted
## Stage 47: weapon follows the exact smoothed gait/guard/sprint state of the rig.
## Based on the Stage 40 right-hand trajectory; still an approximate non-skeletal mount.
## Non-skeletal approximation: reproduces shoulder/elbow pitches used by hero_motion.gdshader.
## Purely cosmetic. Damage, parry windows and hit detection are unchanged.

# The Stage 39 body mesh was measured at the right-hand grip (region tag 155).
const REST_HAND: Vector3 = Vector3(0.74, 1.77, 0.31)
const SHOULDER: Vector3 = Vector3(0.68, 2.70, 0.01)
const ELBOW: Vector3 = Vector3(0.86, 2.24, 0.09)
const STRIKE_DURATION: float = 0.42

static func _pitch_about(point: Vector3, center: Vector3, amount: float) -> Vector3:
    return center + Basis(Vector3.RIGHT, amount) * (point - center)

static func _right_hand(phase: float, movement: float, strike_arc: float,
        guard: float, run_blend: float) -> Vector3:
    var walk := clampf(movement, 0.0, 1.0)
    var run := clampf(run_blend, 0.0, 1.0) * walk
    var shoulder_pitch := (-0.18 - 0.10 * run) * walk * sin(phase)
    shoulder_pitch += -0.55 * strike_arc - 0.85 * guard
    var hand := _pitch_about(REST_HAND, SHOULDER, shoulder_pitch)
    var elbow_bend := 0.09 + 0.26 * run * walk + 0.39 * strike_arc
    hand = _pitch_about(hand, ELBOW, -elbow_bend)
    # Matches the upper-body guard lowering in the source GPU shader.
    hand.y -= 0.045 * guard
    return hand

static func animate(mount: Node3D, gait_phase: float, movement: float,
        attack_remaining: float, delta: float, combo: int = 1,
        guard_strength: float = 0.0, run_blend: float = 0.0) -> void:
    if not is_instance_valid(mount):
        return
    var base_pos: Vector3 = mount.get_meta("weapon_rest_position", mount.position)
    var base_rot: Vector3 = mount.get_meta("weapon_rest_rotation", mount.rotation)
    var grip_offset: Vector3 = mount.get_meta("weapon_grip_offset", Vector3(0.0, 0.216, 0.0))
    var progress := 0.0
    var draw := 0.0
    if attack_remaining > 0.0:
        # One duration for all combo hits; no jump when remaining time crosses .42 s.
        progress = 1.0 - clampf(attack_remaining / STRIKE_DURATION, 0.0, 1.0)
        # Unsheathe early and move back toward the sheath after the follow-through.
        draw = smoothstep(0.0, 0.17, progress) * (1.0 - smoothstep(0.81, 1.0, progress))
    var strike_arc := sin(PI * progress) if attack_remaining > 0.0 else 0.0
    var guard := clampf(guard_strength, 0.0, 1.0)
    var want_drawn := clampf(maxf(draw, guard), 0.0, 1.0)
    var previous_draw := float(mount.get_meta("weapon_draw_blend",0.0))
    # Hold a short-lived transition state so successive combo hits do not snap
    # the blade instantly between sheath and hand. State is visual-only.
    var draw_speed := 24.0 if want_drawn > previous_draw else 16.0
    var draw_lerp := 1.0-exp(-maxf(delta,0.0)*draw_speed)
    var drawn := lerpf(previous_draw,want_drawn,draw_lerp)
    mount.set_meta("weapon_draw_blend",drawn)
    var side := -1.0 if combo == 2 else 1.0
    var walk := clampf(movement, 0.0, 1.0)
    var stride := sin(gait_phase) * walk
    var hand := _right_hand(gait_phase, walk, strike_arc, guard, run_blend)
    # The imported sword points along local +Y; its hand grip is .30 units above
    # the model origin, scaled by the existing .72 child scale at mount creation.
    var weapon_rot := Vector3(
        0.28 - 0.76 * strike_arc + 0.20 * guard + 0.035 * stride,
        -0.12 + 0.48 * strike_arc * side,
        0.22 + 0.78 * strike_arc * side - 0.31 * guard)
    var weapon_basis := Basis.from_euler(weapon_rot)
    var weapon_pos := hand - weapon_basis * grip_offset
    var goal_pos := base_pos.lerp(weapon_pos, drawn)
    var goal_rot := Vector3(
        lerp_angle(base_rot.x, weapon_rot.x, drawn),
        lerp_angle(base_rot.y, weapon_rot.y, drawn),
        lerp_angle(base_rot.z, weapon_rot.z, drawn))
    var blend := 1.0 - exp(-maxf(delta, 0.0) * 20.0)
    mount.position = mount.position.lerp(goal_pos, blend)
    mount.rotation = Vector3(
        lerp_angle(mount.rotation.x, goal_rot.x, blend),
        lerp_angle(mount.rotation.y, goal_rot.y, blend),
        lerp_angle(mount.rotation.z, goal_rot.z, blend))
