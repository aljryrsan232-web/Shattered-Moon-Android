extends Node3D
## Moon Rebuild — Stage 47: synchronized combat animation transitions and bounded cloak clearance.
## Godot 4 source only: runtime/export testing remains required.
## Distinct from the legacy WebGL RPG: village, wildwood, cavern, quest, combat, autosave.

const WALK_SPEED: float = 5.8
const SPRINT_SPEED: float = 8.2
const MOVEMENT_ACCEL: float = 24.0
const MOVEMENT_BRAKE: float = 34.0
const STRIDE_RADIANS_PER_METER: float = 1.46
const ENEMY_SCRIPT = preload("res://scripts/enemy.gd")
const HOUSE_TYPES = [
    preload("res://assets/house_0.glb"), preload("res://assets/house_1.glb"),
    preload("res://assets/house_2.glb"), preload("res://assets/house_3.glb")
]
const OAK = preload("res://assets/oak.glb")
const PINE = preload("res://assets/pine.glb")
const HERO = preload("res://assets/hero_human.glb")
const GROUND = preload("res://assets/ground.glb")
const BOARD = preload("res://assets/notice_board.glb")
const FOUNTAIN = preload("res://assets/fountain.glb")
const MARKET = preload("res://assets/market.glb")
const BRIAR = preload("res://assets/briar_stalker.glb")
const WISP = preload("res://assets/mist_lantern.glb")
const SENTINEL = preload("res://assets/basalt_sentinel.glb")
const ARCH = preload("res://assets/cave_arch.glb")
const RUINS = preload("res://assets/ruin_gate.glb")
const SHRINE = preload("res://assets/lunar_crystal_dais.glb")
const WAYSTONE = preload("res://assets/moon_waystone.glb")
const RAYAN = preload("res://assets/rayan_human.glb")
const MOONFALL = preload("res://assets/moonfall_bridge.glb")
const WATCH_TOWER = preload("res://assets/moonwatch_tower.glb")
const FOREST_SANCTUARY = preload("res://assets/forest_sanctuary.glb")
const ROAD_LANTERN = preload("res://assets/road_lantern.glb")
const FERN = preload("res://assets/fern_cluster.glb")
const RIVER_SHADER = preload("res://shaders/river.gdshader")
const COMPANION_SCRIPT = preload("res://scripts/companion.gd")
const RIG_DRIVER = preload("res://scripts/rig_driver.gd")
const WEAPON_MOTION = preload("res://scripts/weapon_motion.gd")
const AMBIENT_ACTOR = preload("res://scripts/ambient_actor.gd")
const CLOTH_WIND = preload("res://shaders/cloth_wind.gdshader")
const RETRO_DETAILS = preload("res://scripts/retro_detail_props.gd")
const STAGE34_FOLIAGE = preload("res://scripts/stage34_foliage.gd")
const STAGE35_POLISH = preload("res://scripts/stage35_polish.gd")
const STAGE36_CHARACTER_KIT = preload("res://scripts/stage37_character_kit.gd")
const STAGE33_LANDMARKS = preload("res://scripts/stage33_landmarks.gd")
const MINIMAP_SCRIPT = preload("res://scripts/minimap.gd")
const PAUSE_INPUT_SCRIPT = preload("res://scripts/pause_input.gd")
const ECHO_CHIME = preload("res://assets/sfx/echo_glyph_chime.wav")
const ECHO_VICTORY = preload("res://assets/sfx/echo_warden_victory.wav")
const PARRY_CHIME = preload("res://assets/sfx/moon_parry_chime.wav")
const STEEL_IMPACT = preload("res://assets/sfx/moon_steel_impact.wav")
const ROCK = preload("res://assets/mossy_boulder.glb")
const SILVER_BIRCH = preload("res://assets/silver_birch.glb")
const MOONFORGE = preload("res://assets/moonforge_workshop.glb")
const GUILDHALL = preload("res://assets/moon_guildhall.glb")
const SMITH = preload("res://assets/village_smith_adult.glb")
const LAURA_ADULT = preload("res://assets/laura_adult.glb")
const MERCHANT_ADULT = preload("res://assets/merchant_adult.glb")
# Stage 25: original in-game 3D assets inspired by the user's retro fantasy screenshot.
const VILLAGE_HORSE = preload("res://assets/village_horse.glb")
# Stage 28: editable, original GLB sword meshes. Cosmetic only; combat remains unchanged.
const MOONSTEEL_SWORD = preload("res://assets/moonsteel_retro_sword.glb")
const RAYAN_SWORD = preload("res://assets/rayan_retro_sword.glb")
const VILLAGE_FENCE = preload("res://assets/village_fence.glb")
const VILLAGE_SIGN = preload("res://assets/village_signpost.glb")
const VILLAGE_BARREL = preload("res://assets/village_barrel.glb")
const RETRO_HERO_PORTRAIT = preload("res://assets/ui/hero_portrait.png")
const RETRO_JOYSTICK = preload("res://assets/ui/joystick_metal.png")
const RETRO_PUCK = preload("res://assets/ui/joystick_thumb.png")
const FORGE_PLAZA = preload("res://assets/workshop_plaza.glb")
const MOON_SEAL = preload("res://assets/moon_seal_obelisk.glb")
const MOON_ALTAR = preload("res://assets/moon_seal_altar.glb")
const MOON_SEAL_SHADER = preload("res://shaders/moon_seal.gdshader")
const STONE_NORMAL = preload("res://assets/textures/stone_normal.png")
const BASALT_NORMAL = preload("res://assets/textures/basalt_normal.png")
const DIRT_NORMAL = preload("res://assets/textures/dirt_normal.png")
const SAVE_PATH: String = "user://shattered_moon_rebuild_v2.json"
const SAVE_BACKUP_PATH: String = "user://shattered_moon_rebuild_v2.json.bak"
const SAVE_TEMP_PATH: String = "user://shattered_moon_rebuild_v2.json.tmp"
const GRASS_TEXTURE = preload("res://assets/textures/grass.png")
const DIRT_TEXTURE = preload("res://assets/textures/dirt.png")
const STONE_TEXTURE = preload("res://assets/textures/stone.png")
const BASALT_TEXTURE = preload("res://assets/textures/basalt.png")

var player: CharacterBody3D
var visual: Node3D
var hero_forward: Vector3 = Vector3.FORWARD
var hero_rig_parts: Dictionary = {}
var hero_attack_pose: float = 0.0
var hero_weapon_mount: Node3D
var hero_gait_phase: float = 0.0
# Stage 48: purely visual momentum; does not alter player velocity or combat.
var hero_visual_stride: float = 0.0
var hero_visual_turn: float = 0.0
var instanced_rock_fields: Array[MultiMeshInstance3D] = []
var dodge_time: float = 0.0
var dodge_invulnerable: float = 0.0
var dodge_direction: Vector3 = Vector3.ZERO
var hit_flash: float = 0.0
# Stage 19 defensive timing: short window and resource cost, not permanent invulnerability.
var parry_window: float = 0.0
var parry_cooldown: float = 0.0
var parry_success_flash: float = 0.0
var perfect_parries: int = 0
var camera_impact: float = 0.0
var camera_feedback_enabled: bool = true
var parry_audio: AudioStreamPlayer
var strike_audio: AudioStreamPlayer
var guard_label: Label
var swing_arc: MeshInstance3D
var beacons_mask: int = 0
var beacons_rewarded: bool = false
var beacon_anchors: Array[Vector3] = [Vector3(36,0,3),Vector3(112,0,11),Vector3(157,0,-22)]
var camera_rig: Node3D
var view_camera: Camera3D
var zones: Array[Node3D] = []
var enemies: Array[Node3D] = []
var board_position := Vector3(-7.0, 0.0, 10.0)
var shop_position := Vector3(8.5, 0.0, -12.0)
var shrine_position := Vector3(174.0, 0.0, 0.0)
var cam_yaw: float = 0.0
var cam_pitch: float = -0.28
var move_touch: int = -1
var cam_touch: int = -1
var move_origin := Vector2.ZERO
var touch_move := Vector2.ZERO
var clock: float = 0.0
var world_tick: float = 0.0
# Stage 41: optional F3 diagnostics and lightweight light culling (not part of save schema).
var stage41_debug_label: Label
var stage41_show_debug: bool = false
var stage41_active_lights: int = 0
var hud_tick: float = 0.0
var save_timer: float = 0.0
var attack_cooldown: float = 0.0
var combo_step: int = 0
var combo_expiry: float = 0.0
var target_ring: MeshInstance3D
var target_tick: float = 0.0
var target_mark: Node3D
# Stage 20: optional target focus with cycling and a mobile-friendly toggle.
var focus_mode: bool = false
var focus_target: Node3D
var focus_button: Button
var focus_next_button: Button
var focus_label: Label
var focus_hp_bar: ProgressBar
var focus_ring_material: StandardMaterial3D
var boss_hp_bar: ProgressBar
var boss_hp_label: Label
# Stage 50: separate visual-only warning for the boss's existing attack windup.
var boss_attack_label: Label
var boss_attack_bar: ProgressBar
var companion_focus_label: Label
var spell_cooldown: float = 0.0
var dodge_cooldown: float = 0.0
var is_sprinting: bool = false
var health: float = 100.0
var mana: float = 70.0
var stamina: float = 100.0
var max_health: float = 100.0
var gold: int = 40
var potions: int = 3
var exp_points: int = 0
var level: int = 1
var quest_stage: int = 0
var forest_defeated: int = 0
var cave_token: bool = false
var boss_defeated: bool = false
var total_defeated: int = 0
var message_timer: float = 0.0
var notification: String = ""
var hp_bar: ProgressBar
var mp_bar: ProgressBar
var stamina_bar: ProgressBar
var title_label: Label
var quest_label: Label
var message_label: Label
var joystick_puck: TextureRect
var scale_label: Label
var navigation_map: Control
var navigation_label: Label
var pause_root: Control
var pause_quality_label: Label
var pause_info_label: Label
var pause_settings_panel: PanelContainer
var journal_panel: PanelContainer
var journal_text: RichTextLabel
var journal_open: bool = false
var interaction_label: Label
# Stage 16: collectable side-quest; save-compatible with the previous stages.
var moon_memory_positions: Array[Vector3] = [
    Vector3(-37.0,0.0,6.0), Vector3(24.0,0.0,-5.0),
    Vector3(57.0,0.0,36.0), Vector3(91.0,0.0,-29.0),
    Vector3(127.0,0.0,9.0), Vector3(187.0,0.0,-23.0)
]
var moon_memory_names: Array[String] = [
    "عين الحراسة", "بوابة الشروق", "همس الصفصاف",
    "نجمة الغابة", "حدود الأطلال", "ظل الحارس"
]
var moon_memory_nodes: Array[Node3D] = []
var moon_memory_mask: int = 0
var moon_memory_rewarded: bool = false
var moon_memory_anim: float = 0.0
var mobile_resolution_scale: float = 0.82
var camera_distance: float = 8.75
var fps_sum: float = 0.0
var adaptive_timer: float = 0.0
var smooth_fps: float = 60.0
var adaptive_enabled: bool = true
var camera_ray: PhysicsRayQueryParameters3D
var camera_height: float = 4.4
var waystone_rest_timer: float = 0.0
var hero_breath_phase: float = 0.0
var travel_zone: int = 0
var checkpoint_position: Vector3 = Vector3(0,0,18)
var checkpoint_unlocked: int = 0
var checkpoint_rest_count: int = 0
var moon_lantern_step: int = 0
var moon_lantern_rewarded: bool = false
var moon_lantern_positions: Array[Vector3] = [Vector3(71.0,0.0,26.0),Vector3(120.0,0.0,-25.0),Vector3(190.0,0.0,20.0)]
var moon_lantern_lights: Array[OmniLight3D] = []
var sun_light: DirectionalLight3D
# Stage 21 atmospheric effects; visual-only and optional for older mobile devices.
var atmosphere_enabled: bool = true
var atmosphere_environment: Environment
var atmosphere_sky: ProceduralSkyMaterial
var moon_motes: MultiMeshInstance3D
var day_clock: float = 155.0
var lighting_timer: float = 0.0
var ground_material_cache: Dictionary = {}
var near_enemy_markers: Array[MeshInstance3D] = []
var rayan_spot: Vector3 = Vector3(6.5,0,18.0)
var rayan_npc: Node3D
var rayan_ally: CharacterBody3D
var companion_recruited: bool = false
var companion_active: bool = false
var companion_strikes: int = 0
var companion_quest_rewarded: bool = false
# Stage 7: GPU-instanced, nighttime-only fireflies. No per-insect physics nodes.
var firefly_fields: Array[MultiMeshInstance3D] = []
var firefly_visible: bool = false
var scenic_lights: Array[OmniLight3D] = []
var ambient_flicker_clock: float = 0.0
var fern_multimeshes: Array[MultiMeshInstance3D] = []
var sanctuary_center := Vector3(96,0,30)
var sanctuary_state: int = 0 # 0 undiscovered, 1 fight, 2 reward ready, 3 rewarded
var sanctuary_kills: int = 0
var sanctuary_rewarded: bool = false
# Moon-Seal Outpost (post-campaign, save-resumable without repeated rewards).
var moon_seal_mask: int = 0
var moon_seal_state: int = 0 # 0 find seals; 1 defend; 2 return for reward; 3 complete
var moon_seal_kills: int = 0
var moon_seal_rewarded: bool = false
var moon_seal_places: Array[Vector3] = [Vector3(59,0,-25),Vector3(102,0,-25),Vector3(120,0,28)]
var moon_seal_altar_pos: Vector3 = Vector3(130,0,31)
var moon_seal_glow: OmniLight3D
var birch_field: MultiMeshInstance3D
# Stage 11 forging uses existing gold and story progress, no separate inventory or heavy UI.
var smith_position: Vector3 = Vector3(-28.0,0.0,31.0)
var smith_level: int = 0
# Stage 17: optional post-story Moon Rift arena (progress is save-resumable).
var rift_center: Vector3 = Vector3(190.0,0.0,32.0)
var rift_state: int = 0 # 0 dormant, 1 wave active, 2 claim reward, 3 completed
var rift_wave: int = 0 # 1 or 2 = pairs, 3 = elite guardian
var rift_kills: int = 0
var rift_rewarded: bool = false
var rift_nodes: Array[Node3D] = []
var rift_marker: Node3D
var rift_animation: float = 0.0
# Combat ability: no extra assets or permanently spawned particle nodes.
var lunar_burst_cooldown: float = 0.0
var lunar_burst_label: Label
var forge_light: OmniLight3D

# Stage 18: separate exploration chapter; fields are saved alongside the old schema.
var echo_glyph_positions: Array[Vector3] = [
    Vector3(223,0,-24), Vector3(251,0,23), Vector3(278,0,-20)
]
var echo_glyph_names: Array[String] = ["صدى النجوم", "صدى الغابة", "صدى الحارس"]
var echo_glyph_mask: int = 0
var echo_state: int = 0 # 0 seek glyphs; 1 fight; 2 claim; 3 finished
var echo_wave: int = 0 # 1 = two elite creatures; 2 = Echo Warden
var echo_kills: int = 0
var echo_rewarded: bool = false
var echo_altar_pos: Vector3 = Vector3(291,0,8)
var echo_glyph_nodes: Array[Node3D] = []
var echo_altar: Node3D
var echo_fighters: Array[Node3D] = []
var echo_effect_clock: float = 0.0
var echo_sound: AudioStreamPlayer



# Stage 51: display-only references for responsive landscape touch layouts.
# These are not serialized; save format and gameplay state remain unchanged.
var stage51_stats_panel: PanelContainer
var stage51_portrait: TextureRect
var stage51_objective_panel: PanelContainer
var stage51_map_panel: PanelContainer
var stage51_map_heading: Label
var stage51_joystick: TextureRect
var stage51_action_grid: GridContainer
var stage51_menu_button: Button
var stage51_journal_button: Button
var stage51_interact_button: Button
var stage51_compact_layout: bool = false

func _ready() -> void:
    _bind_inputs()
    _environment()
    echo_sound = AudioStreamPlayer.new()
    echo_sound.name = "Echoes_Sound_FX"
    echo_sound.volume_db = -12.0
    add_child(echo_sound)
    parry_audio = AudioStreamPlayer.new()
    parry_audio.name = "Perfect_Parry_FX"
    parry_audio.stream = PARRY_CHIME
    parry_audio.volume_db = -12.0
    add_child(parry_audio)
    strike_audio = AudioStreamPlayer.new()
    strike_audio.name = "Melee_Impact_FX"
    strike_audio.stream = STEEL_IMPACT
    strike_audio.volume_db = -19.0
    add_child(strike_audio)
    _build_village()
    _build_moonforge_village()
    _build_wildwood()
    _build_cavern()
    _build_echo_valley()
    # Stage 34: low-cost regional details; keep lanes/quest entrances unobstructed.
    STAGE34_FOLIAGE.decorate(zones[1],"Wildwood",Rect2(44,-38,81,76),180,34011,Color(.36,.64,.35))
    STAGE34_FOLIAGE.decorate(zones[2],"Hollow Ruins",Rect2(146,-28,56,56),90,34012,Color(.42,.55,.38))
    STAGE34_FOLIAGE.decorate(zones[3],"Echo Valley",Rect2(216,-35,77,70),100,34013,Color(.52,.41,.68))
    _build_stage33_landmarks()
    _build_scenic_landmarks()
    _build_moon_seal_outpost()
    _build_silver_birches()
    _build_rock_fields()
    _build_moon_lanterns()
    _build_moon_memories()
    _build_rift_arena()
    _build_firefly_fields()
    _create_player()
    _build_moon_motes()
    _make_companion()
    _make_camera()
    _make_target_ring()
    _build_ui()
    # 45 FPS mobile target; stable CPU/GPU pressure is preferable to short spikes.
    if OS.has_feature("mobile"):
        Engine.max_fps = 45
    get_viewport().scaling_3d_scale = mobile_resolution_scale
    _restore()
    _sync_companion()
    _spawn_enemies()
    _ensure_forest_spawns()
    _restore_sanctuary_wave()
    _restore_moon_seal_wave()
    _restore_rift_wave()
    _restore_echo_wave()
    _update_zone_visibility()
    _update_stage41_light_visibility()
    _update_lighting()
    _update_firefly_visibility()
    _refresh_moon_motes()
    _status("تحدث إلى الحارسة عند لوحة المهام لبدء المغامرة")

func _bind_inputs() -> void:
    var binds := {
        "move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
        "move_forward": [KEY_W, KEY_UP], "move_backward": [KEY_S, KEY_DOWN],
        "interact": [KEY_E], "attack": [KEY_SPACE, KEY_J],
        "spell": [KEY_Q, KEY_K], "lunar_burst": [KEY_R], "dodge": [KEY_SHIFT], "parry": [KEY_F], "heal": [KEY_H],
        "pause_game": [KEY_P], "quest_journal": [KEY_L], "lock_target": [KEY_T], "next_target": [KEY_TAB],
        "dev_stats": [KEY_F3]
    }
    for act in binds:
        if not InputMap.has_action(act): InputMap.add_action(act)
        for key_code in binds[act]:
            var ev := InputEventKey.new()
            ev.physical_keycode = key_code
            InputMap.action_add_event(act, ev)

func _environment() -> void:
    var sun := DirectionalLight3D.new()
    sun.light_energy = 1.18
    sun.light_color = Color(1.0, 0.88, 0.76)
    sun.shadow_enabled = not OS.has_feature("mobile")
    sun_light = sun
    sun.rotation_degrees = Vector3(-52.0, -28.0, 0.0)
    add_child(sun)
    var world := WorldEnvironment.new()
    var env := Environment.new()
    var sky := Sky.new()
    var mat := ProceduralSkyMaterial.new()
    mat.sky_top_color = Color(0.12, 0.30, 0.55)
    mat.sky_horizon_color = Color(0.67, 0.73, 0.74)
    mat.ground_horizon_color = Color(0.57, 0.61, 0.53)
    sky.sky_material = mat
    atmosphere_sky = mat
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.reflected_light_source = Environment.REFLECTION_SOURCE_BG
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.ambient_light_energy = .78
    atmosphere_environment = env
    world.environment = env
    add_child(world)

func _new_zone(name: String) -> Node3D:
    var root := Node3D.new()
    root.name = name
    add_child(root)
    zones.append(root)
    return root

func _asset(scene: PackedScene, parent: Node3D, at: Vector3, turn: float = 0.0, size: float = 1.0) -> Node3D:
    var obj := scene.instantiate() as Node3D
    parent.add_child(obj)
    obj.position = at
    obj.rotation.y = turn
    obj.scale = Vector3.ONE * size
    return obj

func _ground(parent: Node3D, loc: Vector3, span: Vector2, tint: Color, texture_name: String = "grass") -> void:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(span.x, 0.24, span.y)
    mesh.mesh = box
    mesh.position = loc + Vector3(0, -0.19, 0)
    var material := StandardMaterial3D.new()
    # Tiles repeat across larger regions; avoid stretched, blurry textures.
    material.albedo_color = tint.lightened(0.22)
    material.roughness = 0.86
    match texture_name:
        "stone":
            material.albedo_texture = STONE_TEXTURE
            material.normal_enabled = true
            material.normal_texture = STONE_NORMAL
            material.normal_scale = .52
        "dirt":
            material.albedo_texture = DIRT_TEXTURE
            material.normal_enabled = true
            material.normal_texture = DIRT_NORMAL
            material.normal_scale = .28
        "basalt":
            material.albedo_texture = BASALT_TEXTURE
            material.normal_enabled = true
            material.normal_texture = BASALT_NORMAL
            material.normal_scale = .56
        _: material.albedo_texture = GRASS_TEXTURE
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    material.texture_repeat = BaseMaterial3D.TEXTURE_REPEAT_ENABLED
    material.uv1_scale = Vector3(span.x / 5.4, span.y / 5.4, 1.0)
    mesh.material_override = material
    parent.add_child(mesh)

func _plant_meadow(parent: Node3D, bottom: Vector2, top: Vector2, count: int, clear_road_width: float) -> void:
    # Four triangles per tuft + one instanced draw; deterministic seed.
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for angle in [0.0, PI/2.0]:
        var side := Vector3(cos(angle),0,sin(angle)) * 0.16
        var bottom_left := -side
        var bottom_right := side
        var tip := Vector3(0.05,0.54,0.04)
        for tri in [[bottom_left,bottom_right,tip],[tip,bottom_right,bottom_left]]:
            for vert in tri:
                st.set_normal(Vector3.UP)
                st.add_vertex(vert)
    var blade := st.commit()
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(.30,.56,.24)
    mat.vertex_color_use_as_albedo = true
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.roughness = 1.0
    blade.surface_set_material(0,mat)
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    multi.use_colors = true
    multi.mesh = blade
    multi.instance_count = count if OS.has_feature("mobile") else int(count*1.55)
    var rand := RandomNumberGenerator.new()
    rand.seed = 2448 + count
    var assigned: int = 0
    var attempts: int = 0
    var target_count := multi.instance_count
    while assigned < target_count and attempts < target_count*15:
        attempts += 1
        var x := rand.randf_range(bottom.x,top.x)
        var z := rand.randf_range(bottom.y,top.y)
        if absf(z) < clear_road_width*0.5:
            continue
        if x < 44.0 and x > -39.0 and absf(x) < 34.0:
            var blocked: bool = false
            for i in range(8):
                var house_z := -31.0+float(i)*8.4
                if absf(z-house_z) < 4.7 and (absf(x)>8.0 and absf(x)<23.5):
                    blocked = true
                    break
            if blocked:
                continue
        var b := Basis(Vector3.UP, rand.randf_range(-PI,PI)).scaled(Vector3.ONE*rand.randf_range(.5,1.4))
        multi.set_instance_transform(assigned, Transform3D(b,Vector3(x,0,z)))
        multi.set_instance_color(assigned,Color(rand.randf_range(.7,1.0),rand.randf_range(.82,1.0),rand.randf_range(.58,.87)))
        assigned += 1
    multi.visible_instance_count = assigned
    var grove := MultiMeshInstance3D.new()
    grove.name = "GPU_Grass_Instanced"
    grove.multimesh = multi
    grove.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF if OS.has_feature("mobile") else GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    # Explicit AABB prevents culling all vegetation based on a single tuft.
    grove.custom_aabb = AABB(Vector3(bottom.x,-1.0,bottom.y),Vector3(top.x-bottom.x,4.0,top.y-bottom.y))
    parent.add_child(grove)

func _add_forest_leaf_litter(parent: Node3D, region: Rect2, amount: int, seed: int) -> void:
    # One GPU-instanced field; no collision, AI or object-per-leaf processing.
    var count: int = int(amount*.42) if OS.has_feature("mobile") else amount
    var leaf_mesh := PlaneMesh.new()
    leaf_mesh.size = Vector2(.15,.29)
    var material := StandardMaterial3D.new()
    material.vertex_color_use_as_albedo = true
    material.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
    material.cull_mode = BaseMaterial3D.CULL_DISABLED
    material.roughness = .95
    leaf_mesh.material = material
    var field := MultiMesh.new()
    field.transform_format = MultiMesh.TRANSFORM_3D
    field.use_colors = true
    field.mesh = leaf_mesh
    field.instance_count = count
    var rng := RandomNumberGenerator.new()
    rng.seed = seed
    var placed: int = 0
    var attempts: int = 0
    while placed < count and attempts < count*12:
        attempts += 1
        var x: float = rng.randf_range(region.position.x,region.end.x)
        var z: float = rng.randf_range(region.position.y,region.end.y)
        if absf(z) < 8.0:
            continue
        if x > 84.0 and x < 107.0 and z > 18.0 and z < 41.0:
            continue
        var basis := Basis(Vector3.UP,rng.randf_range(-PI,PI)).scaled(Vector3.ONE*rng.randf_range(.65,1.4))
        field.set_instance_transform(placed, Transform3D(basis,Vector3(x,.045,z)))
        var hue: Color = Color(.68,.39,.14) if placed%3==0 else (Color(.47,.55,.22) if placed%3==1 else Color(.54,.28,.13))
        field.set_instance_color(placed,hue)
        placed += 1
    field.visible_instance_count = placed
    var instance := MultiMeshInstance3D.new()
    instance.name = "Stage31_InstancedForestLeaves"
    instance.multimesh = field
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    instance.custom_aabb = AABB(Vector3(region.position.x,-.1,region.position.y),Vector3(region.size.x,1.0,region.size.y))
    parent.add_child(instance)

func _build_scenic_landmarks() -> void:
    # Showcase assets are grouped by material in their GLB source, not hundreds of loose meshes.
    _asset(WATCH_TOWER,zones[0],Vector3(-38,0,-35),0.24,0.82)
    _obstacle(zones[0],Vector3(-38,0,-35),Vector3(5.1,11.0,5.1))
    _asset(FOREST_SANCTUARY,zones[1],sanctuary_center,0,0.89)
    # Separate column colliders leave the central ritual space accessible.
    for col in range(8):
        var a := TAU*float(col)/8.0
        _obstacle(zones[1],sanctuary_center+Vector3(cos(a)*3.9,0,sin(a)*3.9),Vector3(.78,3.8,.78))
    var sanctuary_tag := Label3D.new()
    sanctuary_tag.text = "معبد القمر — تفاعل"
    sanctuary_tag.font_size = 28
    sanctuary_tag.pixel_size = 0.007
    sanctuary_tag.outline_size = 8
    sanctuary_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    sanctuary_tag.position = sanctuary_center + Vector3(0,6.8,0)
    zones[1].add_child(sanctuary_tag)
    for i in range(3):
        var lamp_z := -24.0+float(i)*23.0
        for side in [-1,1]:
            var lamp_x := float(side)*7.6
            _asset(ROAD_LANTERN,zones[0],Vector3(lamp_x,0,lamp_z),0,0.76)
    for z in [-23.0,0.0,24.0]:
        _asset(ROAD_LANTERN,zones[1],Vector3(61,0,z),0,0.72)
    # A small number of non-shadowed lights. Never one dynamic light per visible lantern.
    for at in [Vector3(7.5,3.6,0),Vector3(-7.5,3.6,0),Vector3(96,2.8,30)]:
        var light := OmniLight3D.new()
        light.position = at
        light.light_color = Color(1.0,.67,.38) if at.x < 40.0 else Color(.34,.75,1.0)
        light.light_energy = .82
        light.omni_range = 9.5
        light.shadow_enabled = false
        (zones[0] if at.x < 40.0 else zones[1]).add_child(light)
        scenic_lights.append(light)
    _build_fern_instancing(zones[0],Vector2(-44,-45),Vector2(44,45),45,173)
    _build_fern_instancing(zones[1],Vector2(42,-40),Vector2(132,40),76,917)
    _build_fern_instancing(zones[2],Vector2(140,-28),Vector2(201,28),24,371)
    var river := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(26,13)
    plane.subdivide_width = 24
    plane.subdivide_depth = 10
    river.mesh = plane
    river.position = Vector3(80,.04,23)
    var river_material := ShaderMaterial.new()
    river_material.shader = RIVER_SHADER
    river.material_override = river_material
    river.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    zones[1].add_child(river)

func _build_moon_seal_outpost() -> void:
    # Three authored GLB carvings, plus a distinctive small outpost landmark.
    # All are part of Wildwood zone and disappear when this area is unloaded.
    var seal_material := ShaderMaterial.new()
    seal_material.shader = MOON_SEAL_SHADER
    for i in range(moon_seal_places.size()):
        _apply_moon_seal_material(_asset(MOON_SEAL,zones[1],moon_seal_places[i],float(i)*.63,0.82),seal_material)
    _apply_moon_seal_material(_asset(MOON_ALTAR,zones[1],moon_seal_altar_pos,0.0,1.0),seal_material)
    var caption := Label3D.new()
    caption.text = "مذبح الأختام — تفاعل"
    caption.font_size = 29
    caption.pixel_size = .007
    caption.outline_size = 9
    caption.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    caption.position = moon_seal_altar_pos + Vector3(0,4.4,0)
    zones[1].add_child(caption)
    moon_seal_glow = OmniLight3D.new()
    moon_seal_glow.position = moon_seal_altar_pos + Vector3(0,2.6,0)
    moon_seal_glow.omni_range = 9.0
    moon_seal_glow.light_color = Color(.27,.76,.95)
    moon_seal_glow.light_energy = .60
    moon_seal_glow.shadow_enabled = false
    zones[1].add_child(moon_seal_glow)

func _apply_moon_seal_material(obj: Node3D, mat: ShaderMaterial) -> void:
    for node in obj.find_children("*","MeshInstance3D",true,false):
        if node is MeshInstance3D:
            (node as MeshInstance3D).set_surface_override_material(0,mat)

func _build_silver_birches() -> void:
    # The entire birch stand is ONE instanced draw per material surface.
    var source: Node3D = SILVER_BIRCH.instantiate() as Node3D
    var pieces := source.find_children("*","MeshInstance3D",true,false)
    if pieces.is_empty():
        source.free()
        return
    var instanced := MultiMesh.new()
    instanced.transform_format = MultiMesh.TRANSFORM_3D
    instanced.mesh = (pieces[0] as MeshInstance3D).mesh
    instanced.instance_count = 18
    var rng := RandomNumberGenerator.new()
    rng.seed = 20261119
    var valid := 0
    for i in range(18):
        var x := rng.randf_range(48.0,132.0)
        var z := (-1.0 if i%2==0 else 1.0)*rng.randf_range(18.0,40.0)
        if x > 91.0 and x < 109.0 and z > 20.0:
            continue # Do not block the sanctuary approach.
        if x > 114.0 and z > 22.0:
            continue # Clear outpost altar and third moon seal.
        var size := rng.randf_range(.70,1.16)
        var b := Basis(Vector3.UP,rng.randf_range(-PI,PI)).scaled(Vector3.ONE*size)
        instanced.set_instance_transform(valid,Transform3D(b,Vector3(x,0,z)))
        valid += 1
    instanced.visible_instance_count = valid
    birch_field = MultiMeshInstance3D.new()
    birch_field.name = "Silver_Birches_GPU_Instanced"
    birch_field.multimesh = instanced
    birch_field.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    birch_field.custom_aabb = AABB(Vector3(42,-2,-43),Vector3(99,12,87))
    zones[1].add_child(birch_field)
    source.free()

func _build_rock_fields() -> void:
    # One GLB surface -> one GPU instancing batch per region. Rocks are visual only;
    # buildings, pillars and gates keep their authored static collision proxies.
    var source: Node3D = ROCK.instantiate() as Node3D
    var pieces := source.find_children("*", "MeshInstance3D", true, false)
    if pieces.is_empty():
        source.free()
        return
    var source_mesh: Mesh = (pieces[0] as MeshInstance3D).mesh
    for entry in [
        [zones[1],Vector2(44,-43),Vector2(129,42),49,911],
        [zones[2],Vector2(143,-33),Vector2(203,34),72,407]
    ]:
        var rand := RandomNumberGenerator.new()
        rand.seed = int(entry[4])
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.mesh = source_mesh
        mm.instance_count = int(entry[3])
        var bound_min: Vector2 = entry[1]
        var bound_max: Vector2 = entry[2]
        var valid: int = 0
        for i in range(int(entry[3])):
            var x := rand.randf_range(bound_min.x,bound_max.x)
            var z := rand.randf_range(bound_min.y,bound_max.y)
            # Preserve road traversal, sanctuary floor and moon shrine.
            if absf(z) < 12.0 or (x>89.0 and x<106.0 and z>18.0):
                continue
            if x>164.0 and x<184.0 and absf(z)<10.0:
                continue
            var scale := rand.randf_range(.56,1.85)
            var basis := Basis(Vector3.UP,rand.randf_range(-PI,PI)).scaled(Vector3(scale,scale*rand.randf_range(.55,1.6),scale))
            mm.set_instance_transform(valid,Transform3D(basis,Vector3(x,-.21,z)))
            valid += 1
        mm.visible_instance_count = valid
        var field := MultiMeshInstance3D.new()
        field.name = "RockClusters_GPU"
        field.multimesh = mm
        field.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        field.custom_aabb = AABB(Vector3(bound_min.x,-1,bound_min.y),Vector3(bound_max.x-bound_min.x,6,bound_max.y-bound_min.y))
        (entry[0] as Node3D).add_child(field)
        instanced_rock_fields.append(field)
    source.free()

func _build_fern_instancing(parent: Node3D, bottom: Vector2, top: Vector2, quantity: int, seed_value: int) -> void:
    var source: Node3D = FERN.instantiate() as Node3D
    var parts := source.find_children("*","MeshInstance3D",true,false)
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    # Every material mesh is drawn as a single MultiMeshInstance3D.
    var transforms: Array[Transform3D] = []
    for i in range(quantity):
        var x := rng.randf_range(bottom.x,top.x)
        var z := rng.randf_range(bottom.y,top.y)
        if absf(z) < 11.0 or (x > 83.0 and x < 107.0 and z > 22.0):
            continue
        var sc := rng.randf_range(.58,.95)
        transforms.append(Transform3D(Basis(Vector3.UP,rng.randf_range(-PI,PI)).scaled(Vector3.ONE*sc),Vector3(x,0,z)))
    for part in parts:
        if not (part is MeshInstance3D):
            continue
        var multi := MultiMesh.new()
        multi.transform_format = MultiMesh.TRANSFORM_3D
        multi.mesh = (part as MeshInstance3D).mesh
        multi.instance_count = transforms.size()
        for i in range(transforms.size()):
            multi.set_instance_transform(i,transforms[i])
        var field := MultiMeshInstance3D.new()
        field.multimesh = multi
        field.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        field.custom_aabb = AABB(Vector3(bottom.x,-.1,bottom.y),Vector3(top.x-bottom.x,4,top.y-bottom.y))
        parent.add_child(field)
        fern_multimeshes.append(field)
    source.free()

func _build_moon_lanterns() -> void:
    var colors := [Color(.25,.75,.96),Color(.72,.38,.94),Color(.98,.74,.36)]
    for i in range(3):
        var zone_parent: Node3D = zones[1] if i < 2 else zones[2]
        _asset(WAYSTONE,zone_parent,moon_lantern_positions[i],float(i)*1.1,0.72)
        var orb := OmniLight3D.new()
        orb.position = moon_lantern_positions[i]+Vector3(0,2.5,0)
        orb.light_color = colors[i]
        orb.light_energy = 0.0
        orb.omni_range = 8.0
        orb.shadow_enabled = false
        zone_parent.add_child(orb)
        moon_lantern_lights.append(orb)

func _build_firefly_fields() -> void:
    var material := ShaderMaterial.new()
    material.shader = preload("res://shaders/fireflies.gdshader")
    var quad := QuadMesh.new()
    quad.size = Vector2(0.28, 0.28)
    # Two batches instead of one scene node per particle.
    var origins := [Vector3(81, 1.3, 13), Vector3(158, 1.3, -12)]
    var parents := [zones[1], zones[2]]
    for field_id in range(origins.size()):
        var field := MultiMeshInstance3D.new()
        var mesh := MultiMesh.new()
        mesh.transform_format = MultiMesh.TRANSFORM_3D
        mesh.use_custom_data = true
        mesh.instance_count = 96
        mesh.mesh = quad
        var rng := RandomNumberGenerator.new()
        rng.seed = 7317 + field_id * 941
        for i in range(mesh.instance_count):
            var position_3d := origins[field_id] + Vector3(rng.randf_range(-22, 22), rng.randf_range(0.2, 3.5), rng.randf_range(-21, 21))
            var transform_3d := Transform3D(Basis.IDENTITY, position_3d)
            mesh.set_instance_transform(i, transform_3d)
            mesh.set_instance_custom_data(i, Color(rng.randf(), rng.randf(), rng.randf_range(.55, 1.0), 1.0))
        field.multimesh = mesh
        field.visible = false
        field.material_override = material
        field.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        field.custom_aabb = AABB(origins[field_id] - Vector3(25, 5, 25), Vector3(50, 12, 50))
        parents[field_id].add_child(field)
        firefly_fields.append(field)
    _update_firefly_visibility()

func _update_firefly_visibility() -> void:
    # Day-night gating also avoids drawing additive quads in daylight.
    var phase := day_clock / 390.0
    var night := phase < .18 or phase > .73
    if firefly_visible == night:
        return
    firefly_visible = night
    for field in firefly_fields:
        field.visible = night

func _update_lighting() -> void:
    # One lighting update per second instead of changing sky/materials every frame.
    var phase := day_clock*TAU/390.0
    var daylight := clampf(.55+.45*sin(phase),.16,1.0)
    sun_light.light_energy = 0.32+daylight*0.83
    sun_light.rotation.x = -0.40 - .48*daylight
    for lamp in scenic_lights:
        lamp.light_energy = .33 + .44*(1.0-daylight)
    if is_instance_valid(moon_seal_glow):
        moon_seal_glow.light_energy = (.50 if moon_seal_state != 3 else 1.10) + .18*(1.0-daylight)
    for i in range(moon_lantern_lights.size()):
        var lit: bool = i < moon_lantern_step
        moon_lantern_lights[i].light_energy = (1.2 if lit else 0.28) * (1.15-daylight*.15)
    _update_atmosphere(daylight)
    _update_stage43_character_materials(daylight)

func _update_stage43_character_materials(daylight: float) -> void:
    # A handful of rig materials only; no changes to vertices, skeleton tags or combat.
    # Godot processes this once per world-lighting tick, not every physics frame.
    var darkness: float = 0.0
    if atmosphere_enabled:
        darkness = 1.0-smoothstep(.18,.86,daylight)
    for node in get_tree().get_nodes_in_group("moon_stage43_lit_actors"):
        if not is_instance_valid(node):
            continue
        var material: Variant = node.get_meta("moon_stage43_character_material",null)
        if material is ShaderMaterial:
            (material as ShaderMaterial).set_shader_parameter("night_blend",darkness)

# Stage 21: interpolate a readable moonlit palette instead of a hard night switch.
# Applied only once per second along with the existing sunlight update.
func _update_ambient_flicker(delta: float) -> void:
    # Run at 5-8Hz, not every frame. Keep original daylight and cinematic balance.
    if not atmosphere_enabled:
        return
    ambient_flicker_clock += delta
    var interval: float = .24 if OS.has_feature("mobile") else .13
    if ambient_flicker_clock < interval:
        return
    ambient_flicker_clock = 0.0
    var daylight := clampf(.55+.45*sin(day_clock*TAU/390.0),.16,1.0)
    var base_energy := .33+.44*(1.0-daylight)
    for i in range(scenic_lights.size()):
        var lamp := scenic_lights[i]
        if not is_instance_valid(lamp) or not lamp.is_visible_in_tree():
            continue
        if lamp.global_position.distance_squared_to(player.global_position) > 2500.0:
            continue
        var variation := sin(clock*9.7+float(i)*1.67)*.042 + sin(clock*16.3+float(i)*2.41)*.018
        lamp.light_energy = base_energy*(1.0+variation)

func _update_atmosphere(daylight: float) -> void:
    if not is_instance_valid(atmosphere_environment) or not is_instance_valid(atmosphere_sky):
        return
    if not atmosphere_enabled:
        atmosphere_environment.fog_enabled = false
        atmosphere_sky.sky_top_color = Color(0.12, 0.30, 0.55)
        atmosphere_sky.sky_horizon_color = Color(0.67, 0.73, 0.74)
        atmosphere_sky.ground_horizon_color = Color(0.57, 0.61, 0.53)
        sun_light.light_color = Color(1.0, 0.88, 0.76)
        _refresh_moon_motes()
        return
    var evening := smoothstep(0.18, 0.86, daylight)
    atmosphere_sky.sky_top_color = Color(.018,.032,.110).lerp(Color(.14,.34,.60),evening)
    atmosphere_sky.sky_horizon_color = Color(.20,.30,.47).lerp(Color(.72,.77,.79),evening)
    atmosphere_sky.ground_horizon_color = Color(.11,.15,.24).lerp(Color(.60,.64,.57),evening)
    sun_light.light_color = Color(.60,.76,1.0).lerp(Color(1.0,.90,.78),evening)
    # Very light distance fog: keeps attack warnings readable and limits visual noise.
    atmosphere_environment.fog_enabled = true
    atmosphere_environment.fog_light_color = Color(.23,.37,.56).lerp(Color(.62,.68,.66),evening)
    atmosphere_environment.fog_density = .0038 if OS.has_feature("mobile") else .0065
    _refresh_moon_motes()

func _build_moon_motes() -> void:
    # One instanced draw call, no physics or per-particle GDScript updates.
    moon_motes = MultiMeshInstance3D.new()
    moon_motes.name = "Moonlit_Ambient_Motes"
    var sphere := SphereMesh.new()
    sphere.radius = .065
    sphere.height = .13
    sphere.radial_segments = 6
    sphere.rings = 3
    var particles := MultiMesh.new()
    particles.transform_format = MultiMesh.TRANSFORM_3D
    particles.use_custom_data = true
    particles.mesh = sphere
    particles.instance_count = 32 if OS.has_feature("mobile") else 64
    var rng := RandomNumberGenerator.new()
    rng.seed = 217021
    for i in range(particles.instance_count):
        var pos := Vector3(rng.randf_range(-16.0,16.0),rng.randf_range(.7,5.3),rng.randf_range(-16.0,16.0))
        var scale_value := rng.randf_range(.65,1.45)
        particles.set_instance_transform(i,Transform3D(Basis.IDENTITY.scaled(Vector3.ONE*scale_value),pos))
        particles.set_instance_custom_data(i,Color(rng.randf(),rng.randf(),rng.randf_range(.6,1.0),.65))
    moon_motes.multimesh = particles
    var mat := ShaderMaterial.new()
    mat.shader = preload("res://shaders/moon_motes.gdshader")
    moon_motes.material_override = mat
    moon_motes.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    moon_motes.custom_aabb = AABB(Vector3(-20,-1,-20),Vector3(40,9,40))
    moon_motes.visible = false
    add_child(moon_motes)
    moon_motes.position = player.position

func _refresh_moon_motes() -> void:
    if not is_instance_valid(moon_motes):
        return
    var phase := day_clock*TAU/390.0
    var daylight := clampf(.55+.45*sin(phase),.16,1.0)
    moon_motes.visible = atmosphere_enabled and daylight < .74

func _impact_sparks(at: Vector3, tint: Color = Color(.76,.91,1.0)) -> void:
    # Lightweight 0.32 s impact burst; one multimesh node per registered hit.
    var sparks := MultiMeshInstance3D.new()
    var particle_mesh := SphereMesh.new()
    particle_mesh.radius = .075
    particle_mesh.height = .15
    particle_mesh.radial_segments = 6
    particle_mesh.rings = 3
    var cluster := MultiMesh.new()
    cluster.transform_format = MultiMesh.TRANSFORM_3D
    cluster.mesh = particle_mesh
    cluster.instance_count = 9 if OS.has_feature("mobile") else 14
    for i in range(cluster.instance_count):
        var a := TAU*float(i)/float(cluster.instance_count)
        var offset := Vector3(cos(a)*.32,sin(a*2.0)*.29,sin(a)*.32)
        cluster.set_instance_transform(i,Transform3D(Basis.IDENTITY,offset))
    sparks.multimesh = cluster
    sparks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    sparks.position = at+Vector3(0.0,1.25,0.0)
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(tint.r,tint.g,tint.b,.92)
    mat.emission_enabled = true
    mat.emission = tint
    mat.emission_energy_multiplier = 1.95
    sparks.material_override = mat
    add_child(sparks)
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(sparks,"scale",Vector3.ONE*2.9,.32)
    tween.tween_property(sparks,"position:y",sparks.position.y+.28,.32)
    tween.tween_property(mat,"albedo_color:a",0.0,.32)
    tween.set_parallel(false)
    tween.tween_callback(sparks.queue_free)

func _obstacle(parent: Node3D, at: Vector3, extent: Vector3, angle: float = 0.0) -> void:
    var body := StaticBody3D.new()
    body.collision_layer = 4
    body.collision_mask = 0
    body.position = at
    body.rotation.y = angle
    var collider := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = extent
    collider.shape = shape
    collider.position.y = extent.y * 0.5
    body.add_child(collider)
    parent.add_child(body)

func _make_sword_arc() -> void:
    # One reusable procedural blade sweep; no particles spawned in every frame.
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for i in range(16):
        var a := deg_to_rad(-80.0 + float(i) * 10.0)
        var b := deg_to_rad(-80.0 + float(i+1) * 10.0)
        var p0 := Vector3(sin(a)*1.1,1.65,cos(a)*1.1)
        var p1 := Vector3(sin(a)*2.7,1.9,cos(a)*2.7)
        var p2 := Vector3(sin(b)*2.7,1.9,cos(b)*2.7)
        var p3 := Vector3(sin(b)*1.1,1.65,cos(b)*1.1)
        for point in [p0,p1,p2,p0,p2,p3]:
            st.set_normal(Vector3.UP)
            st.add_vertex(point)
    swing_arc = MeshInstance3D.new()
    swing_arc.mesh = st.commit()
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.albedo_color = Color(.42,.88,1.0,.48)
    mat.emission_enabled = true
    mat.emission = Color(.18,.56,.93)
    swing_arc.material_override = mat
    swing_arc.visible = false
    player.add_child(swing_arc)

func _show_sword_arc() -> void:
    swing_arc.visible = true
    swing_arc.rotation.y = atan2(hero_forward.x,hero_forward.z)
    swing_arc.scale = Vector3(.45,.65,.45)
    var t := create_tween()
    t.tween_property(swing_arc,"scale",Vector3.ONE,.19)
    t.tween_callback(func() -> void: swing_arc.visible = false)

func _spawn_spell_light(target_point: Vector3) -> void:
    var orb := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = .28
    mesh.height = .56
    mesh.radial_segments = 9
    mesh.rings = 5
    orb.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = Color(.47,.85,1.0)
    mat.emission_enabled = true
    mat.emission = Color(.21,.7,1.0)
    mat.emission_energy_multiplier = 2.0
    orb.material_override = mat
    add_child(orb)
    orb.position = player.position + Vector3(0,1.8,0)
    var t := create_tween()
    t.tween_property(orb,"position",target_point + Vector3(0,1.6,0),.22)
    t.tween_callback(orb.queue_free)

func _moon_spell_impact(target_point: Vector3) -> void:
    # Single transient expanding spell glyph; despawns after 0.30 s.
    var ring := MeshInstance3D.new()
    ring.name = "Stage28_Moonsteel_Spell_Ring"
    var mesh := TorusMesh.new()
    mesh.inner_radius = .54
    mesh.outer_radius = .72
    mesh.rings = 6
    mesh.ring_segments = 24
    ring.mesh = mesh
    ring.position = target_point+Vector3(0,.12,0)
    ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var glow := StandardMaterial3D.new()
    glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    glow.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    glow.albedo_color = Color(.42,.80,1.0,.75)
    glow.emission_enabled = true
    glow.emission = Color(.23,.61,1.0)
    ring.material_override = glow
    add_child(ring)
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(ring,"scale",Vector3.ONE*2.3,.30)
    tween.tween_property(glow,"albedo_color:a",0.0,.30)
    tween.set_parallel(false)
    tween.tween_callback(ring.queue_free)

func _stage35_village_presentation(village: Node3D) -> void:
    STAGE35_POLISH.make_bench(village, Vector3(-4.6,0.0,-10.3), 1.57, .94)
    STAGE35_POLISH.make_bench(village, Vector3(12.2,0.0,11.6), -0.88, .86)
    STAGE35_POLISH.make_hanging_sign(village, Vector3(-13.2,0.0,6.8), 1.57, .92)
    STAGE35_POLISH.make_window_glow(village, Vector3(-18.5,2.15,-6.2), 0.0, Vector2(.92,1.08))
    STAGE35_POLISH.make_window_glow(village, Vector3(18.6,2.05,4.1), PI, Vector2(.92,1.08))
    STAGE35_POLISH.make_torch(village, Vector3(-1.5,0.0,21.8), 0.0, .96)
    STAGE35_POLISH.make_torch(village, Vector3(32.8,0.0,18.6), 0.0, .90)

func _stage35_world_presentation(root: Node3D, zone_name: String) -> void:
    if zone_name == "wildwood":
        STAGE35_POLISH.make_torch(root, Vector3(74.0,0.0,8.5), 0.0, .92, Color(1.0,.66,.26))
        STAGE35_POLISH.make_hanging_sign(root, Vector3(96.0,0.0,-19.0), 0.35, .88, Color(.70,.71,.57))
    elif zone_name == "ruins":
        STAGE35_POLISH.make_torch(root, Vector3(160.8,0.0,14.5), 0.0, .92, Color(.56,.82,1.0))
        STAGE35_POLISH.make_window_glow(root, Vector3(193.5,2.0,9.8), 2.62, Vector2(.82,1.02), Color(.61,.82,1.0))
    elif zone_name == "echo":
        STAGE35_POLISH.make_torch(root, Vector3(235.0,0.0,-20.0), 0.0, .98, Color(.71,.49,1.0))
        STAGE35_POLISH.make_hanging_sign(root, Vector3(266.0,0.0,23.0), -0.5, .86, Color(.69,.58,.80))

func _build_village() -> void:
    var root := _new_zone("01_Village")
    _asset(GROUND, root, Vector3.ZERO)
    _plant_meadow(root, Vector2(-44.0,-45.0),Vector2(44.0,47.0),540,20.0)
    for i in range(8):
        var z := -31.0 + float(i) * 8.4
        for side in [-1, 1]:
            if i == 5 and side == 1:
                continue
            var house_type: int = (i + (1 if side > 0 else 0)) % 4
            var h := _asset(HOUSE_TYPES[house_type],root,Vector3(side * (14.3 + float(i % 3) * 1.5), 0.0, z))
            h.rotation.y = PI if side == 1 else 0.0
            _obstacle(root,h.position,Vector3(9.4,5.0,8.7),h.rotation.y)
    for i in range(42):
        var x := sin(float(i) * 3.27) * (25.0 + float(i % 6) * 2.8)
        var z := -42.0 + float(i % 17) * 5.0
        if absf(x) > 45.0:
            continue
        _asset(PINE if i % 3 == 0 else OAK,root,Vector3(x,0,z),float(i),0.72+float(i%4)*0.12)
    _asset(FOUNTAIN,root,Vector3(-8.7,0,-13.0))
    _obstacle(root,Vector3(-8.7,0,-13.0),Vector3(5.7,2.2,5.7))
    _asset(MARKET,root,shop_position,-0.5)
    _obstacle(root,shop_position,Vector3(3.0,2.9,2.5),-.5)
    _asset(BOARD,root,board_position)
    # Stage 23: recognizable adult NPCs positioned close to existing quest and shop hotspots.
    # Decorative actors only; interactions and all original quest triggers remain unchanged.
    _adult_villager(LAURA_ADULT, root, Vector3(-10.6,0,7.1), 0.28, "لورا — دليل المهمات")
    _adult_villager(MERCHANT_ADULT, root, Vector3(11.0,0,-8.5), -0.65, "تاجر القرية")
    _asset(WAYSTONE,root,Vector3(36,0,3),0,0.8)
    rayan_npc = _asset(RAYAN,root,rayan_spot,PI,0.90)
    var rayan_idle_parts: Dictionary = RIG_DRIVER.get_parts(rayan_npc)
    _apply_retro_character_finish(rayan_npc, Color(.18,.49,.70), .09)
    _add_ambient_actor(rayan_npc, "villager", rayan_idle_parts)
    STAGE36_CHARACTER_KIT.attach(rayan_npc, "rayan")
    _equip_retro_sword(rayan_npc, RAYAN_SWORD, 1.25, 28.0)
    var tag := Label3D.new()
    tag.text = "ريان — الرفيق"
    tag.font_size = 28
    tag.pixel_size = 0.006
    tag.position = Vector3(0,4.25,0)
    tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    rayan_npc.add_child(tag)
    _ground(root,Vector3(48,0,0),Vector2(36,12),Color(0.48,0.45,0.36),"stone")
    _build_retro_village_props(root)
    _stage35_village_presentation(root)
    # Stage 32: physical-looking decorative crates; existing mission hotspots are untouched.
    RETRO_DETAILS.make_supply_crate(root,Vector3(-14.1,0,-14.1),.35,.86)
    RETRO_DETAILS.make_supply_crate(root,Vector3(17.4,0,9.2),-.24,.95)
    RETRO_DETAILS.make_carved_waymarker(root,Vector3(-32.2,0,11.3),.16,.74)

func _build_retro_village_props(village: Node3D) -> void:
    # Original 3D props (not flat image overlays). Existing quests and NPC positions
    # are left unchanged; the stable is placed clear of the central village road.
    var stable := Node3D.new()
    stable.name = "26_Chestnut_Horse_And_Timber_Paddock"
    stable.position = Vector3(26.0, 0.0, 19.0)
    stable.rotation.y = -.18
    village.add_child(stable)
    _asset(VILLAGE_FENCE, stable, Vector3.ZERO, 0.0, 1.0)
    var stable_horse := _asset(VILLAGE_HORSE, stable, Vector3(0,0,0), -.38, .89)
    _add_ambient_actor(stable_horse, "horse")
    _asset(VILLAGE_BARREL, village, Vector3(22.5,0.0,13.3), .18, .95)
    _asset(VILLAGE_BARREL, village, Vector3(23.6,0.0,13.0), -.22, .79)
    _asset(VILLAGE_BARREL, village, Vector3(-16.1,0.0,16.5), .12, .82)
    _asset(VILLAGE_SIGN, village, Vector3(-8.0,0.0,25.5), .04, 1.0)
    _asset(VILLAGE_SIGN, village, Vector3(39.3,0.0,-3.2), 1.7, .84)
    _asset(VILLAGE_SIGN, village, Vector3(5.6,0.0,-26.0), 3.14, .90)
    _add_timber_bench(village, Vector3(-10.2,0.0,-20.2), 0.55)
    _add_timber_bench(village, Vector3(10.2,0.0,13.0), -.55)
    _add_village_banner(village, Vector3(-3.4,0.0,-6.2), Color(.55,.14,.12), .06)
    _add_village_banner(village, Vector3(4.1,0.0,-6.0), Color(.47,.33,.14), -.03)
    _add_village_banner(village, Vector3(14.2,0.0,8.4), Color(.15,.41,.18), 1.28, 4.1)
    _add_stable_lamp(village, Vector3(23.7,3.2,15.0))
    _add_stable_lamp(village, Vector3(29.6,3.2,22.0))
    # Original textured cobblestone lane with a softer, desaturated retro tone.
    # Geometry remains cosmetic: no new path collider and no quest obstruction.
    _ground(village,Vector3(0,.17,0),Vector2(9.5,78.0),Color(.76,.75,.72),"stone")
    _ground(village,Vector3(24,.13,18.8),Vector2(16.0,10.0),Color(.79,.76,.66),"dirt")
    var info := Label3D.new()
    info.text = "إسطبل القرية"
    info.font_size = 24
    info.pixel_size = .006
    info.outline_size = 7
    info.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    info.position = Vector3(0,4.4,0)
    stable.add_child(info)

func _add_village_banner(parent: Node3D, at: Vector3, cloth_color: Color, facing: float = 0.0, pole_height: float = 4.6) -> void:
    var root := Node3D.new()
    root.position = at
    root.rotation.y = facing
    parent.add_child(root)
    var pole := MeshInstance3D.new()
    var pole_mesh := CylinderMesh.new()
    pole_mesh.top_radius = .08
    pole_mesh.bottom_radius = .10
    pole_mesh.height = pole_height
    pole.mesh = pole_mesh
    pole.position = Vector3(0,pole_height*.5,0)
    var pole_mat := StandardMaterial3D.new()
    pole_mat.albedo_color = Color(.45,.31,.16)
    pole.material_override = pole_mat
    root.add_child(pole)
    var arm := MeshInstance3D.new()
    var arm_mesh := BoxMesh.new()
    arm_mesh.size = Vector3(1.15,.10,.10)
    arm.mesh = arm_mesh
    arm.position = Vector3(.44,pole_height-.42,0)
    arm.rotation_degrees.z = 8.0
    arm.material_override = pole_mat
    root.add_child(arm)
    var cloth := MeshInstance3D.new()
    var cloth_mesh := PlaneMesh.new()
    cloth_mesh.size = Vector2(.82,1.26)
    cloth_mesh.subdivide_width = 3
    cloth_mesh.subdivide_depth = 7
    cloth.mesh = cloth_mesh
    cloth.position = Vector3(.78,pole_height-1.04,.01)
    cloth.rotation_degrees = Vector3(90,0,0)
    var cloth_mat := ShaderMaterial.new()
    cloth_mat.shader = CLOTH_WIND
    cloth_mat.set_shader_parameter("cloth_tint",cloth_color)
    cloth.material_override = cloth_mat
    root.add_child(cloth)
    var emblem := MeshInstance3D.new()
    var emblem_mesh := SphereMesh.new()
    emblem_mesh.radius = .09
    emblem_mesh.height = .18
    emblem.mesh = emblem_mesh
    emblem.position = Vector3(.78,pole_height-.86,.06)
    var emblem_mat := StandardMaterial3D.new()
    emblem_mat.albedo_color = Color(.92,.88,.63)
    emblem.material_override = emblem_mat
    root.add_child(emblem)

func _add_timber_bench(parent: Node3D, at: Vector3, facing: float = 0.0) -> void:
    # Cosmetic bench built from just three box primitives; no path collision added.
    var root := Node3D.new()
    root.name = "Stage31_TimberBench"
    root.position = at
    root.rotation.y = facing
    parent.add_child(root)
    var wood := StandardMaterial3D.new()
    wood.albedo_color = Color(.40,.25,.13)
    wood.roughness = .85
    for piece in [Vector3(1.7,.13,.50), Vector3(.15,.72,.15), Vector3(.15,.72,.15)]:
        var index := root.get_child_count()
        var node := MeshInstance3D.new()
        var cube := BoxMesh.new()
        cube.size = piece
        node.mesh = cube
        node.material_override = wood
        node.position = Vector3(0,.76,0) if index == 0 else Vector3(-.65 if index == 1 else .65,.37,0)
        root.add_child(node)

func _add_stable_lamp(parent: Node3D, at: Vector3) -> void:
    var lamp := OmniLight3D.new()
    lamp.position = at
    lamp.light_color = Color(1.0,.78,.49)
    lamp.light_energy = .88
    lamp.omni_range = 7.5
    lamp.shadow_enabled = false
    parent.add_child(lamp)

func _apply_retro_character_finish(actor: Node3D, accent: Color, strength: float = 0.10) -> void:
    for child_mesh in actor.find_children("*","MeshInstance3D",true,false):
        var part := child_mesh as MeshInstance3D
        var overlay := StandardMaterial3D.new()
        overlay.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
        overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        overlay.albedo_color = Color(accent.r, accent.g, accent.b, strength)
        overlay.emission_enabled = true
        overlay.emission = accent * 0.07
        overlay.roughness = 0.92
        part.material_overlay = overlay

func _add_ambient_actor(actor: Node3D, actor_kind: String, rig_state: Dictionary = {}) -> void:
    var animator := Node.new()
    animator.name = "Stage31_AmbientMotion"
    animator.set_script(AMBIENT_ACTOR)
    actor.add_child(animator)
    animator.call("configure", actor, self, actor_kind, rig_state, actor.position.x*.17+actor.position.z*.11)

func _adult_villager(scene: PackedScene, village: Node3D, location: Vector3, angle: float, caption: String) -> void:
    # Characters are real editable GLB assets, not billboard sprites.
    var actor := _asset(scene, village, location, angle, .88)
    # Imported GLB alpha stores region tags, not transparency. Use alpha-safe shader.
    var npc_parts: Dictionary = RIG_DRIVER.get_parts(actor)
    _apply_retro_character_finish(actor, Color(.73,.56,.30), .07)
    _add_ambient_actor(actor, "merchant" if caption.contains("تاجر") else "villager", npc_parts)
    STAGE36_CHARACTER_KIT.attach(actor, "merchant" if caption.contains("تاجر") else "laura")
    var marker := Label3D.new()
    marker.text = caption
    marker.font_size = 28
    marker.pixel_size = .006
    marker.outline_size = 8
    marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    marker.position = Vector3(0,4.18,0)
    actor.add_child(marker)

func _build_moonforge_village() -> void:
    # Two unique landmarks improve silhouette and visual variety without per-frame mesh rebuilds.
    var village: Node3D = zones[0]
    _asset(MOONFORGE,village,Vector3(-31.0,0.0,37.0))
    _asset(FORGE_PLAZA,village,Vector3(-31.0,0.0,30.7))
    _asset(GUILDHALL,village,Vector3(31.0,0.0,35.0),.0,.94)
    _obstacle(village,Vector3(-31.0,0.0,37.0),Vector3(10.2,6.0,8.0))
    _obstacle(village,Vector3(31.0,0.0,35.0),Vector3(11.7,8.0,9.8))
    var smith_actor := _asset(SMITH,village,smith_position,PI,.91)
    var smith_parts: Dictionary = RIG_DRIVER.get_parts(smith_actor)
    _apply_retro_character_finish(smith_actor, Color(.71,.41,.16), .08)
    _add_ambient_actor(smith_actor, "smith", smith_parts)
    STAGE36_CHARACTER_KIT.attach(smith_actor, "smith")
    var label := Label3D.new()
    label.text = "⚒ حداد الفجر — ترقية السيف"
    label.font_size = 34
    label.pixel_size = 0.006
    label.outline_size = 9
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.position.y = 3.95
    village.add_child(label)
    label.position.x = smith_position.x
    label.position.z = smith_position.z
    forge_light = OmniLight3D.new()
    forge_light.position = Vector3(-35.2,2.6,30.7)
    forge_light.light_color = Color(1.0,.38,.13)
    forge_light.light_energy = .92
    forge_light.omni_range = 8.2
    forge_light.shadow_enabled = false
    village.add_child(forge_light)
    scenic_lights.append(forge_light)

func _forge_upgrade() -> void:
    if smith_level >= 3:
        _status("الحداد: سيفك وصل إلى المستوى الثالث، وهو الحد الأعلى")
        return
    var price: int = [100,180,280][smith_level]
    if smith_level == 1 and quest_stage < 2:
        _status("الحداد: أكمل مواجهة وحوش الغابة لفتح الترقية الثانية")
        return
    if smith_level == 2 and quest_stage < 5:
        _status("الحداد: اهزم حارس البازلت أولاً لفتح الترقية الثالثة")
        return
    if gold < price:
        _status("الحداد: ترقية السيف إلى %d تحتاج %d ذهبًا (معك %d)" % [smith_level+1,price,gold])
        return
    gold -= price
    smith_level += 1
    _status("حداد الفجر: سيف قمري +%d! الضرر الإضافي +%d" % [smith_level,smith_level*8])
    _save()

func _retro_wildflowers(parent: Node3D, area_center: Vector3, half_extent: Vector2, count: int, hue: Color, seed: int) -> void:
    # One MultiMesh per zone. Small stylized plants are purely cosmetic.
    var petal := SphereMesh.new()
    petal.radius = .13
    petal.height = .20
    petal.radial_segments = 6
    petal.rings = 3
    var material := StandardMaterial3D.new()
    material.albedo_color = hue
    material.vertex_color_use_as_albedo = true
    material.roughness = .93
    petal.material = material
    var plants := MultiMesh.new()
    plants.transform_format = MultiMesh.TRANSFORM_3D
    plants.use_colors = true
    plants.mesh = petal
    plants.instance_count = maxi(18, int(count * 0.5)) if OS.has_feature("mobile") else count
    var rng := RandomNumberGenerator.new()
    rng.seed = seed
    for i in range(plants.instance_count):
        var x := rng.randf_range(-half_extent.x, half_extent.x)
        var z := rng.randf_range(-half_extent.y, half_extent.y)
        if absf(z) < 7.0:
            z += 8.0 if z >= 0.0 else -8.0
        var s := rng.randf_range(.65,1.65)
        var transform := Transform3D(Basis.IDENTITY.scaled(Vector3.ONE*s), area_center+Vector3(x,.19,z))
        plants.set_instance_transform(i,transform)
        plants.set_instance_color(i,Color(rng.randf_range(.82,1.0),rng.randf_range(.86,1.0),rng.randf_range(.82,1.0)))
    var field := MultiMeshInstance3D.new()
    field.name = "Stage28_Instanced_Fantasy_Ground_Cover"
    field.multimesh = plants
    field.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    field.custom_aabb = AABB(area_center-Vector3(half_extent.x,1.0,half_extent.y),Vector3(half_extent.x*2.0,3.0,half_extent.y*2.0))
    parent.add_child(field)

func _build_stage33_landmarks() -> void:
    # Scenic, non-interactive structures: no collision proxies, no persistent save state.
    # Keep center roads, combat circles and existing quest markers unobstructed.
    STAGE33_LANDMARKS.make_forest_watch_post(zones[1], Vector3(61.0,0.0,-31.0), -.30, .93)
    STAGE33_LANDMARKS.make_forest_watch_post(zones[1], Vector3(121.0,0.0,33.0), .42, .82)
    STAGE33_LANDMARKS.make_stone_remnant(zones[2], Vector3(153.5,0.0,-25.0), .25, 1.02, Color(.41,.62,.93))
    STAGE33_LANDMARKS.make_stone_remnant(zones[2], Vector3(198.0,0.0,-24.0), -.38, .91, Color(.62,.42,.89))
    STAGE33_LANDMARKS.make_stone_remnant(zones[3], Vector3(228.0,0.0,34.0), .20, .95, Color(.60,.37,.96))
    STAGE33_LANDMARKS.make_stone_remnant(zones[3], Vector3(276.0,0.0,34.0), -.20, 1.06, Color(.35,.65,.98))

func _build_wildwood() -> void:
    var root := _new_zone("02_Wildwood")
    _ground(root,Vector3(88,0,0),Vector2(102,91),Color(0.27,0.40,0.25))
    _ground(root,Vector3(87,0,0),Vector2(104,9),Color(0.45,0.39,0.32),"dirt")
    _plant_meadow(root, Vector2(39.0,-41.0), Vector2(125.0,41.0), 900, 16.0)
    _add_forest_leaf_litter(root,Rect2(Vector2(43,-39),Vector2(84,78)),220,31191)
    for i in range(46):
        var x := 45.0 + float((i * 17) % 84)
        var z := float((i * 41) % 78) - 39.0
        if absf(z) < 7.0:
            z += 11.0 if z > 0.0 else -11.0
        if x > 88.0 and x < 104.0 and z > 21.0 and z < 39.0:
            continue  # keep the sanctuary doorway and player approach clear
        _asset(PINE if i%4==0 else OAK,root,Vector3(x,0,z),float(i)*.73,0.78+float(i%4)*.10)
    _asset(MOONFALL,root,Vector3(80,0,23.0),0,1.0)
    _asset(RUINS,root,Vector3(110,0,-14),0.5,1.5)
    # Keep the arch walkway unobstructed; side columns are blocking proxies.
    _obstacle(root,Vector3(106,0,-16.5),Vector3(1.5,3.5,2.2))
    _asset(WAYSTONE,root,Vector3(112,0,11))
    _asset(ARCH,root,Vector3(139,0,0),PI/2,1.65)
    RETRO_DETAILS.make_supply_crate(root,Vector3(58.0,0,-13.5),.13,.73)
    RETRO_DETAILS.make_carved_waymarker(root,Vector3(105.0,0,-32.0),-.18,.97,true)
    _asset(VILLAGE_SIGN, root, Vector3(56.0,0.0,7.8), 1.57, .92)
    _add_village_banner(root, Vector3(101.0,0.0,22.5), Color(.17,.40,.18), .0, 4.2)
    _add_village_banner(root, Vector3(116.0,0.0,-8.0), Color(.19,.33,.51), .0, 4.0)
    _asset(VILLAGE_BARREL, root, Vector3(107.2,0.0,20.0), .0, .75)
    _retro_wildflowers(root, Vector3(88,0,0), Vector2(39,33), 170, Color(.64,.71,.37), 2801)
    _stage35_world_presentation(root, "wildwood")

func _build_cavern() -> void:
    var root := _new_zone("03_Hollow_Ruins")
    _ground(root,Vector3(173,0,0),Vector2(70,67),Color(0.27,0.29,0.31),"basalt")
    _ground(root,Vector3(173,0,0),Vector2(67,8),Color(0.45,0.45,0.45),"stone")
    # Cave boulders are now rendered by the GPU-instanced rock fields.
    _asset(RUINS,root,Vector3(162,0,-13),0.3,1.0)
    _asset(SHRINE,root,shrine_position,0.0,1.0)
    _asset(WAYSTONE,root,beacon_anchors[2],0,0.8)
    _asset(RUINS,root,Vector3(195,0,12),-0.5,1.3)
    RETRO_DETAILS.make_carved_waymarker(root,Vector3(162.0,0,23.0),.34,1.05,true)
    RETRO_DETAILS.make_carved_waymarker(root,Vector3(187.2,0,-24.0),-.44,.88)
    var light := OmniLight3D.new()
    light.position = shrine_position + Vector3(0,4,0)
    light.light_color = Color(0.31,0.80,0.93)
    light.light_energy = 1.8
    light.omni_range = 19.0
    light.shadow_enabled = false
    root.add_child(light)
    _asset(VILLAGE_SIGN, root, Vector3(150.0,0.0,-2.4), 1.57, .85)
    _add_village_banner(root, Vector3(184.5,0.0,8.8), Color(.42,.18,.48), .0, 4.2)
    _asset(VILLAGE_BARREL, root, Vector3(170.4,0.0,10.2), .2, .72)
    _retro_wildflowers(root, Vector3(173,0,0), Vector2(26,24), 76, Color(.61,.59,.51), 2802)
    _stage35_world_presentation(root, "ruins")

func _build_echo_valley() -> void:
    # Reuse the existing GLB kit and stone materials; no new external assets.
    # The old ruin ground overlaps the new valley floor near x=204 so passage is continuous.
    var root := _new_zone("04_Valley_Of_Echoes")
    _ground(root,Vector3(253,0,0),Vector2(101,86),Color(.23,.29,.39),"basalt")
    _ground(root,Vector3(254,0,0),Vector2(97,9),Color(.50,.50,.57),"stone")
    _add_forest_leaf_litter(root,Rect2(Vector2(213,-36),Vector2(76,72)),100,31192)
    _ground(root,Vector3(249,0,12),Vector2(9,32),Color(.42,.43,.52),"stone")
    _asset(ARCH,root,Vector3(209,0,0),PI/2,1.55)
    _asset(RUINS,root,Vector3(236,0,-30),.55,1.2)
    _asset(RUINS,root,Vector3(270,0,32),-.35,1.2)
    _asset(MOON_ALTAR,root,echo_altar_pos,0.0,1.1)
    RETRO_DETAILS.make_carved_waymarker(root,Vector3(241.0,0,-29.0),-.3,.93,true)
    RETRO_DETAILS.make_supply_crate(root,Vector3(258.0,0,33.0),.2,.74)
    for i in range(14):
        var pos := Vector3(214.0+float((i*19)%84),0.0,(-35.0 if i%2==0 else 34.0)+float(i%3)*1.3)
        _asset(SILVER_BIRCH if i%3==0 else ROCK,root,pos,float(i)*.66,.8+float(i%4)*.12)
    for i in range(echo_glyph_positions.size()):
        var marker := Node3D.new()
        marker.name = "Echo_Glyph_%d" % (i+1)
        marker.position = echo_glyph_positions[i]
        root.add_child(marker)
        var foot := MeshInstance3D.new()
        var platform := CylinderMesh.new()
        platform.top_radius = 1.55
        platform.bottom_radius = 1.70
        platform.height = .35
        foot.mesh = platform
        foot.position.y = .07
        var stone_mat := StandardMaterial3D.new()
        stone_mat.albedo_color = Color(.24,.28,.36)
        stone_mat.roughness = .82
        foot.material_override = stone_mat
        marker.add_child(foot)
        var ring := MeshInstance3D.new()
        var band := TorusMesh.new()
        band.inner_radius = 1.34
        band.outer_radius = 1.50
        band.rings = 6
        band.ring_segments = 28
        ring.mesh = band
        ring.position.y = .29
        var cyan := StandardMaterial3D.new()
        cyan.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        cyan.emission_enabled = true
        cyan.emission = Color(.20,.77,1.0)
        cyan.albedo_color = Color(.38,.84,1.0)
        ring.material_override = cyan
        marker.add_child(ring)
        var shard := MeshInstance3D.new()
        var crystal := SphereMesh.new()
        crystal.radius = .39
        crystal.height = 1.4
        crystal.radial_segments = 8
        crystal.rings = 4
        shard.mesh = crystal
        shard.position.y = 1.34
        shard.material_override = cyan
        marker.add_child(shard)
        var label := Label3D.new()
        label.name = "GlyphLabel"
        label.text = "✧ " + echo_glyph_names[i] + " | تفاعل"
        label.font_size = 28
        label.pixel_size = .007
        label.outline_size = 7
        label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        label.position.y = 2.8
        marker.add_child(label)
        echo_glyph_nodes.append(marker)
    echo_altar = Node3D.new()
    echo_altar.name = "Echo_Warden_Summoning_Altar"
    echo_altar.position = echo_altar_pos
    root.add_child(echo_altar)
    _asset(VILLAGE_SIGN, root, Vector3(221.0,0.0,2.4), 1.57, .92)
    _add_village_banner(root, Vector3(238.0,0.0,-22.0), Color(.43,.17,.44), .0, 4.3)
    _asset(VILLAGE_BARREL, root, Vector3(244.8,0.0,-24.0), .18, .80)
    _retro_wildflowers(root, Vector3(254,0,0), Vector2(40,32), 112, Color(.52,.55,.74), 2803)
    _stage35_world_presentation(root, "echo")
    var altar_ring := MeshInstance3D.new()
    var circle := TorusMesh.new()
    circle.inner_radius = 3.2
    circle.outer_radius = 3.40
    circle.rings = 8
    circle.ring_segments = 40
    altar_ring.mesh = circle
    altar_ring.position.y = .12
    var violet := StandardMaterial3D.new()
    violet.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    violet.emission_enabled = true
    violet.emission = Color(.55,.29,1.0)
    violet.albedo_color = Color(.70,.49,1.0)
    altar_ring.material_override = violet
    echo_altar.add_child(altar_ring)
    var altar_label := Label3D.new()
    altar_label.text = "مذبح الأصداء | 0/3"
    altar_label.font_size = 32
    altar_label.pixel_size = .007
    altar_label.outline_size = 8
    altar_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    altar_label.position.y = 3.65
    echo_altar.add_child(altar_label)
    var moonlight := OmniLight3D.new()
    moonlight.position.y = 3.5
    moonlight.light_color = Color(.54,.55,1.0)
    moonlight.light_energy = .85
    moonlight.omni_range = 12.0
    moonlight.shadow_enabled = false
    echo_altar.add_child(moonlight)
    _refresh_echo_markers()

func _play_echo_sfx(clip: AudioStream) -> void:
    if not is_instance_valid(echo_sound):
        return
    echo_sound.stop()
    echo_sound.stream = clip
    echo_sound.play()

func _echo_glyph_count() -> int:
    var count := 0
    for i in range(echo_glyph_positions.size()):
        if (echo_glyph_mask & (1 << i)) != 0:
            count += 1
    return count

func _refresh_echo_markers() -> void:
    for i in range(echo_glyph_nodes.size()):
        var lit := (echo_glyph_mask & (1 << i)) != 0
        var marker := echo_glyph_nodes[i]
        var ring := marker.get_child(1) as MeshInstance3D
        ring.visible = not lit
        var jewel := marker.get_child(2) as MeshInstance3D
        jewel.visible = not lit
        var label := marker.get_child(3) as Label3D
        label.text = ("✓ " if lit else "✧ ") + echo_glyph_names[i] + (" | مضيء" if lit else " | تفاعل")
    if is_instance_valid(echo_altar):
        var inscription := echo_altar.get_child(1) as Label3D
        if echo_rewarded:
            inscription.text = "وادي الأصداء | اكتمل الختم"
        elif echo_state == 2:
            inscription.text = "حارس الأصداء | استلم المكافأة"
        elif echo_state == 1:
            inscription.text = "حارس الأصداء | موجة %d/2" % echo_wave
        else:
            inscription.text = "مذبح الأصداء | %d/3 نقوش" % _echo_glyph_count()

func _echo_wave_size() -> int:
    return 2 if echo_wave == 1 else 1

func _restore_echo_wave() -> void:
    # Respawn ONLY fighters still alive according to durable kill counters.
    if echo_state != 1 or echo_wave not in [1,2]:
        return
    var living := 0
    for fighter in echo_fighters:
        if is_instance_valid(fighter) and not bool(fighter.get("dead")):
            living += 1
    var missing := maxi(0,_echo_wave_size()-echo_kills-living)
    for i in range(missing):
        var slot: int = echo_kills+living+i
        var kind := ("shade_hunter" if slot == 0 else "frost_wisp") if echo_wave == 1 else "echo_warden"
        var at := echo_altar_pos+Vector3((-9.0+float(slot)*12.0) if echo_wave==1 else 0.0,0.0,-9.0)
        var foe := _spawn(kind,at,echo_wave==2)
        foe.connect("defeated",_on_echo_fighter_defeated)
        echo_fighters.append(foe)

func _on_echo_fighter_defeated(_kind: String) -> void:
    if echo_state != 1:
        return
    echo_kills = mini(_echo_wave_size(),echo_kills+1)
    if echo_kills >= _echo_wave_size():
        echo_fighters.clear()
        if echo_wave == 1:
            echo_wave = 2
            echo_kills = 0
            _status("وادي الأصداء: ظهر حارس الأصداء! استعد لمواجهة الزعيم")
            _restore_echo_wave()
        else:
            echo_state = 2
            _status("هزمت حارس الأصداء! اقترب من المذبح لاستلام مكافأتك")
            _play_echo_sfx(ECHO_VICTORY)
    else:
        _status("وادي الأصداء: %d/%d من الحراس" % [echo_kills,_echo_wave_size()])
    _refresh_echo_markers()
    _save()

func _interact_echo_altar() -> void:
    if quest_stage < 5:
        _status("أكمل قصة قلب القمر أولًا حتى يستجيب مذبح الأصداء")
        return
    if echo_rewarded or echo_state == 3:
        _status("وادي الأصداء آمن، وقد استلمت مكافأته مسبقًا")
        return
    if echo_state == 0:
        if echo_glyph_mask != 7:
            _status("مذبح الأصداء: فعّل النقوش الثلاثة أولًا (%d/3)" % _echo_glyph_count())
            return
        echo_state = 1
        echo_wave = 1
        echo_kills = 0
        _restore_echo_wave()
        _play_echo_sfx(ECHO_CHIME)
        _status("بدأ دفاع الأصداء: قاتل صائد الظلال وروح الصقيع ثم الزعيم!")
    elif echo_state == 1:
        _restore_echo_wave()
        _status("وادي الأصداء: الموجة %d/2 — %d/%d مهزومين" % [echo_wave,echo_kills,_echo_wave_size()])
    elif echo_state == 2:
        # Mark the one-time claim *before* awarding level-ups or triggering a save.
        echo_rewarded = true
        echo_state = 3
        gold += 950
        potions += 5
        _gain_exp(650)
        _status("نقاء الأصداء! +950 ذهب +5 جرعات +650 خبرة وتعزيز دائم لسحر القمر")
    _refresh_echo_markers()
    _save()

func _equip_retro_sword(actor: Node3D, model: PackedScene, height_offset: float, angle: float) -> Node3D:
    # The motion pivot lets the sword swing with a pose without changing the
    # actor's imported mesh, hitboxes, attack damage, or AI.
    var pivot := Node3D.new()
    pivot.name = "Retro_Fantasy_Weapon_Pivot"
    pivot.position = Vector3(.41,height_offset,-.47)
    pivot.rotation_degrees = Vector3(9.0,14.0,angle)
    actor.add_child(pivot)
    pivot.set_meta("weapon_rest_position",pivot.position)
    pivot.set_meta("weapon_rest_rotation",pivot.rotation)
    # Original sword mesh grip is y=.30; child scale .72 -> local mount .216.
    pivot.set_meta("weapon_grip_offset",Vector3(0.0,.216,0.0))
    var sword := model.instantiate() as Node3D
    sword.name = "Retro_Fantasy_Equipped_Sword"
    sword.scale = Vector3.ONE * .72
    pivot.add_child(sword)
    return pivot

func _create_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Hero"
    player.collision_layer = 1
    player.collision_mask = 4
    player.floor_snap_length = 0.0
    add_child(player)
    player.position = Vector3(0,0,18)
    var collider := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.46
    capsule.height = 1.95
    collider.shape = capsule
    collider.position.y = 1.03
    player.add_child(collider)
    visual = _asset(HERO, player, Vector3.ZERO, PI)
    _apply_retro_character_finish(visual, Color(.66,.31,.18), .08)
    hero_rig_parts = RIG_DRIVER.get_parts(visual)
    STAGE36_CHARACTER_KIT.attach(visual, "hero")
    hero_weapon_mount = _equip_retro_sword(visual, MOONSTEEL_SWORD, 1.22, -31.0)
    _make_sword_arc()

func _make_companion() -> void:
    rayan_ally = CharacterBody3D.new()
    rayan_ally.set_script(COMPANION_SCRIPT)
    rayan_ally.name = "Rayan_Ally"
    add_child(rayan_ally)
    rayan_ally.call("setup",player,RAYAN,self)
    var ally_avatar: Variant = rayan_ally.get("avatar")
    if ally_avatar is Node3D:
        _apply_retro_character_finish(ally_avatar as Node3D, Color(.19,.55,.74), .09)
        STAGE36_CHARACTER_KIT.attach(ally_avatar as Node3D, "rayan")
        var ally_sword_mount: Node3D = _equip_retro_sword(ally_avatar as Node3D, RAYAN_SWORD, 1.25, 28.0)
        rayan_ally.call("set_weapon_mount",ally_sword_mount)

func _sync_companion() -> void:
    if is_instance_valid(rayan_ally):
        rayan_ally.call("set_enabled",companion_recruited and companion_active)
    if is_instance_valid(rayan_npc):
        rayan_npc.visible = not (companion_recruited and companion_active)

func _companion_strike() -> void:
    if not companion_recruited or companion_quest_rewarded:
        return
    companion_strikes = mini(3,companion_strikes+1)
    if companion_strikes == 3:
        companion_quest_rewarded = true
        gold += 180
        potions += 1
        _gain_exp(110)
        _status("اكتمل تدريب ريان! +180 ذهب +110 خبرة وجرعة علاج")
    else:
        _status("تدريب ريان في القتال: %d/3" % companion_strikes)
    _save()

func _companion_heal(amount: float) -> void:
    if not companion_active or health >= max_health:
        return
    health = minf(max_health,health+amount)
    _status("ريان عالجك أثناء القتال")

func _make_camera() -> void:
    camera_rig = Node3D.new()
    add_child(camera_rig)
    view_camera = Camera3D.new()
    view_camera.current = true
    view_camera.fov = 61.0
    view_camera.near = 0.1
    view_camera.far = 190.0
    camera_rig.add_child(view_camera)
    view_camera.position = Vector3(0,4.9,camera_distance)
    view_camera.rotation.x = cam_pitch

func _make_target_ring() -> void:
    target_ring = MeshInstance3D.new()
    var mesh := TorusMesh.new()
    mesh.inner_radius = 1.12
    mesh.outer_radius = 1.19
    mesh.rings = 8
    mesh.ring_segments = 32
    target_ring.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = Color(.31,.83,1.0,.88)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.emission_enabled = true
    mat.emission = Color(.16,.43,.83)
    target_ring.material_override = mat
    focus_ring_material = mat
    target_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    target_ring.visible = false
    add_child(target_ring)

func _focus_is_valid() -> bool:
    return focus_mode and is_instance_valid(focus_target) and not bool(focus_target.get("dead")) and player.position.distance_to(focus_target.position) < 32.0

func _focus_candidates() -> Array[Node3D]:
    var candidates: Array[Node3D] = []
    for enemy in enemies:
        if is_instance_valid(enemy) and not bool(enemy.get("dead")) and player.position.distance_to(enemy.position) < 28.0:
            candidates.append(enemy)
    return candidates

func _toggle_focus() -> void:
    if focus_mode:
        focus_mode = false
        focus_target = null
        _status("أوقفت تثبيت الهدف")
        _refresh_target_ring()
        return
    var closest: Node3D = null
    var best: float = 28.0
    for enemy in _focus_candidates():
        var distance: float = player.position.distance_to(enemy.position)
        if distance < best:
            best = distance
            closest = enemy
    if closest == null:
        _status("لا يوجد عدو قريب لتثبيت الهدف")
        return
    focus_mode = true
    focus_target = closest
    _status("تم تثبيت %s — Tab لتغيير العدو" % str(closest.get("display_name")))
    _refresh_target_ring()

func _cycle_focus() -> void:
    var available: Array[Node3D] = _focus_candidates()
    if available.is_empty():
        focus_mode = false
        focus_target = null
        _status("لا يوجد هدف قريب")
        return
    var idx: int = available.find(focus_target) if _focus_is_valid() else -1
    focus_target = available[(idx + 1) % available.size()]
    focus_mode = true
    _status("الهدف: %s" % str(focus_target.get("display_name")))
    _refresh_target_ring()

func _refresh_target_ring() -> void:
    if focus_mode and not _focus_is_valid():
        focus_mode = false
        focus_target = null
    var nearest: Node3D = focus_target if _focus_is_valid() else null
    var best: float = 14.0
    if nearest == null:
        for enemy in enemies:
            if not is_instance_valid(enemy) or bool(enemy.get("dead")):
                continue
            var dist: float = player.position.distance_to(enemy.position)
            if dist < best:
                nearest = enemy
                best = dist
    target_mark = nearest
    target_ring.visible = nearest != null
    if is_instance_valid(focus_ring_material):
        focus_ring_material.albedo_color = Color(1.0,.81,.22,.93) if focus_mode else Color(.31,.83,1.0,.88)
        focus_ring_material.emission = Color(.95,.48,.08) if focus_mode else Color(.16,.43,.83)
    if nearest != null:
        target_ring.position = nearest.position+Vector3(0,.08,0)
        var pulse: float = (1.0 + .055*sin(clock*7.0)) if focus_mode else 1.0
        target_ring.scale = Vector3.ONE*(1.85 if bool(nearest.get("is_boss")) else 1.0)*pulse

func _floating_damage(at: Vector3, points: int, stronger: bool = false) -> void:
    var label := Label3D.new()
    label.text = "-%d" % points
    label.font_size = 48 if stronger else 34
    label.pixel_size = 0.008
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.outline_size = 8
    label.modulate = Color(1.0,.72,.28) if stronger else Color(.76,.93,1.0)
    label.position = at+Vector3(0,2.6,0)
    add_child(label)
    var t := create_tween()
    t.set_parallel(true)
    t.tween_property(label,"position:y",label.position.y+1.1,.55)
    t.tween_property(label,"modulate:a",0.0,.55)
    t.set_parallel(false)
    t.tween_callback(label.queue_free)

func _build_moon_memories() -> void:
    # Six light-weight markers, assigned to the matching streaming zone.
    # Emissive surfaces avoid six additional dynamic lights on mobile GPUs.
    var glow := StandardMaterial3D.new()
    glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    glow.albedo_color = Color(0.54,0.79,1.0)
    glow.emission_enabled = true
    glow.emission = Color(0.18,0.55,1.0)
    glow.emission_energy_multiplier = 2.0
    var halo := StandardMaterial3D.new()
    halo.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    halo.albedo_color = Color(0.40,0.77,1.0)
    halo.emission_enabled = true
    halo.emission = Color(0.18,0.50,0.92)
    for i in range(moon_memory_positions.size()):
        var point: Vector3 = moon_memory_positions[i]
        var shard := Node3D.new()
        shard.name = "Moon_Memory_%02d" % (i+1)
        shard.position = point
        var zone_index := 0 if point.x < 40.0 else (1 if point.x < 140.0 else 2)
        zones[zone_index].add_child(shard)
        var diamond := MeshInstance3D.new()
        var gem := SphereMesh.new()
        gem.radius = 0.58
        gem.height = 1.35
        gem.radial_segments = 6
        gem.rings = 4
        diamond.mesh = gem
        diamond.material_override = glow
        diamond.position = Vector3(0,1.52,0)
        diamond.rotation.z = 0.22
        diamond.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        shard.add_child(diamond)
        var circle := MeshInstance3D.new()
        var circle_mesh := TorusMesh.new()
        circle_mesh.inner_radius = 0.91
        circle_mesh.outer_radius = 1.02
        circle_mesh.rings = 8
        circle_mesh.ring_segments = 24
        circle.mesh = circle_mesh
        circle.material_override = halo
        circle.position.y = 0.08
        circle.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        shard.add_child(circle)
        var tag := Label3D.new()
        tag.name = "MemoryLabel"
        tag.text = "✦ ذكرى القمر %d/6 — تفاعل" % (i+1)
        tag.font_size = 25
        tag.pixel_size = 0.007
        tag.outline_size = 7
        tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        tag.position.y = 3.15
        shard.add_child(tag)
        moon_memory_nodes.append(shard)
    _refresh_moon_memories()

func _build_rift_arena() -> void:
    # Lightweight procedural marker. Always exists; it unlocks after the story.
    rift_marker = Node3D.new()
    rift_marker.name = "Moon_Rift_Trial_Arena"
    rift_marker.position = rift_center
    zones[2].add_child(rift_marker)
    var glow := StandardMaterial3D.new()
    glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    glow.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    glow.albedo_color = Color(.30,.66,1.0,.83)
    glow.emission_enabled = true
    glow.emission = Color(.16,.37,.91)
    for radius in [2.2,3.6]:
        var ring := MeshInstance3D.new()
        var mesh := TorusMesh.new()
        mesh.inner_radius = radius
        mesh.outer_radius = radius+0.13
        mesh.rings = 8
        mesh.ring_segments = 36
        ring.mesh = mesh
        ring.position.y = .09
        ring.material_override = glow
        ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        rift_marker.add_child(ring)
    var core := MeshInstance3D.new()
    var gem := SphereMesh.new()
    gem.radius = .58
    gem.height = 1.6
    gem.radial_segments = 8
    gem.rings = 5
    core.mesh = gem
    core.position.y = 1.35
    core.material_override = glow
    core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    rift_marker.add_child(core)
    var inscription := Label3D.new()
    inscription.text = "صدع القمر | تحدي الموجات الثلاث"
    inscription.font_size = 32
    inscription.pixel_size = 0.008
    inscription.outline_size = 8
    inscription.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    inscription.position.y = 3.4
    rift_marker.add_child(inscription)
    _refresh_rift_marker()

func _refresh_rift_marker() -> void:
    if not is_instance_valid(rift_marker):
        return
    rift_marker.visible = quest_stage >= 5 and not rift_rewarded
    if is_instance_valid(rift_marker.get_child(3)):
        var label: Label3D = rift_marker.get_child(3) as Label3D
        if rift_state == 1:
            label.text = "صدع القمر | الموجة %d/3" % rift_wave
        elif rift_state == 2:
            label.text = "صدع القمر | استلم مكافأتك"
        else:
            label.text = "صدع القمر | ابدأ تحدي الموجات"

func _rift_wave_size() -> int:
    return 1 if rift_wave == 3 else 2

func _restore_rift_wave() -> void:
    if rift_state != 1 or rift_wave < 1 or rift_wave > 3:
        return
    # Only restore missing foes; prevents duplicate wave spawns on multiple calls.
    var live := 0
    for unit in rift_nodes:
        if is_instance_valid(unit) and not bool(unit.get("dead")):
            live += 1
    var remaining: int = maxi(0,_rift_wave_size()-rift_kills-live)
    for i in range(remaining):
        var slot: int = rift_kills+live+i
        var kind := "bramble" if rift_wave == 1 else ("wisp" if rift_wave == 2 else "rift_guardian")
        var place := rift_center+Vector3(-6.0+float(slot)*10.0,0.0,-8.0 if rift_wave != 3 else -6.0)
        var foe := _spawn(kind,place,rift_wave == 3)
        foe.connect("defeated",_on_rift_enemy_defeated)
        rift_nodes.append(foe)

func _on_rift_enemy_defeated(_kind: String) -> void:
    if rift_state != 1:
        return
    rift_kills = mini(_rift_wave_size(),rift_kills+1)
    if rift_kills >= _rift_wave_size():
        rift_nodes.clear()
        if rift_wave == 3:
            rift_state = 2
            _status("نجحت في تحدي صدع القمر! عد إلى البوابة لاستلام المكافأة")
        else:
            rift_wave += 1
            rift_kills = 0
            _status("تحدي صدع القمر: بدأت الموجة %d من 3" % rift_wave)
            _restore_rift_wave()
    else:
        _status("صدع القمر: هزمت %d من %d" % [rift_kills,_rift_wave_size()])
    _refresh_rift_marker()
    _save()

func _interact_rift() -> void:
    if quest_stage < 5:
        _status("أكمل قصة قلب القمر لتفعيل الصدع")
        return
    if rift_rewarded or rift_state == 3:
        _status("أكملت تحدي صدع القمر واستلمت جائزته")
        return
    if rift_state == 0:
        rift_state = 1
        rift_wave = 1
        rift_kills = 0
        _restore_rift_wave()
        _status("بدأ تحدي صدع القمر! اهزم ثلاث موجات متتالية")
    elif rift_state == 1:
        _restore_rift_wave()
        _status("صدع القمر: الموجة %d/3 — %d/%d أعداء" % [rift_wave,rift_kills,_rift_wave_size()])
    elif rift_state == 2:
        rift_rewarded = true # set BEFORE XP to ensure exactly-once rewards
        rift_state = 3
        gold += 800
        potions += 4
        _gain_exp(500)
        _status("أكملت صدع القمر! +800 ذهب و4 جرعات و500 خبرة")
    _refresh_rift_marker()
    _save()

func _memory_count() -> int:
    var collected := 0
    for i in range(moon_memory_positions.size()):
        if (moon_memory_mask & (1 << i)) != 0:
            collected += 1
    return collected

func _refresh_moon_memories() -> void:
    for i in range(moon_memory_nodes.size()):
        if is_instance_valid(moon_memory_nodes[i]):
            moon_memory_nodes[i].visible = (moon_memory_mask & (1 << i)) == 0

func _collect_nearby_memory() -> bool:
    for i in range(moon_memory_positions.size()):
        if (moon_memory_mask & (1 << i)) != 0:
            continue
        if player.position.distance_to(moon_memory_positions[i]) > 3.5:
            continue
        moon_memory_mask |= (1 << i)
        _refresh_moon_memories()
        if _memory_count() == 6:
            _status("اكتملت ذكريات القمر الست! عد إلى لوحة لورا لاستلام الجائزة")
        else:
            _status("جمعت %s (%d/6)" % [moon_memory_names[i],_memory_count()])
        _save()
        return true
    return false

func _claim_memory_reward() -> void:
    if moon_memory_rewarded or _memory_count() < 6:
        return
    moon_memory_rewarded = true
    moon_memory_mask = 63
    gold += 520
    potions += 3
    max_health += 25.0
    health = max_health
    _gain_exp(250)
    _refresh_moon_memories()
    _status("لورا: استعدت ذكريات القمر! +520 ذهب و3 جرعات و25 صحة دائمة و250 خبرة")
    _save()

func _journal_text() -> String:
    var entries := PackedStringArray([
        "المهمة الأساسية — قلب القمر",
        _quest_text(),
        "العدو المهزوم: %d | المستوى: %d | نقاط الخبرة: %d" % [total_defeated,level,exp_points],
        "",
        "ذكريات القمر — مهمة الاستكشاف الجديدة",
        "جمعت: %d من 6" % _memory_count(),
        "المكافأة: 520 ذهب + 3 جرعات + 250 خبرة + 25 نقطة صحة دائمة",
        "ابحث عن البلورات الزرقاء في القرية والغابة والأطلال. اقترب واضغط تفاعل.",
        ""
    ])
    if moon_memory_rewarded:
        entries.append("✓ استعدت جميع الذكريات واستلمت المكافأة")
    elif _memory_count() == 6:
        entries.append("اكتملت المجموعة! عد إلى لوحة لورا بعد إنهاء القصة الأساسية")
    else:
        for i in range(moon_memory_positions.size()):
            entries.append(("✓ " if (moon_memory_mask & (1 << i)) != 0 else "◇ ") + moon_memory_names[i])
    entries.append("")
    entries.append("المهام الجانبية والتقدم")
    entries.append("أحجار الطريق: %d/3" % _beacon_count())
    entries.append("أنوار القمر: %d/3" % moon_lantern_step)
    entries.append("الأختام: %d/3 | الحراس: %d/2" % [_moon_seals_collected(),moon_seal_kills])
    entries.append("معبد القمر: %d/3 | %s" % [sanctuary_kills,"المكافأة مستلمة" if sanctuary_rewarded else "قيد العمل"])
    entries.append("ريان: %d/3 ضربات تدريب | %s" % [companion_strikes,"انضم" if companion_recruited else "لم ينضم بعد"])
    entries.append("حدادة الفجر: ترقية السيف %d/3" % smith_level)
    entries.append("")
    entries.append("صدع القمر — تحدي قتال اختياري بعد القصة")
    if rift_rewarded:
        entries.append("✓ اجتزت الموجات الثلاث واستلمت مكافأة 800 ذهب + 4 جرعات + 500 خبرة")
    elif rift_state == 2:
        entries.append("✓ انتصرت في الموجات الثلاث. عد إلى بوابة الصدع للمكافأة")
    elif rift_state == 1:
        entries.append("الموجة %d/3 — هزمت %d من %d في الموجة" % [rift_wave,rift_kills,_rift_wave_size()])
    else:
        entries.append("متاح بعد إنهاء القصة. ابحث عن الدائرة الزرقاء في الأطلال")
    entries.append("")
    entries.append("وادي الأصداء — التوسعة الجديدة شرق الأطلال")
    var echo_note := "بانتظارك"
    if echo_rewarded:
        echo_note = "اكتمل"
    elif echo_state == 2:
        echo_note = "جاهز للمكافأة"
    elif echo_state == 1:
        echo_note = "الموجة %d/2" % echo_wave
    entries.append("النقوش: %d/3 | حالة الحارس: %s" % [_echo_glyph_count(),echo_note])
    if echo_rewarded:
        entries.append("✓ مكافأة تم تسلّمها: 950 ذهب و5 جرعات و650 خبرة وتعزيز دائم لسحر القمر")
    elif echo_state == 1:
        entries.append("قاتل حراس الصدى: %d/%d في هذه الموجة" % [echo_kills,_echo_wave_size()])
    elif echo_glyph_mask != 7:
        for i in range(echo_glyph_positions.size()):
            entries.append(("✓ " if (echo_glyph_mask & (1 << i)) != 0 else "◇ ")+echo_glyph_names[i])
    else:
        entries.append("توجّه إلى المذبح الشرقي لبدء مواجهة حارس الأصداء أو استلام الجائزة")
    entries.append("وحوش الوادي: صائد الظلال سريع المراوغة، وروح الصقيع ذات الهجمات البعيدة")
    entries.append("أسلوب القتال: R / زر موجة = موجة القمر (35 سحر، 20 تحمل، كل 10 ثوانٍ)")
    entries.append("الصد المثالي [F]: عدد مرات النجاح %d | 16 تحمل، نافذة 0.32 ثانية، مواجهة العدو" % perfect_parries)
    return "\n".join(entries)

func _nearby_interaction_hint() -> String:
    for i in range(moon_memory_positions.size()):
        if (moon_memory_mask & (1 << i)) == 0 and player.position.distance_to(moon_memory_positions[i]) < 4.6:
            return "✦ تفاعل (E): اجمع ذكرى القمر — %s" % moon_memory_names[i]
    for i in range(echo_glyph_positions.size()):
        if (echo_glyph_mask & (1 << i)) == 0 and player.position.distance_to(echo_glyph_positions[i]) < 5.6:
            return "✧ تفاعل (E): نقش الوادي — %s" % echo_glyph_names[i]
    if player.position.distance_to(echo_altar_pos) < 6.6:
        return "☽ تفاعل (E): %s" % ("استلم مكافأة حارس الأصداء" if echo_state == 2 else "مذبح الأصداء")
    if player.position.distance_to(rift_center) < 6.3:
        return "☾ تفاعل (E): %s" % ("استلم مكافأة صدع القمر" if rift_state == 2 else "تحدي صدع القمر")
    if player.position.distance_to(smith_position) < 5.4:
        return "⚒ تفاعل (E): حدادة الفجر وترقية السيف"
    if player.position.distance_to(board_position) < 7.6:
        return "📜 تفاعل (E): لوحة لورا والمكافآت"
    if player.position.distance_to(shop_position) < 7.6:
        return "🧪 تفاعل (E): شراء جرعة علاج"
    if player.position.distance_to(rayan_spot) < 5.6:
        return "⚔ تفاعل (E): ريان الرفيق"
    for anchor in beacon_anchors:
        if player.position.distance_to(anchor) < 5.0:
            return "✦ تفاعل (E): حجر الطريق والحفظ"
    for place in moon_seal_places:
        if player.position.distance_to(place) < 5.0:
            return "◈ تفاعل (E): نقش القمر"
    if player.position.distance_to(moon_seal_altar_pos) < 6.2:
        return "◈ تفاعل (E): مذبح الأختام"
    if player.position.distance_to(sanctuary_center) < 7.0:
        return "🌙 تفاعل (E): معبد القمر"
    for place in moon_lantern_positions:
        if player.position.distance_to(place) < 5.0:
            return "✦ تفاعل (E): فانوس القمر"
    if player.position.distance_to(shrine_position) < 6.4:
        return "✦ تفاعل (E): المذبح البلوري"
    return ""

func _retro_panel_style(bg: Color, edge: Color, radius_value: int = 12) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.border_color = edge
    style.set_border_width_all(3)
    style.set_corner_radius_all(radius_value)
    style.shadow_color = Color(.02,.02,.02,.38)
    style.shadow_size = 3
    style.content_margin_left = 8.0
    style.content_margin_right = 8.0
    style.content_margin_top = 6.0
    style.content_margin_bottom = 6.0
    return style

func _retro_progress(bar: ProgressBar, tint: Color) -> void:
    var background := _retro_panel_style(Color(.075,.083,.088,.94),Color(.48,.48,.48,.95),7)
    background.set_content_margin_all(1.0)
    var fill := _retro_panel_style(tint, tint.lightened(.27),6)
    fill.set_content_margin_all(0.0)
    bar.add_theme_stylebox_override("background",background)
    bar.add_theme_stylebox_override("fill",fill)

func _style_aux_button(button: Button, tint: Color, radius_value: int = 11) -> void:
    button.add_theme_font_size_override("font_size", 16)
    button.add_theme_color_override("font_color", Color(1.0,.98,.93))
    button.add_theme_stylebox_override("normal", _retro_panel_style(tint, Color(.78,.76,.67), radius_value))
    button.add_theme_stylebox_override("hover", _retro_panel_style(tint.lightened(.13), Color(.93,.90,.79), radius_value))
    button.add_theme_stylebox_override("pressed", _retro_panel_style(tint.darkened(.18), Color(.66,.63,.57), radius_value))


func _new_button(text_value: String, act: Callable, parent: Control) -> Button:
    var b := Button.new()
    b.text = text_value
    b.custom_minimum_size = Vector2(70,70)
    b.add_theme_font_size_override("font_size",16)
    b.add_theme_color_override("font_color",Color(1.0,.98,.92))
    var tint := Color(.36,.44,.51,.96)
    if text_value.contains("ضربة"):
        tint = Color(.66,.24,.23,.98)
    elif text_value.contains("سحر"):
        tint = Color(.15,.46,.71,.98)
    elif text_value.contains("موجة"):
        tint = Color(.18,.53,.67,.98)
    elif text_value.contains("اندفاع"):
        tint = Color(.27,.49,.29,.98)
    elif text_value.contains("صد"):
        tint = Color(.40,.45,.54,.98)
    elif text_value.contains("علاج"):
        tint = Color(.38,.58,.34,.98)
    elif text_value.contains("تفاعل"):
        tint = Color(.59,.44,.23,.98)
    b.add_theme_stylebox_override("normal",_retro_panel_style(tint,Color(.70,.72,.68),14))
    b.add_theme_stylebox_override("hover",_retro_panel_style(tint.lightened(.15),Color(.91,.87,.72),14))
    b.add_theme_stylebox_override("pressed",_retro_panel_style(tint.darkened(.20),Color(.89,.82,.69),14))
    b.pressed.connect(act)
    parent.add_child(b)
    return b

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var base := Control.new()
    base.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    base.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(base)
    # F3 toggles a non-interactive technical overlay; hidden during ordinary play.
    stage41_debug_label = Label.new()
    stage41_debug_label.name = "Stage41_Performance_Debug_Overlay"
    stage41_debug_label.position = Vector2(15.0, 148.0)
    stage41_debug_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    stage41_debug_label.visible = false
    stage41_debug_label.add_theme_font_size_override("font_size", 15)
    stage41_debug_label.add_theme_color_override("font_color", Color(.91, .95, 1.0))
    stage41_debug_label.add_theme_color_override("font_outline_color", Color(.02,.03,.06))
    stage41_debug_label.add_theme_constant_override("outline_size", 5)
    base.add_child(stage41_debug_label)
    var left := PanelContainer.new()
    left.position = Vector2(122,14)
    left.custom_minimum_size = Vector2(257,0)
    left.add_theme_stylebox_override("panel",_retro_panel_style(Color(.08,.105,.13,.76),Color(.52,.53,.51,.92),11))
    base.add_child(left)
    stage51_stats_panel = left
    var portrait := TextureRect.new()
    portrait.name = "Retro_Hero_Portrait_From_Project_Mesh"
    portrait.texture = RETRO_HERO_PORTRAIT
    portrait.position = Vector2(10,17)
    portrait.size = Vector2(108,108)
    portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
    base.add_child(portrait)
    stage51_portrait = portrait
    var stats := VBoxContainer.new()
    left.add_child(stats)
    title_label = Label.new()
    title_label.text = "حارس الفجر | المستوى 1"
    title_label.add_theme_font_size_override("font_size",19)
    stats.add_child(title_label)
    for k in range(3):
        var b := ProgressBar.new()
        b.custom_minimum_size = Vector2(230,19)
        b.show_percentage = false
        _retro_progress(b,[Color(.84,.18,.18),Color(.11,.47,.78),Color(.88,.87,.76)][k])
        stats.add_child(b)
        if k==0: hp_bar = b
        elif k==1: mp_bar = b
        else: stamina_bar = b
    boss_hp_label = Label.new()
    boss_hp_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    boss_hp_label.text = "حارس البازلت"
    boss_hp_label.visible = false
    stats.add_child(boss_hp_label)
    boss_hp_bar = ProgressBar.new()
    boss_hp_bar.custom_minimum_size = Vector2(244,16)
    boss_hp_bar.show_percentage = false
    boss_hp_bar.visible = false
    stats.add_child(boss_hp_bar)
    boss_attack_label = Label.new()
    boss_attack_label.name = "Stage50_Boss_Attack_Warning"
    boss_attack_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    boss_attack_label.add_theme_font_size_override("font_size", 15)
    boss_attack_label.add_theme_color_override("font_color", Color(1.0,.74,.46))
    boss_attack_label.visible = false
    stats.add_child(boss_attack_label)
    boss_attack_bar = ProgressBar.new()
    boss_attack_bar.name = "Stage50_Boss_Attack_Charge"
    boss_attack_bar.custom_minimum_size = Vector2(244, 12)
    boss_attack_bar.max_value = 100.0
    boss_attack_bar.show_percentage = false
    _retro_progress(boss_attack_bar, Color(.96,.55,.20))
    boss_attack_bar.visible = false
    stats.add_child(boss_attack_bar)
    companion_focus_label = Label.new()
    companion_focus_label.name = "Stage50_Ally_Target_Readout"
    companion_focus_label.add_theme_font_size_override("font_size", 13)
    companion_focus_label.add_theme_color_override("font_color", Color(.56,.90,.65))
    companion_focus_label.visible = false
    stats.add_child(companion_focus_label)
    focus_label = Label.new()
    focus_label.visible = false
    focus_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    focus_label.add_theme_font_size_override("font_size",15)
    stats.add_child(focus_label)
    focus_hp_bar = ProgressBar.new()
    focus_hp_bar.custom_minimum_size = Vector2(244,13)
    focus_hp_bar.show_percentage = false
    focus_hp_bar.visible = false
    stats.add_child(focus_hp_bar)
    var objective_box := PanelContainer.new()
    objective_box.set_anchors_preset(Control.PRESET_TOP_WIDE)
    objective_box.offset_left = 396
    objective_box.offset_top = 14
    objective_box.offset_right = -260
    objective_box.offset_bottom = 83
    objective_box.add_theme_stylebox_override("panel",_retro_panel_style(Color(.14,.15,.17,.77),Color(.59,.56,.47,.82),12))
    base.add_child(objective_box)
    stage51_objective_panel = objective_box
    quest_label = Label.new()
    quest_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    quest_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    quest_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    quest_label.add_theme_font_size_override("font_size",18)
    objective_box.add_child(quest_label)
    # Stage 15: unobtrusive navigator stays in the corner on both desktop and touch.
    var map_panel := PanelContainer.new()
    map_panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    map_panel.offset_left = -246
    map_panel.offset_top = 10
    map_panel.offset_right = -12
    map_panel.offset_bottom = 166
    map_panel.add_theme_stylebox_override("panel",_retro_panel_style(Color(.07,.12,.12,.82),Color(.45,.52,.48,.88),12))
    base.add_child(map_panel)
    stage51_map_panel = map_panel
    var map_stack := VBoxContainer.new()
    map_stack.add_theme_constant_override("separation", 2)
    map_panel.add_child(map_stack)
    var map_heading := Label.new()
    map_heading.text = "🧭 خريطة الطريق"
    map_heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    map_heading.add_theme_font_size_override("font_size", 15)
    map_stack.add_child(map_heading)
    stage51_map_heading = map_heading
    navigation_map = Control.new()
    navigation_map.set_script(MINIMAP_SCRIPT)
    navigation_map.set("director",self)
    navigation_map.custom_minimum_size = Vector2(218,100)
    navigation_map.mouse_filter = Control.MOUSE_FILTER_IGNORE
    map_stack.add_child(navigation_map)
    navigation_label = Label.new()
    navigation_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    navigation_label.add_theme_font_size_override("font_size",14)
    map_stack.add_child(navigation_label)
    var joystick := TextureRect.new()
    joystick.texture = RETRO_JOYSTICK
    joystick.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    joystick.stretch_mode = TextureRect.STRETCH_SCALE
    joystick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    joystick.offset_left = 28
    joystick.offset_top = -178
    joystick.offset_right = 180
    joystick.offset_bottom = -24
    joystick.mouse_filter = Control.MOUSE_FILTER_IGNORE
    base.add_child(joystick)
    stage51_joystick = joystick
    joystick_puck = TextureRect.new()
    joystick_puck.texture = RETRO_PUCK
    joystick_puck.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    joystick_puck.stretch_mode = TextureRect.STRETCH_SCALE
    joystick_puck.position = Vector2(51,51)
    joystick_puck.size = Vector2(50,50)
    joystick_puck.mouse_filter = Control.MOUSE_FILTER_IGNORE
    joystick.add_child(joystick_puck)
    var controls := GridContainer.new()
    controls.columns = 8
    controls.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    controls.offset_left = -630
    controls.offset_top = -105
    controls.offset_right = -18
    controls.offset_bottom = -15
    controls.add_theme_constant_override("h_separation",5)
    controls.add_theme_constant_override("v_separation",5)
    base.add_child(controls)
    stage51_action_grid = controls
    _new_button("⚔\nضربة",_attack,controls)
    _new_button("✦\nسحر",_spell,controls)
    _new_button("☾\nموجة",_lunar_burst,controls)
    _new_button("➜\nاندفاع",_dodge,controls)
    _new_button("◈\nصد",_parry,controls)
    _new_button("✚\nعلاج",_heal,controls)
    _new_button("☷\nتفاعل",_interact,controls)
    _new_button("⚙",_cycle_resolution,controls)
    lunar_burst_label = Label.new()
    lunar_burst_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    lunar_burst_label.add_theme_font_size_override("font_size",16)
    stats.add_child(lunar_burst_label)
    guard_label = Label.new()
    guard_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    guard_label.add_theme_font_size_override("font_size",15)
    stats.add_child(guard_label)
    interaction_label = Label.new()
    interaction_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    interaction_label.offset_left = -340
    interaction_label.offset_right = 340
    interaction_label.offset_top = -222
    interaction_label.offset_bottom = -182
    interaction_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    interaction_label.add_theme_font_size_override("font_size",18)
    interaction_label.add_theme_color_override("font_color",Color(.80,.97,1.0))
    base.add_child(interaction_label)
    message_label = Label.new()
    message_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    message_label.offset_left = -345
    message_label.offset_right = 345
    message_label.offset_top = -162
    message_label.offset_bottom = -113
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size",20)
    base.add_child(message_label)
    var top_menu_button := Button.new()
    top_menu_button.text = "☰ إيقاف"
    top_menu_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    top_menu_button.offset_left = -132
    top_menu_button.offset_top = 174
    top_menu_button.offset_right = -12
    top_menu_button.offset_bottom = 218
    _style_aux_button(top_menu_button, Color(.35,.34,.42,.95), 11)
    top_menu_button.pressed.connect(_toggle_pause)
    base.add_child(top_menu_button)
    stage51_menu_button = top_menu_button
    var journal_button := Button.new()
    journal_button.text = "📜 سجل"
    journal_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    journal_button.offset_left = -132
    journal_button.offset_top = 226
    journal_button.offset_right = -12
    journal_button.offset_bottom = 270
    _style_aux_button(journal_button, Color(.47,.36,.21,.95), 11)
    journal_button.pressed.connect(_toggle_journal)
    base.add_child(journal_button)
    stage51_journal_button = journal_button
    # Separate focus controls to avoid squeezing the existing eight combat buttons.
    focus_button = Button.new()
    focus_button.text = "◎ تثبيت [T]"
    focus_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    focus_button.offset_left = -148
    focus_button.offset_right = -12
    focus_button.offset_top = 278
    focus_button.offset_bottom = 322
    _style_aux_button(focus_button, Color(.19,.46,.60,.96), 11)
    focus_button.pressed.connect(_toggle_focus)
    base.add_child(focus_button)
    focus_next_button = Button.new()
    focus_next_button.text = "⇄ هدف آخر"
    focus_next_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    focus_next_button.offset_left = -148
    focus_next_button.offset_right = -12
    focus_next_button.offset_top = 330
    focus_next_button.offset_bottom = 374
    _style_aux_button(focus_next_button, Color(.22,.51,.31,.96), 11)
    focus_next_button.pressed.connect(_cycle_focus)
    base.add_child(focus_next_button)
    # The large green mission/interact orb in the screenshot is an actual action button.
    var quest_orb := Button.new()
    quest_orb.name = "Retro_Green_Interact_Orb"
    quest_orb.text = "!"
    quest_orb.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    quest_orb.offset_left = -117
    quest_orb.offset_right = -23
    quest_orb.offset_top = 390
    quest_orb.offset_bottom = 484
    quest_orb.add_theme_font_size_override("font_size",59)
    quest_orb.add_theme_color_override("font_color",Color(.96,1.0,.90))
    quest_orb.add_theme_stylebox_override("normal",_retro_panel_style(Color(.13,.63,.15,.93),Color(.68,.76,.70),47))
    quest_orb.add_theme_stylebox_override("hover",_retro_panel_style(Color(.25,.80,.18,.97),Color(.9,.94,.86),47))
    quest_orb.add_theme_stylebox_override("pressed",_retro_panel_style(Color(.11,.47,.09,.98),Color(.55,.64,.58),47))
    quest_orb.pressed.connect(_interact)
    base.add_child(quest_orb)
    stage51_interact_button = quest_orb
    _build_pause_menu(layer)
    get_viewport().size_changed.connect(_stage51_update_layout)
    _stage51_update_layout()
    _refresh_hud()

# Stage 51 mobile landscape HUD: keep 8 actions available without covering
# the 152px movement stick or the green mission/interact button.
# The reference resolution is 1280x720; this also adapts to resized desktop windows.
func _stage51_update_layout() -> void:
    if not is_instance_valid(stage51_action_grid):
        return
    var screen: Vector2 = Vector2(get_viewport().get_visible_rect().size)
    if screen.x < 480.0 or screen.y < 320.0:
        return # unsupported portrait/tiny debugging window; leave current layout.
    stage51_compact_layout = OS.has_feature("mobile") or screen.x < 1120.0 or screen.y < 650.0
    var short_screen: bool = stage51_compact_layout and screen.y < 500.0
    if stage51_compact_layout:
        stage51_action_grid.columns = 4
        stage51_action_grid.offset_left = -328.0
        stage51_action_grid.offset_right = -14.0
        stage51_action_grid.offset_top = -144.0 if short_screen else -172.0
        stage51_action_grid.offset_bottom = -8.0 if short_screen else -12.0
        # Keep all 8 combat, heal, interaction, and quality functions accessible.
        for action in stage51_action_grid.get_children():
            if action is Button:
                action.custom_minimum_size = Vector2(62,62) if short_screen else Vector2(72,72)
                action.add_theme_font_size_override("font_size",13 if short_screen else 14)
        stage51_joystick.offset_left = 16.0
        stage51_joystick.offset_top = -148.0 if short_screen else -172.0
        stage51_joystick.offset_right = 156.0 if short_screen else 168.0
        stage51_joystick.offset_bottom = -8.0 if short_screen else -20.0
        stage51_portrait.position = Vector2(8,12)
        stage51_portrait.size = Vector2(86,86)
        stage51_stats_panel.position = Vector2(94,12)
        stage51_stats_panel.custom_minimum_size = Vector2(244,0)
        stage51_map_panel.offset_left = -181.0
        stage51_map_panel.offset_right = -12.0
        stage51_map_panel.offset_top = 12.0
        stage51_map_panel.offset_bottom = 145.0
        # On extra-short landscape screens, use the Journal instead of a tall minimap.
        stage51_map_panel.visible = screen.y >= 420.0
        navigation_map.custom_minimum_size = Vector2(143,73)
        stage51_map_heading.add_theme_font_size_override("font_size",12)
        navigation_label.add_theme_font_size_override("font_size",12)
        stage51_objective_panel.offset_left = 350.0
        stage51_objective_panel.offset_right = -192.0
        stage51_objective_panel.offset_top = 13.0
        stage51_objective_panel.offset_bottom = 91.0
        stage51_objective_panel.visible = screen.x >= 760.0
        quest_label.add_theme_font_size_override("font_size",14)
        quest_label.max_lines_visible = 3
        # Compact utility strip below minimap; action grid begins near bottom.
        stage51_menu_button.offset_left = -184.0
        stage51_menu_button.offset_right = -99.0
        stage51_menu_button.offset_top = 14.0 if screen.y < 420.0 else 150.0
        stage51_menu_button.offset_bottom = 56.0 if screen.y < 420.0 else (192.0 if short_screen else 197.0)
        stage51_journal_button.offset_left = -94.0
        stage51_journal_button.offset_right = -12.0
        stage51_journal_button.offset_top = 14.0 if screen.y < 420.0 else 150.0
        stage51_journal_button.offset_bottom = 56.0 if screen.y < 420.0 else (192.0 if short_screen else 197.0)
        focus_button.offset_left = -184.0
        focus_button.offset_right = -99.0
        focus_button.offset_top = 64.0 if screen.y < 420.0 else (197.0 if short_screen else 205.0)
        focus_button.offset_bottom = 108.0 if screen.y < 420.0 else (240.0 if short_screen else 251.0)
        focus_next_button.offset_left = -94.0
        focus_next_button.offset_right = -12.0
        focus_next_button.offset_top = 64.0 if screen.y < 420.0 else (197.0 if short_screen else 205.0)
        focus_next_button.offset_bottom = 108.0 if screen.y < 420.0 else (240.0 if short_screen else 251.0)
        focus_button.add_theme_font_size_override("font_size",13)
        focus_next_button.add_theme_font_size_override("font_size",13)
        focus_button.text = "◎ هدف" if not _focus_is_valid() else "◎ إلغاء"
        focus_next_button.text = "⇄ التالي"
        # The regular action grid already includes Interact, so compact short
        # phones can safely hide the redundant large orb to avoid overlap.
        stage51_interact_button.visible = not short_screen
        stage51_interact_button.offset_left = -94.0
        stage51_interact_button.offset_right = -14.0
        stage51_interact_button.offset_top = 265.0
        stage51_interact_button.offset_bottom = 341.0
        stage51_interact_button.add_theme_font_size_override("font_size",42)
        # Hide long quest text only when the screen is too narrow for a legible column.
        interaction_label.offset_left = -215.0
        interaction_label.offset_right = 215.0
        interaction_label.add_theme_font_size_override("font_size",14)
        message_label.offset_left = -230.0
        message_label.offset_right = 230.0
        message_label.add_theme_font_size_override("font_size",16)
    else:
        stage51_action_grid.columns = 8
        stage51_action_grid.offset_left = -630.0
        stage51_action_grid.offset_top = -105.0
        stage51_action_grid.offset_right = -18.0
        stage51_action_grid.offset_bottom = -15.0
        for action in stage51_action_grid.get_children():
            if action is Button:
                action.custom_minimum_size = Vector2(70,70)
                action.add_theme_font_size_override("font_size",16)
        stage51_joystick.offset_left = 28.0
        stage51_joystick.offset_top = -178.0
        stage51_joystick.offset_right = 180.0
        stage51_joystick.offset_bottom = -24.0
        stage51_portrait.position = Vector2(10,17)
        stage51_portrait.size = Vector2(108,108)
        stage51_stats_panel.position = Vector2(122,14)
        stage51_stats_panel.custom_minimum_size = Vector2(257,0)
        stage51_map_panel.offset_left = -246.0
        stage51_map_panel.offset_top = 10.0
        stage51_map_panel.offset_right = -12.0
        stage51_map_panel.offset_bottom = 166.0
        stage51_map_panel.visible = true
        navigation_map.custom_minimum_size = Vector2(218,100)
        stage51_map_heading.add_theme_font_size_override("font_size",15)
        navigation_label.add_theme_font_size_override("font_size",14)
        stage51_objective_panel.offset_left = 396.0
        stage51_objective_panel.offset_right = -260.0
        stage51_objective_panel.offset_top = 14.0
        stage51_objective_panel.offset_bottom = 83.0
        stage51_objective_panel.visible = true
        quest_label.max_lines_visible = -1
        quest_label.add_theme_font_size_override("font_size",18)
        stage51_menu_button.offset_left = -132.0
        stage51_menu_button.offset_right = -12.0
        stage51_menu_button.offset_top = 174.0
        stage51_menu_button.offset_bottom = 218.0
        stage51_journal_button.offset_left = -132.0
        stage51_journal_button.offset_right = -12.0
        stage51_journal_button.offset_top = 226.0
        stage51_journal_button.offset_bottom = 270.0
        focus_button.offset_left = -148.0
        focus_button.offset_right = -12.0
        focus_button.offset_top = 278.0
        focus_button.offset_bottom = 322.0
        focus_next_button.offset_left = -148.0
        focus_next_button.offset_right = -12.0
        focus_next_button.offset_top = 330.0
        focus_next_button.offset_bottom = 374.0
        focus_button.add_theme_font_size_override("font_size",16)
        focus_next_button.add_theme_font_size_override("font_size",16)
        focus_button.text = "◎ تثبيت [T]"
        focus_next_button.text = "⇄ هدف آخر"
        stage51_interact_button.visible = true
        stage51_interact_button.offset_left = -117.0
        stage51_interact_button.offset_right = -23.0
        stage51_interact_button.offset_top = 390.0
        stage51_interact_button.offset_bottom = 484.0
        stage51_interact_button.add_theme_font_size_override("font_size",59)
        interaction_label.offset_left = -340.0
        interaction_label.offset_right = 340.0
        interaction_label.add_theme_font_size_override("font_size",18)
        message_label.offset_left = -345.0
        message_label.offset_right = 345.0
        message_label.add_theme_font_size_override("font_size",20)
    # Menu panels always fit inside the logical safe height and can scroll.
    var panel_half_h: float = minf(333.0,screen.y*.43)
    var panel_half_w: float = minf(228.0,screen.x*.42)
    pause_settings_panel.offset_left = -panel_half_w
    pause_settings_panel.offset_right = panel_half_w
    pause_settings_panel.offset_top = -panel_half_h
    pause_settings_panel.offset_bottom = panel_half_h
    var journal_half_h: float = minf(275.0,screen.y*.43)
    var journal_half_w: float = minf(295.0,screen.x*.42)
    journal_panel.offset_left = -journal_half_w
    journal_panel.offset_right = journal_half_w
    journal_panel.offset_top = -journal_half_h
    journal_panel.offset_bottom = journal_half_h

func _build_pause_menu(layer: CanvasLayer) -> void:
    pause_root = Control.new()
    pause_root.name = "PauseOverlay"
    pause_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    pause_root.process_mode = Node.PROCESS_MODE_ALWAYS
    pause_root.mouse_filter = Control.MOUSE_FILTER_STOP
    pause_root.set_script(PAUSE_INPUT_SCRIPT)
    pause_root.set("director",self)
    pause_root.visible = false
    layer.add_child(pause_root)
    var shade := ColorRect.new()
    shade.color = Color(.025,.055,.09,.83)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    pause_root.add_child(shade)
    var panel := PanelContainer.new()
    panel.set_anchors_preset(Control.PRESET_CENTER)
    panel.offset_left = -228
    panel.offset_right = 228
    panel.offset_top = -333
    panel.offset_bottom = 333
    pause_root.add_child(panel)
    pause_settings_panel = panel
    # Scrolling avoids cutting off Save/Resume on shorter landscape phones.
    var scroll := ScrollContainer.new()
    scroll.name = "Stage51_PauseScroll"
    scroll.set_deferred("horizontal_scroll_mode", ScrollContainer.SCROLL_MODE_DISABLED)
    panel.add_child(scroll)
    var items := VBoxContainer.new()
    items.add_theme_constant_override("separation", 8)
    items.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(items)
    var heading := Label.new()
    heading.text = "🌙 أسطورة القمر المكسور"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size",25)
    items.add_child(heading)
    var subtitle := Label.new()
    subtitle.text = "اللعبة متوقفة مؤقتًا"
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    items.add_child(subtitle)
    pause_quality_label = Label.new()
    pause_quality_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    items.add_child(pause_quality_label)
    var resume := _new_button("▶ متابعة اللعب",_toggle_pause,items)
    resume.custom_minimum_size.y = 49
    var save_button := _new_button("💾 حفظ التقدم الآن",_pause_save,items)
    save_button.custom_minimum_size.y = 49
    var graphics := _new_button("⚙ تغيير دقة العرض",_pause_quality,items)
    graphics.custom_minimum_size.y = 49
    var adaptive := _new_button("◈ تبديل ضبط الجودة التلقائي",_pause_adaptive,items)
    adaptive.custom_minimum_size.y = 49
    var camera_effects := _new_button("◈ تبديل اهتزاز الكاميرا",_pause_camera_feedback,items)
    camera_effects.custom_minimum_size.y = 45
    var atmosphere_button := _new_button("☾ تبديل أجواء القمر والضباب",_pause_atmosphere,items)
    atmosphere_button.custom_minimum_size.y = 45
    var journal := _new_button("📜 سجل المهمات (L)",_toggle_journal,items)
    journal.custom_minimum_size.y = 49
    var help := Label.new()
    help.text = "WASD للحركة · زر الفأرة الأيمن للكاميرا\nJ/Space للضرب · F للصد · Shift للمراوغة\nQ للسحر · R للموجة · H للعلاج\nT تثبيت العدو · Tab تغيير الهدف\nE للتفاعل · L للسجل · P/Esc للإيقاف"
    help.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    help.add_theme_font_size_override("font_size",14)
    items.add_child(help)
    pause_info_label = Label.new()
    pause_info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    pause_info_label.add_theme_font_size_override("font_size",14)
    items.add_child(pause_info_label)
    journal_panel = PanelContainer.new()
    journal_panel.set_anchors_preset(Control.PRESET_CENTER)
    journal_panel.offset_left = -295
    journal_panel.offset_right = 295
    journal_panel.offset_top = -275
    journal_panel.offset_bottom = 275
    journal_panel.visible = false
    pause_root.add_child(journal_panel)
    var journal_stack := VBoxContainer.new()
    journal_stack.add_theme_constant_override("separation",8)
    journal_panel.add_child(journal_stack)
    var journal_title := Label.new()
    journal_title.text = "📜 سجل المهمات — أسطورة القمر المكسور"
    journal_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    journal_title.add_theme_font_size_override("font_size",22)
    journal_stack.add_child(journal_title)
    journal_text = RichTextLabel.new()
    journal_text.custom_minimum_size = Vector2(0,240)
    journal_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
    journal_text.scroll_active = true
    journal_text.add_theme_font_size_override("normal_font_size",18)
    journal_stack.add_child(journal_text)
    var back := _new_button("← العودة إلى القائمة",_toggle_journal,journal_stack)
    back.custom_minimum_size.y = 42
    var continue_button := _new_button("▶ متابعة اللعب",_toggle_pause,journal_stack)
    continue_button.custom_minimum_size.y = 42

func _set_journal_page(visible_journal: bool) -> void:
    journal_open = visible_journal
    if is_instance_valid(pause_settings_panel):
        pause_settings_panel.visible = not visible_journal
    if is_instance_valid(journal_panel):
        journal_panel.visible = visible_journal
    if visible_journal and is_instance_valid(journal_text):
        journal_text.text = _journal_text()

func _toggle_journal() -> void:
    if not get_tree().paused:
        _toggle_pause()
        _set_journal_page(true)
    else:
        _set_journal_page(not journal_open)

func _refresh_pause_details() -> void:
    if is_instance_valid(pause_quality_label):
        pause_quality_label.text = "الدقة: %d%% | التلقائي: %s | الاهتزاز: %s\nأجواء القمر: %s" % [roundi(mobile_resolution_scale*100.0),"مفعل" if adaptive_enabled else "متوقف","مفعل" if camera_feedback_enabled else "متوقف","مفعلة" if atmosphere_enabled else "متوقفة"]

func _toggle_pause() -> void:
    var now_paused: bool = not get_tree().paused
    if now_paused:
        touch_move = Vector2.ZERO
        move_touch = -1
        cam_touch = -1
        joystick_puck.position = Vector2(51,51)
        pause_info_label.text = "يمكنك حفظ اللعبة وتغيير الجودة هنا"
        _refresh_pause_details()
        _set_journal_page(false)
        pause_root.visible = true
        get_tree().paused = true
    else:
        get_tree().paused = false
        pause_root.visible = false
        _set_journal_page(false)

func _pause_save() -> void:
    pause_info_label.text = "✓ تم حفظ التقدم" if _save() else "تعذر حفظ التقدم، تحقق من مساحة التخزين"

func _pause_quality() -> void:
    _cycle_resolution()
    _refresh_pause_details()
    pause_info_label.text = "تم تعديل دقة العرض"
    _save()

func _pause_adaptive() -> void:
    adaptive_enabled = not adaptive_enabled
    _refresh_pause_details()
    pause_info_label.text = "تم تحديث إعداد الضبط التلقائي"
    _save()

func _pause_camera_feedback() -> void:
    camera_feedback_enabled = not camera_feedback_enabled
    camera_impact = 0.0
    _refresh_pause_details()
    if is_instance_valid(pause_info_label):
        pause_info_label.text = "يمكنك تعطيل اهتزاز الكاميرا إن كان مزعجًا"
    _save()

func _pause_atmosphere() -> void:
    atmosphere_enabled = not atmosphere_enabled
    _update_lighting()
    _refresh_pause_details()
    pause_info_label.text = "تم تحديث إضاءة السماء والضباب والجزيئات"
    _save()

func _spawn_enemies() -> void:
    for i in range(3):
        _spawn("bramble",Vector3(78.0+float(i)*12.0,0.0,-8.0+float(i)*9.0))
    for i in range(2):
        _spawn("wisp",Vector3(152.0+float(i)*12.0,0.0,12.0-float(i)*17.0))
    _ensure_guardian_spawned()

func _ensure_forest_spawns() -> void:
    # A player can defeat brambles before speaking to Lora; never leave quest 1 without targets.
    if quest_stage != 1 or forest_defeated >= 3:
        return
    var living := 0
    for enemy in enemies:
        if is_instance_valid(enemy) and str(enemy.get("enemy_type")) == "bramble" and not bool(enemy.get("dead")):
            living += 1
    var needed := mini(3 - forest_defeated,3)
    for i in range(living,needed):
        _spawn("bramble",Vector3(69.0+float(i)*12.0,0.0,19.0-float(i)*11.0))

func _ensure_guardian_spawned() -> void:
    # Never spawn boss before the altar quest; otherwise an early kill soft-locks the campaign.
    if boss_defeated or quest_stage != 3:
        return
    for enemy in enemies:
        if is_instance_valid(enemy) and str(enemy.get("enemy_type")) == "guardian" and not bool(enemy.get("dead")):
            return
    _spawn("guardian",Vector3(191,0,0),true)

func _spawn(kind: String, at: Vector3, boss: bool = false) -> Node3D:
    var enemy := CharacterBody3D.new()
    enemy.set_script(ENEMY_SCRIPT)
    enemy.position = at
    add_child(enemy)
    var resource: PackedScene = BRIAR if kind in ["bramble","shade_hunter"] else (WISP if kind in ["wisp","frost_wisp"] else SENTINEL)
    enemy.call("setup",kind,resource,player,boss)
    enemy.connect("defeated",_on_enemy_defeated)
    enemy.connect("hero_hit",_take_damage)
    enemy.add_to_group("shattered_moon_enemies")
    enemies.append(enemy)
    return enemy

func _restore_sanctuary_wave() -> void:
    if sanctuary_state != 1:
        return
    # Persist *completed* victories. On restart the remaining enemies return.
    var starts := [Vector3(88,0,22),Vector3(105,0,26),Vector3(101,0,37)]
    for i in range(sanctuary_kills,3):
        var enemy_kind := "bramble" if i == 1 else "wisp"
        var encounter := _spawn(enemy_kind,starts[i])
        encounter.connect("defeated",_on_sanctuary_enemy_defeated)

func _moon_seals_collected() -> int:
    var count := 0
    for i in range(3):
        if (moon_seal_mask & (1 << i)) != 0:
            count += 1
    return count

func _restore_moon_seal_wave() -> void:
    if moon_seal_state != 1:
        return
    # On save/reload only missing defenders respawn; defeated count is persistent.
    var locations := [Vector3(123,0,17),Vector3(133,0,20)]
    for i in range(moon_seal_kills,2):
        var kind := "bramble" if i == 0 else "wisp"
        var guard := _spawn(kind,locations[i])
        guard.connect("defeated",_on_moon_seal_guard_defeated)

func _on_moon_seal_guard_defeated(_kind: String) -> void:
    if moon_seal_state != 1:
        return
    moon_seal_kills = mini(2,moon_seal_kills+1)
    if moon_seal_kills >= 2:
        moon_seal_state = 2
        _status("هُزم حارسا الأختام! عد إلى مذبح الغابة لتسلّم المكافأة")
    else:
        _status("حراسة مذبح القمر: %d/2" % moon_seal_kills)
    _save()

func _on_sanctuary_enemy_defeated(_kind: String) -> void:
    if sanctuary_state != 1:
        return
    sanctuary_kills = mini(3,sanctuary_kills+1)
    if sanctuary_kills >= 3:
        sanctuary_state = 2
        _status("طهرت المعبد من الأرواح! عد إلى البلورة لتستلم المكافأة")
    else:
        _status("دفاع المعبد: %d/3 من الوحوش" % sanctuary_kills)
    _save()

func _on_enemy_defeated(kind: String) -> void:
    total_defeated += 1
    var is_minor: bool = kind in ["bramble","wisp","shade_hunter","frost_wisp"]
    gold += (40 if kind in ["shade_hunter","frost_wisp"] else (24 if kind=="bramble" else 33)) if is_minor else 160
    _gain_exp((45 if kind in ["shade_hunter","frost_wisp"] else (22 if kind=="bramble" else 34)) if is_minor else 220)
    if kind == "bramble":
        forest_defeated += 1
        if quest_stage == 1 and forest_defeated >= 3:
            quest_stage = 2
            _status("أُزيل خطر الغابة! اذهب إلى المذبح البلوري داخل الأطلال")
    elif kind == "guardian":
        boss_defeated = true
        if quest_stage == 3:
            quest_stage = 4
            _status("هُزم حارس البازلت! عد إلى لوحة المهام في القرية")
    _save()

func _gain_exp(amount: int) -> void:
    exp_points += amount
    while exp_points >= level * 90:
        exp_points -= level * 90
        level += 1
        max_health += 18.0
        health = max_health
        mana = 70.0 + (level - 1) * 8.0
        _status("ارتقيت إلى المستوى %d!" % level)

func _take_damage(amount: float, attacker: Node3D = null) -> void:
    if dodge_invulnerable > 0.0:
        _status("نجحت المراوغة!")
        return
    # Only an actual visible attacker in the forward cone can be parried.
    # Non-combat/environment damage cannot be cancelled by this ability.
    if parry_window > 0.0 and is_instance_valid(attacker):
        var toward: Vector3 = attacker.global_position - player.global_position
        toward.y = 0.0
        if toward.length() >= 0.01 and toward.length() <= 7.0 and hero_forward.dot(toward.normalized()) >= 0.20:
            parry_window = 0.0
            parry_success_flash = 0.42
            camera_impact = maxf(camera_impact,0.13)
            perfect_parries += 1
            stamina = minf(100.0,stamina+9.0)
            if attacker.has_method("interrupt_attack"):
                attacker.call("interrupt_attack",0.70)
            if attacker.has_method("take_hit"):
                var counter_damage := 18.0 + float(level-1)*1.7 + float(smith_level)*3.0
                attacker.call("take_hit",counter_damage,player.global_position)
                _floating_damage(attacker.global_position,roundi(counter_damage),true)
                _impact_sparks(attacker.global_position,Color(.45,.83,1.0))
            _parry_visual()
            if is_instance_valid(parry_audio):
                parry_audio.play()
            _status("صد مثالي! استعدت 9 تحمل · المجموع %d" % perfect_parries)
            return
    health = maxf(0.0, health - amount)
    _impact_sparks(player.position,Color(1.0,.38,.26))
    _status("تلقيت ضربة! استخدم الاندفاع أو العلاج")
    hit_flash = 0.22
    camera_impact = maxf(camera_impact,0.24)
    if health <= 0.0:
        health = max_health
        mana = 70.0 + (level-1)*8.0
        player.position = checkpoint_position
        gold = maxi(0,gold-20)
        _status("عدت إلى القرية بعد الهزيمة، وخسرت 20 ذهبًا")
        _save()

func _attack() -> void:
    if attack_cooldown > 0.0:
        return
    combo_step = (combo_step % 3) + 1 if combo_expiry > 0.0 else 1
    combo_expiry = 1.2
    hero_attack_pose = 0.42
    attack_cooldown = 0.72 if combo_step == 3 else 0.44
    # The GPU animation supplies torso and arm motion without a rigid-body wobble.
    _show_sword_arc()
    var power := (23.0 if combo_step == 1 else (31.0 if combo_step == 2 else 44.0)) + float(level-1)*4.0 + float(smith_level)*8.0
    var hits: int = 0
    for enemy in enemies:
        if not is_instance_valid(enemy) or bool(enemy.get("dead")):
            continue
        var offset: Vector3 = enemy.position - player.position
        offset.y = 0.0
        if offset.length() <= 3.75 and offset.length() > .01 and hero_forward.dot(offset.normalized()) > 0.10:
            var strike_ray := PhysicsRayQueryParameters3D.create(player.global_position+Vector3(0,1.3,0),enemy.global_position+Vector3(0,1.3,0),4)
            strike_ray.exclude = [player.get_rid()]
            if not get_world_3d().direct_space_state.intersect_ray(strike_ray).is_empty():
                continue
            enemy.call("take_hit",power,player.position)
            _floating_damage(enemy.position,roundi(power),combo_step == 3)
            _impact_sparks(enemy.position,Color(1.0,.72,.37) if combo_step == 3 else Color(.85,.92,1.0))
            hits += 1
    if hits > 0:
        camera_impact = maxf(camera_impact,0.035 if combo_step<3 else 0.075)
        if is_instance_valid(strike_audio):
            strike_audio.play()
        _status("سلسلة ضربات %d/3 · أصبت %d" % [combo_step,hits])

func _spell() -> void:
    if mana < 18.0 or spell_cooldown > 0.0:
        _status("الطاقة السحرية غير كافية" if mana<18.0 else "السحر يستعيد قوته")
        return
    mana -= 18.0
    spell_cooldown = 1.45
    # Focus wins over nearest-target auto-aim, but only while within spell range.
    var nearest: Node3D = focus_target if _focus_is_valid() and player.position.distance_to(focus_target.position) < 17.0 else null
    var best := 17.0
    if nearest == null:
        for enemy in enemies:
            if not is_instance_valid(enemy) or bool(enemy.get("dead")):
                continue
            var d: float = enemy.position.distance_to(player.position)
            if d < best:
                best = d
                nearest = enemy
    if nearest != null:
        _spawn_spell_light(nearest.position)
        var spell_power := 38.0+float(level-1)*4.0+(12.0 if echo_rewarded else 0.0)
        nearest.call("take_hit",spell_power,player.position)
        _floating_damage(nearest.position,roundi(spell_power),true)
        _impact_sparks(nearest.position,Color(.40,.75,1.0))
        _moon_spell_impact(nearest.position)
        _status("شعاع القمر أصاب الهدف")
    else:
        _status("لم تجد تعويذتك هدفًا قريبًا")

func _lunar_burst() -> void:
    # A telegraphed area skill aimed at groups: costs both mana and stamina.
    if lunar_burst_cooldown > 0.0:
        _status("اندفاع القمر يعود بعد %d ثوانٍ" % ceili(lunar_burst_cooldown))
        return
    if mana < 35.0 or stamina < 20.0:
        _status("اندفاع القمر يحتاج إلى 35 سحر و20 تحمل")
        return
    mana -= 35.0
    stamina -= 20.0
    lunar_burst_cooldown = 10.0
    hero_attack_pose = 0.53
    _burst_visual()
    var hits := 0
    var power := 55.0+float(level-1)*5.0+float(smith_level)*5.0+(10.0 if echo_rewarded else 0.0)
    for enemy in enemies:
        if not is_instance_valid(enemy) or bool(enemy.get("dead")):
            continue
        var direction: Vector3 = enemy.position-player.position
        direction.y = 0.0
        if direction.length() > 6.2:
            continue
        var ray := PhysicsRayQueryParameters3D.create(player.global_position+Vector3(0,1.3,0),enemy.global_position+Vector3(0,1.3,0),4)
        ray.exclude = [player.get_rid()]
        if not get_world_3d().direct_space_state.intersect_ray(ray).is_empty():
            continue
        enemy.call("take_hit",power,player.position)
        _floating_damage(enemy.position,roundi(power),true)
        _impact_sparks(enemy.position,Color(.47,.94,1.0))
        hits += 1
    _status("موجة القمر: أصبت %d أعداء!" % hits if hits > 0 else "موجة القمر انطلقت، لكن لا يوجد أعداء قريبون")

func _burst_visual() -> void:
    # One temporary ring per cast; the tween disposes of it in under one second.
    var ring := MeshInstance3D.new()
    var mesh := TorusMesh.new()
    mesh.inner_radius = .85
    mesh.outer_radius = 1.05
    mesh.rings = 8
    mesh.ring_segments = 48
    ring.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(.45,.9,1.0,.90)
    mat.emission_enabled = true
    mat.emission = Color(.23,.65,1.0)
    ring.material_override = mat
    ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    ring.position = player.position+Vector3(0,.14,0)
    add_child(ring)
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(ring,"scale",Vector3.ONE*5.4,.43)
    tween.tween_property(mat,"albedo_color:a",0.0,.43)
    tween.set_parallel(false)
    tween.tween_callback(ring.queue_free)

func _parry() -> void:
    # F / touch: a short, deliberate counter window, not a held shield.
    if parry_cooldown > 0.0:
        _status("الصد يستعيد جاهزيته: %d ث" % ceili(parry_cooldown))
        return
    if stamina < 16.0:
        _status("الصد يحتاج إلى 16 تحمل")
        return
    stamina -= 16.0
    parry_window = 0.32
    parry_cooldown = 1.20
    hero_attack_pose = 0.0
    _status("◈ توقيت الصد: واجه الضربة القادمة")

func _parry_visual() -> void:
    # Short-lived low-polygon ring; safe for GL Compatibility/mobile.
    var ring := MeshInstance3D.new()
    var mesh := TorusMesh.new()
    mesh.inner_radius = 0.75
    mesh.outer_radius = 0.90
    mesh.rings = 8
    mesh.ring_segments = 32
    ring.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(0.65,0.91,1.0,0.95)
    mat.emission_enabled = true
    mat.emission = Color(0.35,0.65,1.0)
    ring.material_override = mat
    ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    ring.position = player.global_position+Vector3(0,1.25,0)
    ring.rotation.x = PI*.45
    add_child(ring)
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(ring,"scale",Vector3.ONE*2.3,0.30)
    tween.tween_property(mat,"albedo_color:a",0.0,0.30)
    tween.set_parallel(false)
    tween.tween_callback(ring.queue_free)

func _dodge() -> void:
    if dodge_cooldown > 0.0 or stamina < 28.0:
        return
    stamina -= 28.0
    dodge_cooldown = 1.05
    dodge_direction = hero_forward
    parry_window = 0.0 # dodge cancels pending guard; no stacked invulnerability
    dodge_time = 0.19
    dodge_invulnerable = 0.32
    _status("مراوغة")

func _heal() -> void:
    if potions <= 0 or health >= max_health:
        _status("لا توجد جرعات كافية أو صحتك ممتلئة")
        return
    potions -= 1
    health = minf(max_health,health+55.0)
    _status("استُخدمت جرعة علاج")
    _save()

func _interact() -> void:
    # Memories take interaction priority when beside another landmark.
    if _collect_nearby_memory():
        return
    # New forge is a persistent, optional upgrade. Existing quests remain unaffected.
    # Stage 18 exploration comes before older, distant quest interaction checks.
    if player.position.distance_to(echo_altar_pos) < 5.4:
        _interact_echo_altar()
        return
    for i in range(echo_glyph_positions.size()):
        if player.position.distance_to(echo_glyph_positions[i]) < 4.4:
            if quest_stage < 5:
                _status("النقش صامت. أكمل مهمة قلب القمر أولًا")
            elif (echo_glyph_mask & (1 << i)) != 0:
                _status("هذا النقش مضيء بالفعل")
            else:
                echo_glyph_mask |= (1 << i)
                _play_echo_sfx(ECHO_CHIME)
                _status("أيقظت %s — نقوش الوادي %d/3" % [echo_glyph_names[i],_echo_glyph_count()])
                if echo_glyph_mask == 7:
                    _status("اشتعلت نقوش الوادي! توجه إلى مذبح الأصداء في أقصى الشرق")
                _refresh_echo_markers()
                _save()
            return
    if player.position.distance_to(rift_center) < 5.0:
        _interact_rift()
        return
    if player.position.distance_to(smith_position) < 4.4:
        _forge_upgrade()
        return
    # Priority goes to the new outpost before nearby legacy waystones.
    if player.position.distance_to(moon_seal_altar_pos) < 5.4:
        if quest_stage < 5:
            _status("يحتاج المذبح إلى حارس أكمل مهمة قلب القمر")
        elif moon_seal_state == 0:
            _status("ابحث عن النقوش القمرية الثلاثة في غابة الهمس (%d/3)" % _moon_seals_collected())
        elif moon_seal_state == 1:
            _status("احمِ المذبح من الوحشين المتبقيين: %d/2" % moon_seal_kills)
        elif moon_seal_state == 2 and not moon_seal_rewarded:
            moon_seal_rewarded = true
            moon_seal_state = 3
            gold += 620
            potions += 3
            _gain_exp(340)
            _status("طَهُر مذبح القمر! +620 ذهب و340 خبرة و3 جرعات")
            _save()
        else:
            _status("أختام الغابة مضيئة؛ أصبحت المنطقة آمنة")
        return
    for i in range(moon_seal_places.size()):
        if player.position.distance_to(moon_seal_places[i]) < 4.2:
            if quest_stage < 5:
                _status("النقوش صامتة الآن. أكمل القصة الأساسية أولًا")
            elif (moon_seal_mask & (1 << i)) != 0:
                _status("فعلت هذا النقش مسبقًا")
            else:
                moon_seal_mask |= (1 << i)
                _status("نقش القمر: %d/3" % _moon_seals_collected())
                if _moon_seals_collected() == 3 and moon_seal_state == 0:
                    moon_seal_state = 1
                    moon_seal_kills = 0
                    _restore_moon_seal_wave()
                    _status("أيقظت الأختام حارسين! اهزمهما لحماية مذبح الغابة")
                _save()
            return
    if player.position.distance_to(sanctuary_center) < 6.0:
        if quest_stage < 2:
            _status("لا يستجيب المعبد بعد. أكمل مهمة الغابة أولاً")
        elif sanctuary_state == 0:
            sanctuary_state = 1
            sanctuary_kills = 0
            _restore_sanctuary_wave()
            _status("معبد القمر: اهزم الحراس الثلاثة قبل تفعيل البلورة")
            _save()
        elif sanctuary_state == 1:
            _status("أبعد الأرواح عن المعبد: %d/3" % sanctuary_kills)
        elif sanctuary_state == 2 and not sanctuary_rewarded:
            sanctuary_state = 3
            sanctuary_rewarded = true
            gold += 350
            potions += 2
            _gain_exp(190)
            _status("نجحت مهمة حارس المعبد! +350 ذهب، +190 خبرة، وجرعتان")
            _save()
        else:
            _status("أعدت النور إلى المعبد، وسيظل آمنًا")
        return
    if player.position.distance_to(rayan_spot) < 5.0:
        if quest_stage < 1:
            _status("ريان: تحدث إلى لورا أولاً، ثم أرافقك في رحلتك")
        elif not companion_recruited:
            companion_recruited = true
            companion_active = true
            _sync_companion()
            _status("انضم ريان إليك! سيساعدك في القتال والعلاج")
            _save()
        else:
            companion_active = not companion_active
            _sync_companion()
            _status("ريان يرافقك" if companion_active else "ريان ينتظرك عند بوابة القرية")
            _save()
        return
    for i in range(moon_lantern_positions.size()):
        if player.position.distance_to(moon_lantern_positions[i]) < 4.5:
            if quest_stage < 5:
                _status("أكمل مهمة قلب القمر قبل تفعيل أنوار القمر")
            elif moon_lantern_rewarded:
                _status("أنوار القمر الثلاثة تضيء الطريق الآن")
            elif i == moon_lantern_step:
                moon_lantern_step += 1
                _status("أشعلت فانوس القمر %d من 3" % moon_lantern_step)
                if moon_lantern_step == 3:
                    moon_lantern_rewarded = true
                    gold += 480
                    potions += 3
                    _gain_exp(210)
                    _status("اكتمل لغز أنوار القمر! +480 ذهب و210 خبرة و3 جرعات")
                _update_lighting()
                _save()
            elif i < moon_lantern_step:
                _status("هذا الفانوس مضاء بالفعل")
            else:
                _status("تفعيل الفوانيس بالترتيب: الأزرق، البنفسجي، الذهبي")
            return
    for i in range(beacon_anchors.size()):
        if player.position.distance_to(beacon_anchors[i]) < 4.1:
            if (beacons_mask & (1 << i)) != 0:
                if waystone_rest_timer <= 0.0:
                    health = max_health
                    mana = 70.0+float(level-1)*8.0
                    stamina = 100.0
                    checkpoint_position = beacon_anchors[i]+Vector3(0,0,3.0)
                    checkpoint_unlocked = i+1
                    checkpoint_rest_count += 1
                    waystone_rest_timer = 7.0
                    _status("استرحت عند حجر الطريق واستعدت صحتك وسحرك. حُفظت نقطة عودتك")
                    _save()
                else:
                    _status("استرح قليلًا قبل إعادة تفعيل الحجر")
            else:
                beacons_mask |= (1 << i)
                checkpoint_position = beacon_anchors[i] + Vector3(0,0,3.0)
                checkpoint_unlocked = i+1
                _status("أشعلت حجر الطريق %d من 3" % _beacon_count())
                if _beacon_count() == 3 and not beacons_rewarded:
                    beacons_rewarded = true
                    gold += 180
                    potions += 2
                    _gain_exp(65)
                    _status("اكتملت مهمة أحجار الطريق! +180 ذهب وجرعتان و65 خبرة")
                _save()
            return
    if player.position.distance_to(board_position) < 6.8:
        if quest_stage == 0:
            quest_stage = 1
            _ensure_forest_spawns()
            _status("لورا: تخلص من 3 وحوش شوكية في غابة الهمس شرق القرية")
        elif quest_stage == 4:
            quest_stage = 5
            _refresh_rift_marker()
            gold += 270
            potions += 4
            _gain_exp(180)
            _status("أكملت مغامرة قلب القمر! +270 ذهب +4 جرعات")
        elif quest_stage == 5:
            if _memory_count() == 6 and not moon_memory_rewarded:
                _claim_memory_reward()
            elif moon_memory_rewarded:
                _status("لورا: استعادت القرية ذكريات القمر، شكرًا أيها الحارس")
            else:
                _status("لورا: ابحث عن ذكريات القمر الست المنتشرة في العالم (%d/6)" % _memory_count())
        else:
            _status("لورا: تابع المهمة المعروضة في أعلى الشاشة")
        _save()
        return
    if player.position.distance_to(shop_position) < 7.6:
        if gold >= 75:
            gold -= 75
            potions += 1
            _status("اشتريت جرعة علاج مقابل 75 ذهبًا")
            _save()
        else:
            _status("التاجر: تحتاج إلى 75 ذهبًا لشراء جرعة")
        return
    if player.position.distance_to(shrine_position) < 6.0:
        if quest_stage == 2:
            cave_token = true
            quest_stage = 3
            _ensure_guardian_spawned()
            _status("حصلت على شظية القمر! اهزم حارس البازلت داخل الأطلال")
            _save()
        elif quest_stage > 2:
            _status("لقد أخذت شظية القمر من هذا المذبح")
        else:
            _status("يجب إنهاء مهمة وحوش الغابة أولًا")
        return
    _status("اقترب من لوحة لورا أو التاجر أو المذبح ثم اضغط تفاعل")

func _beacon_count() -> int:
    var count := 0
    for i in range(3):
        if (beacons_mask & (1 << i)) != 0:
            count += 1
    return count

func _status(msg: String) -> void:
    notification = msg
    message_timer = 4.7
    if message_label != null:
        message_label.text = msg

func _quest_text() -> String:
    match quest_stage:
        0: return "📜 المهمة: تحدث إلى لورا عند لوحة الإعلانات في القرية"
        1: return "📜 الغابة: اهزم 3 وحوش شوكية  (%d/3)" % mini(forest_defeated,3)
        2: return "📜 استكشف الأطلال: ابحث عن شظية القمر عند المذبح"
        3: return "📜 زعيم الأطلال: اهزم حارس البازلت"
        4: return "📜 عد إلى لورا واستلم مكافأة المهمة"
        _: return "🌙 أنوار القمر: %d/3 · اتبع الأزرق ثم البنفسجي ثم الذهبي" % moon_lantern_step if not moon_lantern_rewarded else "✅ اكتملت قصة قلب القمر وأنوار القمر"

func _navigation_goal() -> Vector3:
    # One reliable primary destination; side quests remain listed in the HUD.
    match quest_stage:
        0, 4:
            return board_position
        1:
            var closest: float = INF
            var selected: Vector3 = Vector3(81,0,4)
            for enemy in enemies:
                if is_instance_valid(enemy) and not bool(enemy.get("dead")) and str(enemy.get("enemy_type")) == "bramble":
                    var d: float = player.position.distance_squared_to(enemy.position)
                    if d < closest:
                        closest = d
                        selected = enemy.position
            return selected
        2:
            return shrine_position
        3:
            return Vector3(191,0,0)
        _:
            if not moon_lantern_rewarded and moon_lantern_step < moon_lantern_positions.size():
                return moon_lantern_positions[moon_lantern_step]
            if not moon_seal_rewarded:
                if moon_seal_state == 0:
                    for i in range(moon_seal_places.size()):
                        if (moon_seal_mask & (1 << i)) == 0:
                            return moon_seal_places[i]
                return moon_seal_altar_pos
            if not sanctuary_rewarded:
                return sanctuary_center
            for i in range(beacon_anchors.size()):
                if (beacons_mask & (1 << i)) == 0:
                    return beacon_anchors[i]
            if not moon_memory_rewarded:
                for i in range(moon_memory_positions.size()):
                    if (moon_memory_mask & (1 << i)) == 0:
                        return moon_memory_positions[i]
                return board_position
            if quest_stage >= 5 and not rift_rewarded:
                return rift_center
            if quest_stage >= 5 and not echo_rewarded:
                if echo_state == 1:
                    for fighter in echo_fighters:
                        if is_instance_valid(fighter) and not bool(fighter.get("dead")):
                            return fighter.position
                    return echo_altar_pos
                if echo_state == 2 or echo_glyph_mask == 7:
                    return echo_altar_pos
                for i in range(echo_glyph_positions.size()):
                    if (echo_glyph_mask & (1 << i)) == 0:
                        return echo_glyph_positions[i]
            return board_position

func _navigation_arrow(to_goal: Vector3) -> String:
    var forward := Vector3(sin(cam_yaw),0.0,-cos(cam_yaw))
    var right := Vector3(cos(cam_yaw),0.0,sin(cam_yaw))
    if to_goal.length_squared() < 1.0:
        return "◎"
    var dir := to_goal.normalized()
    var front_dot: float = dir.dot(forward)
    var side_dot: float = dir.dot(right)
    if absf(front_dot) >= absf(side_dot):
        return "↑" if front_dot >= 0.0 else "↓"
    return "→" if side_dot >= 0.0 else "←"

func _refresh_hud() -> void:
    if not is_instance_valid(hp_bar):
        return
    if is_instance_valid(navigation_label):
        var to_goal: Vector3 = _navigation_goal()-player.position
        to_goal.y = 0.0
        navigation_label.text = "%s الهدف: %d م" % [_navigation_arrow(to_goal),roundi(to_goal.length())]
    if is_instance_valid(navigation_map):
        navigation_map.queue_redraw()
    if is_instance_valid(interaction_label):
        interaction_label.text = _nearby_interaction_hint()
    hp_bar.max_value = max_health
    hp_bar.value = health
    mp_bar.max_value = 70.0+float(level-1)*8.0
    mp_bar.value = mana
    stamina_bar.max_value = 100.0
    stamina_bar.value = stamina
    if is_instance_valid(lunar_burst_label):
        lunar_burst_label.text = "☾ موجة القمر [R]: %s" % ("جاهزة" if lunar_burst_cooldown <= 0.0 else "%d ث" % ceili(lunar_burst_cooldown))
    if is_instance_valid(guard_label):
        guard_label.text = "◈ الصد [F]: %s · نجحت %d" % [("الآن!" if parry_window > 0.0 else ("جاهز" if parry_cooldown <= 0.0 else "%d ث" % ceili(parry_cooldown))),perfect_parries]
    var locked: bool = _focus_is_valid()
    if is_instance_valid(focus_label):
        focus_label.visible = locked
        focus_hp_bar.visible = locked
        focus_button.text = ("◎ إلغاء" if locked else "◎ هدف") if stage51_compact_layout else ("◎ إلغاء [T]" if locked else "◎ تثبيت [T]")
        if locked:
            focus_label.text = "◎ %s · %d م" % [str(focus_target.get("display_name")),roundi(player.position.distance_to(focus_target.position))]
            focus_hp_bar.max_value = float(focus_target.get("max_hp"))
            focus_hp_bar.value = float(focus_target.get("hp"))
    title_label.text = "⚔ Lv.%d   🪙%d   🧪%d   ⚒%d   ✦%d/6" % [level,gold,potions,smith_level,_memory_count()]
    var boss: Node3D = null
    for enemy in enemies:
        if is_instance_valid(enemy) and bool(enemy.get("is_boss")) and not bool(enemy.get("dead")):
            if player.position.distance_to(enemy.position) < 32.0:
                boss = enemy
                break
    boss_hp_bar.visible = boss != null
    boss_hp_label.visible = boss != null
    # Read the existing windup; never alter attack_timer, impact timing or damage.
    var boss_charging: bool = boss != null and float(boss.get("windup")) > 0.0
    boss_attack_label.visible = boss_charging
    boss_attack_bar.visible = boss_charging
    if boss != null:
        boss_hp_label.text = str(boss.get("display_name"))
        boss_hp_bar.max_value = float(boss.get("max_hp"))
        boss_hp_bar.value = float(boss.get("hp"))
        if boss_charging:
            var duration: float = maxf(0.01, float(boss.get("windup_initial")))
            var remaining: float = float(boss.get("windup"))
            var charging: float = clampf(1.0 - remaining/duration, 0.0, 1.0)
            boss_attack_bar.value = charging * 100.0
            boss_attack_label.text = ("⚠ ضربة دائرية — ابتعد" if bool(boss.get("slam_active"))
                else "⚠ ضربة أمامية — صد أو راوِغ") + "  %.1f ث" % remaining
    # Readout appears only if Rayan is fighting the player's deliberately locked target.
    var ally_assisting: bool = companion_active and locked and is_instance_valid(rayan_ally) and (rayan_ally.get("current_target") == focus_target)
    companion_focus_label.visible = ally_assisting
    if ally_assisting:
        companion_focus_label.text = "⚔ ريان يساندك ضد الهدف المختار"
    quest_label.text = _quest_text() + ("\n✦ أحجار الطريق: %d/3" % _beacon_count() if not beacons_rewarded else "")
    if not moon_memory_rewarded:
        quest_label.text += "\n✦ ذكريات القمر: %d/6" % _memory_count()
    if quest_stage >= 5 and not echo_rewarded and (player.position.x > 194.0 or echo_state in [1,2]):
        if echo_state == 1:
            quest_label.text += "\n☽ وادي الأصداء: موجة %d/2 · %d/%d" % [echo_wave,echo_kills,_echo_wave_size()]
        elif echo_state == 2:
            quest_label.text += "\n☽ وادي الأصداء: استلم المكافأة من المذبح"
        else:
            quest_label.text += "\n☽ نقوش الوادي: %d/3" % _echo_glyph_count()
    if rift_state == 1:
        quest_label.text += "\n☾ صدع القمر: موجة %d/3 · %d/%d" % [rift_wave,rift_kills,_rift_wave_size()]
    elif rift_state == 2:
        quest_label.text += "\n☾ صدع القمر: استلم مكافأة التحدي"
    if smith_level < 3 and player.position.distance_to(smith_position) < 15.0:
        quest_label.text += "\n⚒ حدادة الفجر: %d/3 — اقترب للتطوير" % smith_level
    if companion_recruited and not companion_quest_rewarded:
        quest_label.text += "\n⚔ تدريب ريان: %d/3 ضربات" % companion_strikes
    if sanctuary_state in [1,2]:
        quest_label.text += "\n🌙 معبد القمر: %d/3 — %s" % [sanctuary_kills,"استلم المكافأة" if sanctuary_state == 2 else "احمِ المعبد"]
    if quest_stage >= 5 and not moon_seal_rewarded:
        var new_objective := "الأختام: %d/3" % _moon_seals_collected()
        if moon_seal_state == 1: new_objective = "دفاع المذبح: %d/2" % moon_seal_kills
        elif moon_seal_state == 2: new_objective = "العودة إلى المذبح لاستلام المكافأة"
        quest_label.text += "\n💠 %s" % new_objective

func _cycle_resolution() -> void:
    var choices := [0.65,0.82,1.0]
    var index := 0
    for i in range(choices.size()):
        if absf(mobile_resolution_scale-choices[i]) < .025:
            index = i
    mobile_resolution_scale = choices[(index+1)%choices.size()]
    get_viewport().scaling_3d_scale = mobile_resolution_scale
    adaptive_enabled = false # direct manual choice takes priority until next launch
    _status("مقياس الرسم: %d%% (تلقائي متوقف)" % roundi(mobile_resolution_scale * 100.0))

func _blocked(where: Vector3) -> bool:
    if where.x < -48.0 or where.x > 302.0 or absf(where.z) > 47.0:
        return true
    # Guard bounds used by dash. Actual walk collision comes from CharacterBody3D.
    if where.x > -31.0 and where.x < 32.0:
        for i in range(8):
            var z := -31.0 + float(i)*8.4
            for side in [-1,1]:
                if i == 5 and side == 1:
                    continue
                var x := float(side)*(14.3 + float(i%3)*1.5)
                if absf(where.x-x)<5.5 and absf(where.z-z)<5.0:
                    return true
    return false

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("dev_stats"):
        if event is InputEventKey and event.echo:
            return
        stage41_show_debug = not stage41_show_debug
        if is_instance_valid(stage41_debug_label):
            stage41_debug_label.visible = stage41_show_debug
        get_viewport().set_input_as_handled()
        return
    if event.is_action_pressed("quest_journal"):
        if event is InputEventKey and event.echo:
            return
        _toggle_journal()
        get_viewport().set_input_as_handled()
        return
    if event.is_action_pressed("ui_cancel") or event.is_action_pressed("pause_game"):
        if event is InputEventKey and event.echo:
            return
        _toggle_pause()
        get_viewport().set_input_as_handled()
        return
    if event is InputEventScreenTouch:
        var t := event as InputEventScreenTouch
        var screen_width: float = get_viewport().get_visible_rect().size.x
        if t.pressed and t.position.x < screen_width*.42 and t.position.y > get_viewport().get_visible_rect().size.y*.42:
            move_touch = t.index
            move_origin = t.position
        elif t.pressed and t.position.x >= screen_width*.42:
            cam_touch = t.index
        elif not t.pressed:
            if t.index == move_touch:
                move_touch = -1
                touch_move = Vector2.ZERO
                joystick_puck.position = Vector2(51,51)
            if t.index == cam_touch:
                cam_touch = -1
    elif event is InputEventScreenDrag:
        var d := event as InputEventScreenDrag
        if d.index == move_touch:
            touch_move = ((d.position-move_origin)/69.0).limit_length(1.0)
            joystick_puck.position = Vector2(51,51)+touch_move*38.0
        elif d.index == cam_touch:
            cam_yaw -= d.relative.x*.007
            cam_pitch = clampf(cam_pitch+d.relative.y*.003,-.58,-.11)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        var mouse := event as InputEventMouseMotion
        cam_yaw -= mouse.relative.x * .007
        cam_pitch = clampf(cam_pitch+mouse.relative.y*.003,-.58,-.11)
    if event.is_action_pressed("interact"): _interact()
    if event.is_action_pressed("attack"): _attack()
    if event.is_action_pressed("spell"): _spell()
    if event.is_action_pressed("lunar_burst"): _lunar_burst()
    if event.is_action_pressed("dodge"): _dodge()
    if event.is_action_pressed("parry"): _parry()
    if event.is_action_pressed("lock_target"): _toggle_focus()
    if event.is_action_pressed("next_target"): _cycle_focus()
    if event.is_action_pressed("heal"): _heal()

func _update_stage41_light_visibility() -> void:
    # Stage 35 cosmetic torches/window lights are optional. Keep near lights on and
    # disable distant ones, with hysteresis to prevent flashing on movement.
    # Real navigation, quest and combat lights are deliberately NOT in this group.
    if not is_instance_valid(player):
        return
    stage41_active_lights = 0
    var mobile := OS.has_feature("mobile")
    for element in get_tree().get_nodes_in_group("shattered_moon_cosmetic_light"):
        var light := element as OmniLight3D
        if not is_instance_valid(light):
            continue
        var near_radius := 33.0 if mobile else 52.0
        var far_radius := 42.0 if mobile else 64.0
        var radius := far_radius if light.visible else near_radius
        light.visible = light.global_position.distance_squared_to(player.global_position) <= radius * radius
        if light.visible and light.is_visible_in_tree():
            stage41_active_lights += 1

func _update_stage41_debug() -> void:
    if not stage41_show_debug or not is_instance_valid(stage41_debug_label):
        return
    stage41_debug_label.text = "FPS: %d | 3D: %.2f | lights: %d | enemies: %d" % [
        Engine.get_frames_per_second(), mobile_resolution_scale,
        stage41_active_lights, enemies.size()]

func _update_zone_visibility() -> void:
    if zones.size()<3:
        return
    zones[0].visible = player.position.x < 73.0
    zones[1].visible = player.position.x > 27.0 and player.position.x < 151.0
    zones[2].visible = player.position.x > 117.0 and player.position.x < 263.0
    if zones.size() >= 4:
        zones[3].visible = player.position.x > 175.0

func _physics_process(delta: float) -> void:
    clock += delta
    if is_instance_valid(moon_motes) and moon_motes.visible:
        moon_motes.position = player.position
    echo_effect_clock += delta
    for i in range(echo_glyph_nodes.size()):
        if (echo_glyph_mask & (1 << i)) != 0 or player.position.distance_squared_to(echo_glyph_positions[i]) > 1300.0:
            continue
        var glyph := echo_glyph_nodes[i]
        var jewel := glyph.get_child(2) as MeshInstance3D
        jewel.position.y = 1.34+sin(echo_effect_clock*2.0+float(i))*.17
        jewel.rotation.y += delta*.75
    lunar_burst_cooldown = maxf(0.0,lunar_burst_cooldown-delta)
    if is_instance_valid(rift_marker) and rift_marker.visible and player.position.distance_squared_to(rift_center) < 1600.0:
        rift_animation += delta
        var crystal: Node3D = rift_marker.get_child(2) as Node3D
        crystal.position.y = 1.35+sin(rift_animation*2.3)*.18
        crystal.rotation.y += delta*.9
    # Cosmetic animation is amortized and skipped for already collected memories.
    moon_memory_anim += delta
    for i in range(moon_memory_nodes.size()):
        var memory: Node3D = moon_memory_nodes[i]
        if not memory.visible:
            continue
        if player.position.distance_squared_to(moon_memory_positions[i]) > 1600.0:
            continue
        var gem: Node3D = memory.get_child(0) as Node3D
        gem.position.y = 1.52 + sin(moon_memory_anim*1.9+float(i))*0.20
        gem.rotation.y += delta*0.75
    day_clock = fposmod(day_clock+delta,390.0)
    lighting_timer += delta
    if lighting_timer >= 1.0:
        lighting_timer = 0.0
        _update_lighting()
        _update_firefly_visibility()
    _update_ambient_flicker(delta)
    # Camera follows the selected enemy gently; no hard snap during dodge/sprinting.
    if _focus_is_valid():
        var focus_aim: Vector3 = focus_target.position - player.position
        focus_aim.y = 0.0
        if focus_aim.length_squared() > 0.12:
            cam_yaw = lerp_angle(cam_yaw,atan2(focus_aim.x,-focus_aim.z),minf(delta*2.2,1.0))
    var keys := Input.get_vector("move_left","move_right","move_forward","move_backward")
    var input_vector := touch_move if touch_move.length() > 0.12 else keys
    # On mobile, pushing the analog stick close to its edge enables sprint.
    is_sprinting = (Input.is_key_pressed(KEY_CTRL) or touch_move.length()>0.86) and stamina > 3.0
    var direction := Vector3.ZERO
    if input_vector.length() > .1:
        var forward := Vector3(sin(cam_yaw),0,-cos(cam_yaw))
        var right := Vector3(cos(cam_yaw),0,sin(cam_yaw))
        direction = (right*input_vector.x-forward*input_vector.y).normalized()
        hero_forward = direction
        if dodge_time <= 0.0:
            visual.rotation.y = lerp_angle(visual.rotation.y,atan2(direction.x,direction.z),minf(1.0,delta*11.0))
    # Grounded movement: accelerate toward input, but decelerate faster when released.
    # Walking into a wall must not make the character walk in place endlessly.
    hero_attack_pose = maxf(0.0,hero_attack_pose-delta)
    var speed := SPRINT_SPEED if is_sprinting else WALK_SPEED
    var desired_velocity: Vector3 = direction * speed
    if dodge_time > 0.0:
        dodge_time = maxf(0.0,dodge_time-delta)
        player.velocity = dodge_direction * 20.0
    else:
        var rate := MOVEMENT_ACCEL if direction.length() > .1 else MOVEMENT_BRAKE
        player.velocity = player.velocity.move_toward(desired_velocity,rate * delta)
    # During the dodge, visual orientation follows the committed dash trajectory.
    # Input, hero_forward, collision, damage and invulnerability stay untouched.
    if dodge_time > 0.0 and dodge_direction.length_squared() > 0.01 and not _focus_is_valid():
        visual.rotation.y = lerp_angle(visual.rotation.y,
            atan2(dodge_direction.x,dodge_direction.z),minf(1.0,delta*14.0))
    # Face the locked enemy while strafing; still allows freely controlled movement.
    if _focus_is_valid():
        var facing: Vector3 = focus_target.position-player.position
        facing.y = 0.0
        if facing.length_squared() > 0.1:
            hero_forward = facing.normalized()
            visual.rotation.y = lerp_angle(visual.rotation.y,atan2(facing.x,facing.z),minf(delta*12.0,1.0))
    var before_move: Vector3 = player.global_position
    var future: Vector3 = player.position + player.velocity * delta
    if not _blocked(future):
        player.move_and_slide()
    else:
        player.velocity = Vector3.ZERO
    var actual_distance: float = (player.global_position-before_move).length()
    var ground_speed: float = actual_distance/maxf(delta,0.001)
    # Advance the step cycle using traveled distance instead of input direction.
    # A blocked hero stops stepping and sprint stamina is not wasted on a wall.
    hero_gait_phase = fposmod(hero_gait_phase+actual_distance*STRIDE_RADIANS_PER_METER,TAU)
    var walking_blend := clampf(ground_speed/WALK_SPEED,0.0,1.0)
    # One damped stride blend for the whole actor; avoids hard starts/stops
    # in the visible body bob while keeping physics and stamina independent.
    var visual_stride_rate := 12.0 if walking_blend > hero_visual_stride else 15.0
    hero_visual_stride = lerpf(hero_visual_stride,walking_blend,
        1.0-exp(-maxf(delta,0.0)*visual_stride_rate))
    visual.position.y = lerpf(visual.position.y,
        sin(hero_gait_phase)*(.029 if is_sprinting else .020)*hero_visual_stride+
        sin(clock*1.9)*.011*(1.0-hero_visual_stride),minf(1.0,delta*9.0))
    if is_sprinting and actual_distance>0.002 and dodge_time<=0.0:
        stamina = maxf(0.0,stamina-10.0*delta)
    # Weighted torso/head turn, independent of collision and attack rules.
    var turn_lean: float = 0.0
    if ground_speed > 0.3 and player.velocity.length_squared() > 0.09:
        var movement_yaw: float = atan2(player.velocity.x, player.velocity.z)
        turn_lean = sin(movement_yaw - visual.rotation.y) * walking_blend
    hero_visual_turn = lerpf(hero_visual_turn,clampf(turn_lean,-1.0,1.0),
        1.0-exp(-maxf(delta,0.0)*9.0))
    # Bank slightly into turns, with no lingering tilt after releasing movement.
    visual.rotation.z = lerpf(visual.rotation.z,
        sin(hero_gait_phase*.5)*.012*hero_visual_stride + .043*hero_visual_turn,
        1.0-exp(-maxf(delta,0.0)*7.0))
    RIG_DRIVER.animate(hero_rig_parts,hero_gait_phase,walking_blend,
        hero_attack_pose,delta,is_sprinting,dodge_time,hit_flash,combo_step,
        maxf(clampf(parry_window/0.32,0.0,1.0),clampf(parry_success_flash/0.42,0.0,1.0)),turn_lean)
    # Stage 47: weapon uses the SAME already-smoothed gait, guard and sprint
    # parameters as the body shader. Mechanical parry duration remains unchanged.
    WEAPON_MOTION.animate(hero_weapon_mount,hero_gait_phase,
        float(hero_rig_parts.get("walk_blend",walking_blend)),
        hero_attack_pose,delta,combo_step,
        float(hero_rig_parts.get("guard_blend",0.0)),
        float(hero_rig_parts.get("run_blend",0.0)))
    dodge_invulnerable = maxf(0.0,dodge_invulnerable-delta)
    parry_window = maxf(0.0,parry_window-delta)
    parry_cooldown = maxf(0.0,parry_cooldown-delta)
    parry_success_flash = maxf(0.0,parry_success_flash-delta)
    hit_flash = maxf(0.0,hit_flash-delta)
    stamina = minf(100.0,stamina + (5.0 if is_sprinting else 14.0)*delta)
    mana = minf(70.0+float(level-1)*8.0,mana+3.0*delta)
    camera_rig.position = camera_rig.position.lerp(player.position+Vector3(0,1.65,0),minf(delta*7.0,1.0))
    camera_rig.rotation.y = lerp_angle(camera_rig.rotation.y,cam_yaw,minf(delta*7.0,1.0))
    view_camera.rotation.x = lerpf(view_camera.rotation.x,cam_pitch,minf(delta*7.0,1.0))
    # A restrained field-of-view change makes sprinting and lock-on feel deliberate.
    var camera_target_fov: float = 64.0 if (is_sprinting and ground_speed > 1.0) else (58.0 if _focus_is_valid() else 61.0)
    view_camera.fov = lerpf(view_camera.fov,camera_target_fov,minf(delta*3.0,1.0))
    # Static building occlusion: bring camera forward, rather than viewing through a roof.
    var from_point := player.global_position+Vector3(0,1.65,0)
    var ideal_target := camera_rig.global_transform * Vector3(0,camera_height,camera_distance)
    var ray_query := PhysicsRayQueryParameters3D.create(from_point, ideal_target, 4)
    ray_query.exclude = [player.get_rid()]
    var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(ray_query)
    var desired_range: float = camera_distance
    if hit.has("position"):
        desired_range = maxf(2.3,from_point.distance_to(hit["position"])-0.6)
    view_camera.position.z = lerpf(view_camera.position.z, desired_range, minf(delta*10.0,1.0))
    # Damped screen response: local camera offset only, never repositions the hero.
    view_camera.position.x = sin(clock*67.0)*camera_impact if camera_feedback_enabled else 0.0
    view_camera.position.y = 4.9+(cos(clock*49.0)*camera_impact*0.45 if camera_feedback_enabled else 0.0)
    camera_impact = maxf(0.0,camera_impact-delta*0.85)
    attack_cooldown = maxf(0.0,attack_cooldown-delta)
    combo_expiry = maxf(0.0,combo_expiry-delta)
    target_tick += delta
    if target_tick > 0.20:
        target_tick = 0.0
        _refresh_target_ring()
    spell_cooldown = maxf(0.0,spell_cooldown-delta)
    dodge_cooldown = maxf(0.0,dodge_cooldown-delta)
    hud_tick += delta
    world_tick += delta
    save_timer += delta
    adaptive_timer += delta
    waystone_rest_timer = maxf(0.0, waystone_rest_timer-delta)
    if adaptive_enabled and adaptive_timer > 2.0:
        adaptive_timer = 0.0
        smooth_fps = lerpf(smooth_fps, float(Engine.get_frames_per_second()), 0.5)
        if smooth_fps < 27.0 and mobile_resolution_scale > 0.67:
            mobile_resolution_scale = maxf(0.65,mobile_resolution_scale-0.08)
            get_viewport().scaling_3d_scale = mobile_resolution_scale
        elif smooth_fps > 42.0 and mobile_resolution_scale < 0.87:
            mobile_resolution_scale = minf(0.9,mobile_resolution_scale+0.035)
            get_viewport().scaling_3d_scale = mobile_resolution_scale
    if hud_tick > .18:
        hud_tick = 0.0
        _refresh_hud()
    if world_tick > .55:
        world_tick = 0.0
        _update_zone_visibility()
        _update_stage41_light_visibility()
        _update_stage41_debug()
        for i in range(enemies.size()-1,-1,-1):
            if not is_instance_valid(enemies[i]):
                enemies.remove_at(i)
    if message_timer > 0.0:
        message_timer -= delta
        if message_timer <= 0.0 and is_instance_valid(message_label):
            message_label.text = ""
    if save_timer > 22.0:
        save_timer = 0.0
        _save()

func _save() -> bool:
    var data := {
        "schema":6,"echo_mask":echo_glyph_mask,"echo_state":echo_state,"echo_wave":echo_wave,"echo_kills":echo_kills,"echo_rewarded":echo_rewarded,"rift_state":rift_state,"rift_wave":rift_wave,"rift_kills":rift_kills,"rift_rewarded":rift_rewarded,"memory_mask":moon_memory_mask,"memory_rewarded":moon_memory_rewarded,"smith_level":smith_level,"seal_mask":moon_seal_mask,"seal_state":moon_seal_state,"seal_kills":moon_seal_kills,"seal_rewarded":moon_seal_rewarded,"sanctuary_state":sanctuary_state,"sanctuary_kills":sanctuary_kills,"sanctuary_paid":sanctuary_rewarded,"beacons":beacons_mask,"beacons_paid":beacons_rewarded,"stage":quest_stage,"forest_kills":forest_defeated,"token":cave_token,
        "boss":boss_defeated,"level":level,"experience":exp_points,"gold":gold,"perfect_parries":perfect_parries,
        "health":health,"mana":mana,"potions":potions,"total_kills":total_defeated,
        "px":player.position.x,"pz":player.position.z,
        "checkpoint":checkpoint_unlocked,"rest_count":checkpoint_rest_count,
        "adaptive_quality":adaptive_enabled,"render_scale":mobile_resolution_scale,"camera_feedback":camera_feedback_enabled,"atmosphere_enabled":atmosphere_enabled,
        "lantern_step":moon_lantern_step,"lantern_rewarded":moon_lantern_rewarded,
        "day_clock":day_clock,
        "companion_recruited":companion_recruited,"companion_active":companion_active,
        "companion_strikes":companion_strikes,"companion_quest_rewarded":companion_quest_rewarded
    }
    # Stage 42: never truncate a healthy save just to write the next autosave.
    # Write a temporary file first, preserve the previous valid save, then swap.
    var file := FileAccess.open(SAVE_TEMP_PATH, FileAccess.WRITE)
    if file == null:
        push_warning("Shattered Moon: cannot open temporary save")
        return false
    file.store_string(JSON.stringify(data))
    file.flush()
    file.close()
    if _read_save_dictionary(SAVE_TEMP_PATH).is_empty():
        return false
    var source_path := ProjectSettings.globalize_path(SAVE_TEMP_PATH)
    var target_path := ProjectSettings.globalize_path(SAVE_PATH)
    var backup_path := ProjectSettings.globalize_path(SAVE_BACKUP_PATH)
    var previous_save := _read_save_dictionary(SAVE_PATH)
    if not previous_save.is_empty():
        # A damaged primary must never overwrite the last valid backup.
        if DirAccess.copy_absolute(target_path, backup_path) != OK:
            push_warning("Shattered Moon: could not protect previous save")
            return false
    var result := DirAccess.rename_absolute(source_path, target_path)
    if result != OK and FileAccess.file_exists(SAVE_PATH):
        # For platforms that refuse rename-over-existing, recovery requires a
        # valid backup before removing the original file.
        if _read_save_dictionary(SAVE_BACKUP_PATH).is_empty():
            return false
        if DirAccess.remove_absolute(target_path) != OK:
            return false
        result = DirAccess.rename_absolute(source_path, target_path)
        if result != OK:
            DirAccess.copy_absolute(backup_path, target_path)
    return result == OK

func _read_save_dictionary(path: String) -> Dictionary:
    if not FileAccess.file_exists(path):
        return {}
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return {}
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    if not (parsed is Dictionary):
        return {}
    var result: Dictionary = parsed
    # Older game stages contain 'stage', newer ones also have 'schema'.
    if not result.has("stage") and not result.has("schema"):
        return {}
    return result

func _restore() -> void:
    var data := _read_save_dictionary(SAVE_PATH)
    if data.is_empty():
        data = _read_save_dictionary(SAVE_BACKUP_PATH)
        if not data.is_empty():
            push_warning("Shattered Moon: primary save invalid; restored backup")
    if data.is_empty():
        return
    # Default new values for every older save, including Stage 14-17.
    echo_glyph_mask = clampi(int(data.get("echo_mask",0)),0,7)
    echo_state = clampi(int(data.get("echo_state",0)),0,3)
    echo_wave = clampi(int(data.get("echo_wave",0)),0,2)
    echo_kills = clampi(int(data.get("echo_kills",0)),0,2)
    echo_rewarded = bool(data.get("echo_rewarded",false))
    if echo_rewarded:
        echo_state = 3
        echo_glyph_mask = 7
    elif echo_state in [1,2]:
        # A fight/claim implies all runes were activated; repair interrupted saves.
        echo_glyph_mask = 7
    if echo_state == 1 and not echo_rewarded:
        if echo_wave == 0: echo_wave = 1
        if echo_wave == 1 and echo_kills >= 2:
            echo_wave = 2
            echo_kills = 0
        elif echo_wave == 2 and echo_kills >= 1:
            echo_state = 2
    _refresh_echo_markers()
    moon_memory_mask = clampi(int(data.get("memory_mask",0)),0,63)
    moon_memory_rewarded = bool(data.get("memory_rewarded",false))
    if moon_memory_rewarded:
        moon_memory_mask = 63
    _refresh_moon_memories()
    rift_rewarded = bool(data.get("rift_rewarded",false))
    rift_state = clampi(int(data.get("rift_state",0)),0,3)
    rift_wave = clampi(int(data.get("rift_wave",0)),0,3)
    rift_kills = clampi(int(data.get("rift_kills",0)),0,2)
    if rift_rewarded:
        rift_state = 3
    elif rift_state == 1 and rift_wave == 0:
        rift_wave = 1
    elif rift_state == 1 and rift_kills >= _rift_wave_size():
        rift_kills = _rift_wave_size()-1
    moon_seal_mask = clampi(int(data.get("seal_mask",0)),0,7)
    moon_seal_state = clampi(int(data.get("seal_state",0)),0,3)
    moon_seal_kills = clampi(int(data.get("seal_kills",0)),0,2)
    moon_seal_rewarded = bool(data.get("seal_rewarded",false))
    # Reconcile partial saves. Never duplicate defender waves or quest rewards.
    if moon_seal_rewarded: moon_seal_state = 3
    elif moon_seal_state == 1 and moon_seal_kills >= 2: moon_seal_state = 2
    elif moon_seal_state == 0 and moon_seal_mask == 7: moon_seal_state = 1
    sanctuary_state = clampi(int(data.get("sanctuary_state",0)),0,3)
    sanctuary_kills = clampi(int(data.get("sanctuary_kills",0)),0,3)
    sanctuary_rewarded = bool(data.get("sanctuary_paid",false))
    if sanctuary_rewarded:
        sanctuary_state = 3
    elif sanctuary_state == 1 and sanctuary_kills == 3:
        sanctuary_state = 2
    beacons_mask = clampi(int(data.get("beacons",0)),0,7)
    beacons_rewarded = bool(data.get("beacons_paid",false))
    quest_stage = clampi(int(data.get("stage",0)),0,5)
    forest_defeated = maxi(0,int(data.get("forest_kills",0)))
    cave_token = bool(data.get("token",false))
    boss_defeated = bool(data.get("boss",false))
    # Reconcile old save files made before boss-gating was added.
    if quest_stage == 3 and boss_defeated:
        quest_stage = 4
    elif quest_stage == 1 and forest_defeated >= 3:
        quest_stage = 2
    level = maxi(1,int(data.get("level",1)))
    exp_points = maxi(0,int(data.get("experience",0)))
    gold = maxi(0,int(data.get("gold",40)))
    smith_level = clampi(int(data.get("smith_level",0)),0,3)
    potions = maxi(0,int(data.get("potions",3)))
    total_defeated = maxi(0,int(data.get("total_kills",0)))
    perfect_parries = maxi(0,int(data.get("perfect_parries",0)))
    moon_lantern_step = clampi(int(data.get("lantern_step",0)),0,3)
    moon_lantern_rewarded = bool(data.get("lantern_rewarded",false))
    day_clock = fposmod(float(data.get("day_clock",155.0)),390.0)
    companion_recruited = bool(data.get("companion_recruited",false))
    companion_active = bool(data.get("companion_active",false)) and companion_recruited
    companion_strikes = clampi(int(data.get("companion_strikes",0)),0,3)
    companion_quest_rewarded = bool(data.get("companion_quest_rewarded",false))
    checkpoint_unlocked = clampi(int(data.get("checkpoint",0)),0,3)
    checkpoint_rest_count = maxi(0,int(data.get("rest_count",0)))
    adaptive_enabled = bool(data.get("adaptive_quality",true))
    camera_feedback_enabled = bool(data.get("camera_feedback",true))
    atmosphere_enabled = bool(data.get("atmosphere_enabled",true))
    mobile_resolution_scale = clampf(float(data.get("render_scale",.82)),.65,1.0)
    get_viewport().scaling_3d_scale = mobile_resolution_scale
    if checkpoint_unlocked > 0:
        checkpoint_position = beacon_anchors[checkpoint_unlocked-1]+Vector3(0,0,3.0)
    max_health = 100.0 + float(level-1)*18.0 + (25.0 if moon_memory_rewarded else 0.0)
    health = clampf(float(data.get("health",max_health)),1.0,max_health)
    mana = clampf(float(data.get("mana",70)),0.0,70.0+float(level-1)*8.0)
    var x := clampf(float(data.get("px",0)),-46.0,300.0)
    var z := clampf(float(data.get("pz",18)),-45.0,45.0)
    player.position = Vector3(x,0,z) if not _blocked(Vector3(x,0,z)) else Vector3(0,0,18)
    _refresh_rift_marker()
