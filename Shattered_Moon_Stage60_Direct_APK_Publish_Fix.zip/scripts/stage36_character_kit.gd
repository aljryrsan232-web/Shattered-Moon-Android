extends RefCounted
## Stage 36: original low-poly accessory GLB kits. Do not replace the actor's
## vertex-tagged motion surface; accessories follow the existing model root.
const HERO = preload("res://assets/stage36/hero_retro_armor.glb")
const RAYAN = preload("res://assets/stage36/rayan_retro_armor.glb")
const LAURA = preload("res://assets/stage36/laura_retro_jewelry.glb")
const SMITH = preload("res://assets/stage36/smith_retro_apron.glb")
const MERCHANT = preload("res://assets/stage36/merchant_retro_kit.glb")
const BRIAR = preload("res://assets/stage36/briar_retro_details.glb")
const WISP = preload("res://assets/stage36/wisp_retro_details.glb")
const SENTINEL = preload("res://assets/stage36/sentinel_retro_details.glb")

static func attach(actor: Node3D, role: String) -> Node3D:
    if actor == null:
        return null
    var resource: PackedScene
    match role:
        "hero": resource = HERO
        "rayan": resource = RAYAN
        "laura": resource = LAURA
        "smith": resource = SMITH
        "merchant": resource = MERCHANT
        "bramble", "shade_hunter": resource = BRIAR
        "wisp", "frost_wisp": resource = WISP
        "guardian", "rift_guardian", "echo_warden": resource = SENTINEL
        _: return null
    var accessory := resource.instantiate() as Node3D
    accessory.name = "Stage36_" + role + "_Kit"
    actor.add_child(accessory)
    # Cosmetic only. All colliders and combat stats remain original.
    return accessory
