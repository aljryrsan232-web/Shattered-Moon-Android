extends RefCounted
## Stage 33 original fantasy set-dressing. Geometry only; no colliders, signals or save data.

const WOOD = preload("res://assets/textures/retro_wood_planks_stage32.png")
const STONE = preload("res://assets/textures/retro_stone_blocks_stage32.png")
const WOOD_NORMAL = preload("res://assets/textures/retro_wood_normal_stage34.png")
const STONE_NORMAL = preload("res://assets/textures/retro_stone_normal_stage34.png")

static func _mat(texture: Texture2D, tint: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_texture = texture
    mat.albedo_color = tint
    mat.roughness = .88
    mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    mat.texture_repeat = BaseMaterial3D.TEXTURE_REPEAT_ENABLED
    if not OS.has_feature("mobile"):
        mat.normal_enabled = true
        mat.normal_texture = WOOD_NORMAL if texture == WOOD else STONE_NORMAL
        mat.normal_scale = .30 if texture == WOOD else .43
    return mat

static func _block(parent: Node3D, label: String, at: Vector3, size: Vector3, surface: Material) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.name = label
    var mesh := BoxMesh.new()
    mesh.size = size
    instance.mesh = mesh
    instance.position = at
    instance.material_override = surface
    parent.add_child(instance)
    return instance

static func _lamp(parent: Node3D, at: Vector3, hue: Color) -> void:
    var jewel := MeshInstance3D.new()
    jewel.name = "Stage33_Emissive_Lantern_Glass"
    var globe := SphereMesh.new()
    globe.radius = .22
    globe.height = .44
    globe.radial_segments = 8
    globe.rings = 4
    jewel.mesh = globe
    jewel.position = at
    var mat := StandardMaterial3D.new()
    mat.albedo_color = hue
    mat.emission_enabled = true
    mat.emission = hue
    mat.emission_energy_multiplier = 1.35
    jewel.material_override = mat
    jewel.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(jewel)
    # Avoid dynamic point lights on the mobile Compatibility renderer.

static func make_forest_watch_post(parent: Node3D, at: Vector3, yaw: float, factor: float = 1.0) -> Node3D:
    var root := Node3D.new()
    root.name = "Stage33_Forest_Lantern_Watchpost"
    root.position = at
    root.rotation.y = yaw
    root.scale = Vector3.ONE*factor
    parent.add_child(root)
    var timber := _mat(WOOD,Color(.66,.52,.40))
    var iron := StandardMaterial3D.new()
    iron.albedo_color = Color(.24,.26,.28)
    iron.metallic = .31
    iron.roughness = .68
    _block(root,"Timber_Support",Vector3(0,1.42,0),Vector3(.31,2.84,.36),timber)
    _block(root,"Angled_Bracket",Vector3(.38,2.55,0),Vector3(.95,.17,.25),timber).rotation.z = -.20
    _block(root,"Hanging_Frame",Vector3(.85,2.13,0),Vector3(.37,.55,.35),iron)
    _lamp(root,Vector3(.85,2.09,0),Color(1.0,.76,.42))
    _block(root,"Plank_Base",Vector3(0,.13,0),Vector3(1.1,.26,1.05),timber)
    # Dark metal fittings break up the plain rectangular silhouette.
    for py in [1.22,2.42]:
        _block(root,"Stage34_Iron_Bolt",Vector3(.165,py,-.19),Vector3(.08,.10,.07),iron)
    _block(root,"Stage34_Lantern_Ridge",Vector3(.85,2.47,0),Vector3(.46,.10,.44),iron)
    return root

static func make_stone_remnant(parent: Node3D, at: Vector3, yaw: float, factor: float = 1.0, glow: Color = Color(.55,.67,.93)) -> Node3D:
    var root := Node3D.new()
    root.name = "Stage33_Ruined_Stone_Gateway"
    root.position = at
    root.rotation.y = yaw
    root.scale = Vector3.ONE*factor
    parent.add_child(root)
    var masonry := _mat(STONE,Color(.76,.74,.71))
    var inset := StandardMaterial3D.new()
    inset.albedo_color = Color(.27,.30,.35)
    inset.roughness = .74
    for side in [-1.0,1.0]:
        _block(root,"Stone_Foundation",Vector3(side*1.35,.24,0),Vector3(.95,.48,.97),masonry)
        _block(root,"Weathered_Pillar",Vector3(side*1.35,1.63,0),Vector3(.68,2.38,.72),masonry)
        _block(root,"Inset_Carved_Rune",Vector3(side*1.35,1.88,-.38),Vector3(.17,.47,.04),inset)
    _block(root,"Broken_Arch_Lintel",Vector3(0,3.03,0),Vector3(3.65,.46,.89),masonry).rotation_degrees.z = 3.0
    var moss := StandardMaterial3D.new()
    moss.albedo_color = Color(.28,.38,.23)
    moss.roughness = .98
    # A few shallow patches; no extra light, collision or per-frame animation.
    _block(root,"Stage34_Moss_Left",Vector3(-1.35,.49,-.475),Vector3(.64,.08,.055),moss)
    _block(root,"Stage34_Moss_Right",Vector3(1.35,.64,-.37),Vector3(.42,.09,.055),moss)
    _lamp(root,Vector3(0,3.49,-.15),glow)
    return root
