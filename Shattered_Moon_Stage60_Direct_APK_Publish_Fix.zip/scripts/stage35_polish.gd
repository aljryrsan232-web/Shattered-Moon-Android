extends RefCounted
## Stage 35 presentation props: emissive windows, torches, benches and hanging signs.
## Cosmetic only; no collisions or gameplay changes.

static func _warm_material(color: Color, emission: Color = Color(0,0,0)) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = .86
    if emission != Color(0,0,0):
        mat.emission_enabled = true
        mat.emission = emission
        mat.emission_energy_multiplier = 1.15
    return mat

static func make_bench(parent: Node3D, at: Vector3, yaw: float, factor: float = 1.0) -> Node3D:
    var bench := Node3D.new()
    bench.name = "Stage35_Bench"
    bench.position = at
    bench.rotation.y = yaw
    bench.scale = Vector3.ONE * factor
    parent.add_child(bench)
    var wood := _warm_material(Color(.63,.45,.26))
    var dark := _warm_material(Color(.28,.20,.12))
    for x in [-.48,.48]:
        var leg := MeshInstance3D.new()
        var leg_mesh := BoxMesh.new()
        leg_mesh.size = Vector3(.11,.48,.11)
        leg.mesh = leg_mesh
        leg.position = Vector3(x,.24,-.12)
        leg.material_override = dark
        bench.add_child(leg)
        var leg2 := MeshInstance3D.new()
        leg2.mesh = leg_mesh
        leg2.position = Vector3(x,.24,.12)
        leg2.material_override = dark
        bench.add_child(leg2)
    var seat := MeshInstance3D.new()
    var seat_mesh := BoxMesh.new()
    seat_mesh.size = Vector3(1.35,.08,.42)
    seat.mesh = seat_mesh
    seat.position = Vector3(0,.52,0)
    seat.material_override = wood
    bench.add_child(seat)
    var back := MeshInstance3D.new()
    var back_mesh := BoxMesh.new()
    back_mesh.size = Vector3(1.28,.08,.38)
    back.mesh = back_mesh
    back.position = Vector3(0,.87,-.15)
    back.rotation_degrees.x = -18.0
    back.material_override = wood
    bench.add_child(back)
    return bench

static func make_window_glow(parent: Node3D, at: Vector3, yaw: float, size: Vector2 = Vector2(.95,1.15), color: Color = Color(1.0,.82,.47)) -> Node3D:
    var root := Node3D.new()
    root.name = "Stage35_WindowGlow"
    root.position = at
    root.rotation.y = yaw
    parent.add_child(root)
    var quad := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = size
    quad.mesh = plane
    quad.rotation_degrees = Vector3(0,90,0)
    var glow := _warm_material(Color(color.r,color.g,color.b,.92), color * .85)
    glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    glow.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    glow.cull_mode = BaseMaterial3D.CULL_DISABLED
    quad.material_override = glow
    root.add_child(quad)
    var light := OmniLight3D.new()
    light.position = Vector3(.32,0,0)
    light.light_color = color
    light.light_energy = .52 if OS.has_feature("mobile") else .70
    light.omni_range = 4.8 if OS.has_feature("mobile") else 6.0
    light.shadow_enabled = false
    root.add_child(light)
    light.add_to_group("shattered_moon_cosmetic_light")
    return root

static func make_torch(parent: Node3D, at: Vector3, yaw: float, factor: float = 1.0, flame: Color = Color(1.0,.62,.21)) -> Node3D:
    var torch := Node3D.new()
    torch.name = "Stage35_Torch"
    torch.position = at
    torch.rotation.y = yaw
    torch.scale = Vector3.ONE * factor
    parent.add_child(torch)
    var pole := MeshInstance3D.new()
    var pole_mesh := CylinderMesh.new()
    pole_mesh.top_radius = .05
    pole_mesh.bottom_radius = .06
    pole_mesh.height = 2.05
    pole.mesh = pole_mesh
    pole.position = Vector3(0,1.02,0)
    pole.material_override = _warm_material(Color(.38,.26,.15))
    torch.add_child(pole)
    var basket := MeshInstance3D.new()
    var basket_mesh := CylinderMesh.new()
    basket_mesh.top_radius = .13
    basket_mesh.bottom_radius = .17
    basket_mesh.height = .18
    basket.mesh = basket_mesh
    basket.position = Vector3(0,1.96,0)
    basket.material_override = _warm_material(Color(.30,.30,.31))
    torch.add_child(basket)
    var ember := MeshInstance3D.new()
    var ember_mesh := SphereMesh.new()
    ember_mesh.radius = .16
    ember_mesh.height = .32
    ember_mesh.radial_segments = 8
    ember_mesh.rings = 4
    ember.mesh = ember_mesh
    ember.position = Vector3(0,2.14,0)
    var e := _warm_material(flame, flame * .8)
    e.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    ember.material_override = e
    torch.add_child(ember)
    var light := OmniLight3D.new()
    light.position = Vector3(0,2.0,0)
    light.light_color = flame
    light.light_energy = .72 if OS.has_feature("mobile") else .96
    light.omni_range = 6.0 if OS.has_feature("mobile") else 7.5
    light.shadow_enabled = false
    torch.add_child(light)
    light.add_to_group("shattered_moon_cosmetic_light")
    return torch

static func make_hanging_sign(parent: Node3D, at: Vector3, yaw: float, factor: float = 1.0, panel_tint: Color = Color(.78,.69,.54)) -> Node3D:
    var sign := Node3D.new()
    sign.name = "Stage35_HangingSign"
    sign.position = at
    sign.rotation.y = yaw
    sign.scale = Vector3.ONE * factor
    parent.add_child(sign)
    var post := MeshInstance3D.new()
    var post_mesh := CylinderMesh.new()
    post_mesh.top_radius = .06
    post_mesh.bottom_radius = .07
    post_mesh.height = 2.55
    post.mesh = post_mesh
    post.position = Vector3(0,1.27,0)
    post.material_override = _warm_material(Color(.42,.29,.17))
    sign.add_child(post)
    var arm := MeshInstance3D.new()
    var arm_mesh := BoxMesh.new()
    arm_mesh.size = Vector3(.95,.09,.09)
    arm.mesh = arm_mesh
    arm.position = Vector3(.36,2.28,0)
    arm.material_override = _warm_material(Color(.42,.29,.17))
    sign.add_child(arm)
    var panel := MeshInstance3D.new()
    var panel_mesh := BoxMesh.new()
    panel_mesh.size = Vector3(.56,.42,.07)
    panel.mesh = panel_mesh
    panel.position = Vector3(.72,1.88,0)
    panel.material_override = _warm_material(panel_tint)
    sign.add_child(panel)
    return sign
