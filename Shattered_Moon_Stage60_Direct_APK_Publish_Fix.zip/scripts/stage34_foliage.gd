extends RefCounted
## Stage 34: one draw-batched, collison-free detail layer per region.
## No physics, scene tree loops, or save keys. This does not block roads or quest areas.

static func decorate(parent: Node3D, title: String, bounds: Rect2, amount: int, seed_value: int, tint: Color) -> void:
    var tufts := SurfaceTool.new()
    tufts.begin(Mesh.PRIMITIVE_TRIANGLES)
    for angle in [0.0, PI * .5]:
        var side := Vector3(cos(angle),0.0,sin(angle)) * .20
        var center := Vector3(.01,.03,.0)
        var first := center-side
        var second := center+side
        var top := center+Vector3(.04,.60,.05)
        for v in [first, second, top]:
            tufts.set_normal(Vector3.UP)
            tufts.add_vertex(v)
    var mesh := tufts.commit()
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(.9,.93,.83)
    material.vertex_color_use_as_albedo = true
    material.cull_mode = BaseMaterial3D.CULL_DISABLED
    material.roughness = .96
    mesh.surface_set_material(0,material)
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    multi.use_colors = true
    multi.mesh = mesh
    var density: int = amount / 2 if OS.has_feature("mobile") else amount
    multi.instance_count = density
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    var added: int = 0
    for attempt in range(density * 22):
        if added >= density:
            break
        var x := rng.randf_range(bounds.position.x, bounds.end.x)
        var z := rng.randf_range(bounds.position.y, bounds.end.y)
        if absf(z) < (13.0 if title == "Wildwood" else 10.0):
            continue
        if title == "Wildwood" and Vector2(x,z).distance_squared_to(Vector2(96,30)) < 120.0:
            continue
        if title == "Echo Valley" and Vector2(x,z).distance_squared_to(Vector2(291,8)) < 140.0:
            continue
        var size := rng.randf_range(.6,1.7)
        var rotation := Basis(Vector3.UP,rng.randf_range(-PI,PI))
        multi.set_instance_transform(added,Transform3D(rotation.scaled(Vector3.ONE*size),Vector3(x,.025,z)))
        var variation := rng.randf_range(.79,1.1)
        multi.set_instance_color(added,Color(minf(1.0,tint.r*variation),minf(1.0,tint.g*variation),minf(1.0,tint.b*variation)))
        added += 1
    multi.visible_instance_count = added
    var field := MultiMeshInstance3D.new()
    field.name = "Stage34_" + title.replace(" ","_") + "_Wildflowers"
    field.multimesh = multi
    field.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    field.custom_aabb = AABB(Vector3(bounds.position.x,-1.0,bounds.position.y),Vector3(bounds.size.x,2.9,bounds.size.y))
    parent.add_child(field)
