extends Control
## Receives the resume shortcut even when the SceneTree is paused.
var director: Node3D
func _input(event: InputEvent) -> void:
    if not visible or not is_instance_valid(director):
        return
    if event.is_action_pressed("quest_journal"):
        if event is InputEventKey and event.echo:
            return
        director.call("_toggle_journal")
        get_viewport().set_input_as_handled()
        return
    if event.is_action_pressed("ui_cancel") or event.is_action_pressed("pause_game"):
        if event is InputEventKey and event.echo:
            return
        director.call("_toggle_pause")
        get_viewport().set_input_as_handled()
