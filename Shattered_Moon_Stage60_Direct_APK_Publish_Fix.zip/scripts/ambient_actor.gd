extends Node
## Stage 31: cosmetic NPC/horse idle motion. No physics, navigation or quest state.
const RIG_DRIVER = preload("res://scripts/rig_driver.gd")

var actor: Node3D
var director: Node3D
var kind: String = "villager"
var parts: Dictionary = {}
var initial_y: float = 0.0
var initial_yaw: float = 0.0
var phase: float = 0.0
var elapsed: float = 0.0

func configure(target: Node3D, controller: Node3D, actor_kind: String, rig_state: Dictionary, seed: float) -> void:
    actor = target
    director = controller
    kind = actor_kind
    parts = rig_state
    phase = seed
    initial_y = target.position.y
    initial_yaw = target.rotation.y
    set_process(true)

func _process(delta: float) -> void:
    if not is_instance_valid(actor) or not is_instance_valid(director):
        set_process(false)
        return
    if not actor.is_visible_in_tree():
        return
    var hero: Node3D = director.get("player") as Node3D
    if not is_instance_valid(hero):
        return
    var relative: Vector3 = hero.global_position - actor.global_position
    relative.y = 0.0
    if relative.length_squared() > 2500.0:
        return # Do not animate remote zones.
    elapsed += delta
    if kind == "horse":
        actor.position.y = initial_y + sin(elapsed*1.55+phase)*.016
        actor.rotation.y = initial_yaw + sin(elapsed*.72+phase)*.07
        return
    # A subtle idle breath; the existing per-part human shader also breathes.
    actor.position.y = initial_y + sin(elapsed*1.75+phase)*.010
    var target_yaw := initial_yaw
    if relative.length_squared() < 37.0 and relative.length_squared() > .01:
        target_yaw = atan2(relative.x, relative.z)
    var turn_speed := 1.8 if kind == "merchant" else 1.1
    actor.rotation.y = lerp_angle(actor.rotation.y, target_yaw, minf(1.0,delta*turn_speed))
    if not parts.is_empty():
        RIG_DRIVER.animate(parts, 0.0, 0.0, 0.0, delta)
