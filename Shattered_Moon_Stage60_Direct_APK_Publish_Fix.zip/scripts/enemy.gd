extends CharacterBody3D
const STAGE36_CHARACTER_KIT = preload("res://scripts/stage37_character_kit.gd")
## Small, self-contained AI controller for original GLB creatures.
## No external plugins or resources required besides the imported meshes.

signal defeated(enemy_type: String)
signal hero_hit(damage: float, attacker: Node3D)

var enemy_type: String = "bramble"
var target: Node3D
var model: Node3D
var hp: float = 50.0
var max_hp: float = 50.0
var speed: float = 2.1
var damage: float = 11.0
var attack_timer: float = 0.0
var windup: float = 0.0
var stagger_timer: float = 0.0
var animation_clock: float = 0.0
var dead: bool = false
var hero_in_range: bool = false
var name_label: Label3D
var display_name: String = "Briar Stalker"
var is_boss: bool = false
var origin: Vector3
var telegraph: MeshInstance3D
var close_detail_visible: bool = true
# Stage 17: readable boss phases with alternating cone/melee and radial shockwave.
var enraged: bool = false
var attack_counter: int = 0
var slam_active: bool = false
var attack_radius: float = 0.0
var charged_target_pos: Vector3 = Vector3.ZERO # Frost spell has a dodgeable ground target.
var impact_reaction: float = 0.0
# Stage 49: purely cosmetic follow-through after a telegraphed attack.
var strike_follow_through: float = 0.0
var windup_initial: float = 0.0
var model_rest_scale: Vector3 = Vector3.ONE
# Stage 32: distinct boss phase-II ground glyph. Cosmetic only; collisions and damage unchanged.
var phase_aura: MeshInstance3D
# Stage 33: visual-only accessories, distinguish the three guardian encounters.
var stage33_boss_shards: Array[MeshInstance3D] = []
var stage33_boss_tint: Color = Color(.88,.59,.27)


func _apply_retro_enemy_finish(accent: Color, strength: float = 0.14) -> void:
    for child_mesh in model.find_children("*","MeshInstance3D",true,false):
        var part := child_mesh as MeshInstance3D
        var overlay := StandardMaterial3D.new()
        overlay.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
        overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        overlay.albedo_color = Color(accent.r, accent.g, accent.b, strength)
        overlay.emission_enabled = true
        overlay.emission = accent * 0.10
        overlay.roughness = 0.94
        part.material_overlay = overlay


func _retro_creature_spike(local_position: Vector3, size: Vector3, tint: Color) -> void:
    var spike := MeshInstance3D.new()
    var mesh := PrismMesh.new()
    mesh.size = size
    spike.mesh = mesh
    spike.position = local_position
    spike.rotation_degrees.z = -14.0 if local_position.x > 0.0 else 14.0
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    mat.roughness = .84
    spike.material_override = mat
    model.add_child(spike)

func _build_retro_creature_silhouette(kind: String) -> void:
    # Additional horns and shoulder spikes are cosmetic; combat collision stays the same.
    if kind in ["bramble", "shade_hunter"]:
        _retro_creature_spike(Vector3(-.69,2.53,.02),Vector3(.27,.73,.25),Color(.35,.30,.17))
        _retro_creature_spike(Vector3(.69,2.53,.02),Vector3(.27,.73,.25),Color(.35,.30,.17))
    elif kind in ["wisp", "frost_wisp"]:
        _retro_creature_spike(Vector3(-.35,2.45,-.14),Vector3(.22,.59,.19),Color(.30,.56,.66))
        _retro_creature_spike(Vector3(.35,2.45,-.14),Vector3(.22,.59,.19),Color(.30,.56,.66))
    else:
        _retro_creature_spike(Vector3(-1.10,3.25,0),Vector3(.48,1.10,.41),Color(.23,.27,.35))
        _retro_creature_spike(Vector3(1.10,3.25,0),Vector3(.48,1.10,.41),Color(.23,.27,.35))

func _stage33_mesh_part(parent: Node3D, label: String, mesh: PrimitiveMesh, at: Vector3, tint: Color, luminous: bool = false) -> MeshInstance3D:
    var part := MeshInstance3D.new()
    part.name = label
    part.mesh = mesh
    part.position = at
    part.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF if luminous else GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    var material := StandardMaterial3D.new()
    material.albedo_color = tint
    material.roughness = .56 if luminous else .81
    material.metallic = .12 if luminous else .28
    if luminous:
        material.emission_enabled = true
        material.emission = tint
        material.emission_energy_multiplier = 1.45
    part.material_override = material
    parent.add_child(part)
    return part

func _build_stage33_boss_regalia() -> void:
    if not is_boss:
        return
    # Unique color and helmet outline per guardian; remains attached to model pose.
    if enemy_type == "echo_warden":
        stage33_boss_tint = Color(.67,.36,.91)
    elif enemy_type == "rift_guardian":
        stage33_boss_tint = Color(.33,.74,.75)
    else:
        stage33_boss_tint = Color(.89,.54,.21)
    var armor := Color(.24,.29,.38) if enemy_type != "guardian" else Color(.35,.32,.29)
    var visor := BoxMesh.new()
    visor.size = Vector3(.92,.20,.28)
    _stage33_mesh_part(model,"Stage33_Crest_Visor",visor,Vector3(0,3.72,-.45),armor)
    var crown := CylinderMesh.new()
    crown.top_radius = .12
    crown.bottom_radius = .43
    crown.height = .63
    _stage33_mesh_part(model,"Stage33_Guardian_Crest",crown,Vector3(0,4.16,0),stage33_boss_tint)
    for side in [-1.0,1.0]:
        var shoulder := PrismMesh.new()
        shoulder.size = Vector3(.75,.54,.84)
        var plate := _stage33_mesh_part(model,"Stage33_Shoulder_Plate",shoulder,Vector3(side*1.15,2.89,0),armor)
        plate.rotation_degrees.z = -18.0 * side
        var inlay := BoxMesh.new()
        inlay.size = Vector3(.18,.12,.74)
        _stage33_mesh_part(model,"Stage33_Shoulder_Emblem",inlay,Vector3(side*1.25,3.15,-.12),stage33_boss_tint,true)
    # Four low-poly energy crystals orbit only after phase-II unlock. No hitboxes.
    for i in range(4):
        var shard_mesh := PrismMesh.new()
        shard_mesh.size = Vector3(.23,.58,.25)
        var shard := _stage33_mesh_part(self,"Stage33_Orbiting_Rune_%d" % i,shard_mesh,Vector3.ZERO,stage33_boss_tint,true)
        shard.visible = false
        stage33_boss_shards.append(shard)

func setup(kind: String, appearance: PackedScene, hero: Node3D, boss: bool = false) -> void:
    enemy_type = kind
    target = hero
    is_boss = boss
    if kind == "bramble":
        hp = 65.0
        speed = 2.8
        damage = 10.0
        display_name = "Briar Stalker"
    elif kind == "wisp":
        hp = 72.0
        speed = 2.2
        damage = 14.0
        display_name = "Mist Lantern"
    elif kind == "shade_hunter":
        hp = 108.0
        speed = 4.1
        damage = 17.0
        display_name = "Shade Hunter"
    elif kind == "frost_wisp":
        hp = 89.0
        speed = 2.5
        damage = 18.0
        display_name = "Frost Wisp"
    elif kind in ["guardian","rift_guardian","echo_warden"]:
        hp = 440.0 if kind == "echo_warden" else (340.0 if kind == "rift_guardian" else 310.0)
        speed = 2.25 if kind == "echo_warden" else 1.9
        damage = 29.0 if kind == "echo_warden" else 24.0
        display_name = "Echo Warden" if kind == "echo_warden" else ("Rift Sentinel" if kind == "rift_guardian" else "Basalt Sentinel")
    max_hp = hp
    origin = position
    collision_layer = 2
    collision_mask = 4
    var capsule_collider := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.84 if boss else 0.56
    shape.height = 3.5 if boss else 2.2
    capsule_collider.shape = shape
    capsule_collider.position.y = 1.8 if boss else 1.15
    add_child(capsule_collider)
    model = appearance.instantiate() as Node3D
    add_child(model)
    if kind in ["shade_hunter","frost_wisp","echo_warden"]:
        # Material overlay preserves textures and makes the new enemies readable.
        var overlay := StandardMaterial3D.new()
        overlay.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        overlay.albedo_color = Color(.55,.22,.92,.28) if kind == "shade_hunter" else (Color(.33,.81,1.0,.29) if kind == "frost_wisp" else Color(.72,.41,1.0,.26))
        overlay.emission_enabled = true
        overlay.emission = overlay.albedo_color
        for child_mesh in model.find_children("*","MeshInstance3D",true,false):
            var part := child_mesh as MeshInstance3D
            part.material_overlay = overlay
        if kind == "shade_hunter": model.scale = Vector3(1.06,.94,1.06)
        elif kind == "frost_wisp": model.scale = Vector3.ONE*1.16
    if kind == "bramble":
        _apply_retro_enemy_finish(Color(.23,.46,.19), .10)
        model.scale *= Vector3(1.04,1.02,1.04)
    elif kind == "wisp":
        _apply_retro_enemy_finish(Color(.31,.66,.84), .14)
        model.scale *= Vector3.ONE*1.12
    elif kind == "shade_hunter":
        _apply_retro_enemy_finish(Color(.52,.24,.75), .12)
    elif kind == "frost_wisp":
        _apply_retro_enemy_finish(Color(.39,.76,.95), .13)
    else:
        _apply_retro_enemy_finish(Color(.62,.41,.19), .10)
    _build_retro_creature_silhouette(kind)
    STAGE36_CHARACTER_KIT.attach(model, kind)
    name_label = Label3D.new()
    name_label.text = display_name
    name_label.font_size = 28
    name_label.pixel_size = 0.006
    name_label.outline_size = 8
    name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    name_label.position.y = 4.7 if boss else 3.25
    add_child(name_label)
    if boss:
        model.scale = Vector3.ONE * 1.35
        _build_stage33_boss_regalia()
    model_rest_scale = model.scale
    telegraph = MeshInstance3D.new()
    var ring := TorusMesh.new()
    ring.inner_radius = 1.25 if not boss else 2.15
    ring.outer_radius = 1.41 if not boss else 2.35
    ring.rings = 8
    ring.ring_segments = 24
    telegraph.mesh = ring
    telegraph.position.y = 0.075
    var danger := StandardMaterial3D.new()
    danger.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    danger.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    danger.albedo_color = Color(.29,.80,1.0,.80) if kind == "frost_wisp" else Color(1.0,.20,.11,.80)
    danger.emission_enabled = true
    danger.emission = Color(.11,.60,.95) if kind == "frost_wisp" else Color(.95,.12,.04)
    telegraph.material_override = danger
    telegraph.visible = false
    add_child(telegraph)

    if is_boss:
        phase_aura = MeshInstance3D.new()
        phase_aura.name = "Stage32_Boss_Phase_II_Glyph"
        var aura_mesh := TorusMesh.new()
        aura_mesh.inner_radius = 2.35
        aura_mesh.outer_radius = 2.43
        aura_mesh.rings = 8
        aura_mesh.ring_segments = 48
        phase_aura.mesh = aura_mesh
        phase_aura.position.y = .09
        phase_aura.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var aura_material := StandardMaterial3D.new()
        aura_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        aura_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        aura_material.albedo_color = Color(stage33_boss_tint.r,stage33_boss_tint.g,stage33_boss_tint.b,.54)
        aura_material.emission_enabled = true
        aura_material.emission = stage33_boss_tint.darkened(.38)
        phase_aura.material_override = aura_material
        phase_aura.visible = false
        add_child(phase_aura)

func take_hit(amount: float, from_position: Vector3) -> void:
    if dead:
        return
    hp = maxf(0.0, hp - amount)
    stagger_timer = 0.20 if not is_boss else 0.07
    impact_reaction = 0.25
    if is_boss and not enraged and hp > 0.0 and hp <= max_hp*.50:
        enraged = true
        damage *= 1.35
        speed *= 1.20
        display_name += " · Phase II"
        if is_instance_valid(telegraph):
            var danger := telegraph.material_override as StandardMaterial3D
            danger.albedo_color = Color(1.0,.39,.14,.85)
            danger.emission = Color(1.0,.22,.05)
    var away := position - from_position
    away.y = 0.0
    if away.length() > 0.01:
        move_and_collide(away.normalized() * (0.45 if not is_boss else 0.16))
    _refresh_name()
    if hp <= 0.0:
        dead = true
        defeated.emit(enemy_type)
        # Leave a small defeat effect: model sinks before it is removed.
        var tween := create_tween()
        tween.tween_property(model, "position:y", -1.9, 0.55)
        tween.tween_callback(queue_free)

func interrupt_attack(stagger: float = 0.7) -> void:
    # A successful parry interrupts queued attacks, including boss slams.
    if dead:
        return
    windup = 0.0
    slam_active = false
    stagger_timer = maxf(stagger_timer,stagger)
    attack_timer = maxf(attack_timer,stagger+0.3)
    if is_instance_valid(telegraph):
        telegraph.visible = false
    _refresh_name()

func _refresh_name() -> void:
    if name_label != null:
        name_label.text = "%s  %d/%d" % [display_name, ceili(hp), ceili(max_hp)]
        name_label.modulate = Color(1.0, 0.60, 0.50) if hp < max_hp * 0.35 else Color(1.0, 1.0, 1.0)

func _physics_process(delta: float) -> void:
    if target == null or dead or model == null:
        return
    var dist := position.distance_to(target.position)
    # Disable heavy AI animation/steering outside the currently played region.
    if dist > 43.0:
        model.visible = false
        name_label.visible = false
        telegraph.visible = false
        if is_instance_valid(phase_aura):
            phase_aura.visible = false
        for shard in stage33_boss_shards:
            shard.visible = false
        velocity = Vector3.ZERO
        return
    model.visible = true
    # The enemy's model faces its opponent while winding up; the collider, AI
    # movement and charged target position are deliberately not rotated.
    if windup > 0.0:
        var aim_pos: Vector3 = charged_target_pos if enemy_type == "frost_wisp" else target.global_position
        var toward_aim: Vector3 = aim_pos - global_position
        toward_aim.y = 0.0
        if toward_aim.length_squared() > 0.01:
            model.rotation.y = lerp_angle(model.rotation.y,
                atan2(toward_aim.x,toward_aim.z),minf(1.0,maxf(delta,0.0)*8.0))
    # Phase-II crystals provide a non-verbal indication of danger and add no damage.
    for i in range(stage33_boss_shards.size()):
        var shard := stage33_boss_shards[i]
        shard.visible = enraged
        if enraged:
            var angle := animation_clock*1.14 + TAU*float(i)/4.0
            shard.position = Vector3(cos(angle)*2.40, 2.45+.24*sin(angle*1.9), sin(angle)*2.40)
            shard.rotation.y = angle
    if is_instance_valid(phase_aura):
        phase_aura.visible = enraged
        if enraged:
            var aura_pulse := 1.0 + .085*sin(animation_clock*3.8)
            phase_aura.scale = Vector3(aura_pulse,1.0,aura_pulse)
    name_label.visible = dist < 23.0
    animation_clock += delta
    # Stage 30: a visible anticipation and recoil pose, without modifying any hit timing.
    var anticipation: float = (1.0-clampf(windup/maxf(windup_initial,0.01),0.0,1.0)) if windup > 0.0 else 0.0
    var recoil_strength: float = clampf(impact_reaction/0.25,0.0,1.0)
    var follow_strength: float = clampf(strike_follow_through/0.18,0.0,1.0)
    model.position.y = sin(animation_clock * (2.8 if is_boss else 5.0)) * (0.11 if enemy_type == "wisp" else .035) - .06*anticipation
    model.rotation.x = lerpf(model.rotation.x,
        -.17*anticipation+.10*recoil_strength+.085*follow_strength,minf(delta*14.0,1.0))
    # Heavy guardians lean into a charged strike; minor enemies shift laterally.
    var attack_lean := .072 if is_boss else .035
    model.rotation.z = (sin(animation_clock * 3.0) * .025 + recoil_strength*.16
        + sin(animation_clock*2.8)*attack_lean*anticipation - .065*follow_strength)
    model.scale = model_rest_scale*(1.0+impact_reaction*.16)*(1.0+.035*anticipation)
    impact_reaction = maxf(0.0,impact_reaction-delta)
    strike_follow_through = maxf(0.0,strike_follow_through-delta)
    telegraph.visible = windup > 0.0
    if telegraph.visible:
        if enemy_type == "frost_wisp":
            telegraph.position = to_local(charged_target_pos) + Vector3(0.0,.075,0.0)
        # Ring strengthens as the impact approaches; keep the existing attack
        # radius and time window exactly as before (display-only effect).
        var size := (.95 + .09*sin(animation_clock*22.0))*(2.20 if slam_active else (1.55 if enemy_type == "frost_wisp" else 1.0))
        telegraph.scale = Vector3(size,1.0,size)
        var warning_mat := telegraph.material_override as StandardMaterial3D
        if warning_mat != null:
            var warning_color: Color = warning_mat.albedo_color
            warning_color.a = .56 + .36*anticipation
            warning_mat.albedo_color = warning_color
    attack_timer = maxf(0.0, attack_timer - delta)
    stagger_timer = maxf(0.0, stagger_timer - delta)
    if stagger_timer > 0.0:
        return
    if windup > 0.0:
        windup -= delta
        if windup <= 0.0:
            telegraph.visible = false
            # Follow-through is driven by the actual windup completion, not a
            # separate timer that could drift away from the hit signal.
            strike_follow_through = 0.18
            # Ground slam is a circular hazard; melee needs clear line of sight.
            if slam_active:
                if position.distance_to(target.position) < attack_radius and absf(position.y-target.position.y) < 2.5:
                    hero_hit.emit(damage*1.12,self)
            elif position.distance_to(target.position) < (9.2 if enemy_type == "frost_wisp" else (4.2 if is_boss else 2.8)) and (enemy_type != "frost_wisp" or target.position.distance_to(charged_target_pos) < 2.5):
                var query := PhysicsRayQueryParameters3D.create(global_position + Vector3(0,1.3,0), target.global_position + Vector3(0,1.3,0),4)
                query.exclude = [get_rid()]
                if get_world_3d().direct_space_state.intersect_ray(query).is_empty():
                    hero_hit.emit(damage,self)
            slam_active = false
        return
    var delta_to_hero := target.position - position
    delta_to_hero.y = 0.0
    var distance := delta_to_hero.length()
    var preferred_range := 6.6 if enemy_type == "frost_wisp" else (3.0 if is_boss else 2.0)
    if distance > preferred_range and distance < 35.0:
        var direction := delta_to_hero.normalized()
        if enemy_type == "shade_hunter":
            var flank := Vector3(-direction.z,0.0,direction.x)
            direction = (direction + flank * sin(animation_clock*1.7)*.52).normalized()
        velocity = direction * speed
        move_and_slide()
        model.rotation.y = lerp_angle(model.rotation.y, atan2(direction.x, direction.z), minf(1.0, delta * 7.0))
    elif attack_timer <= 0.0 and distance <= (8.2 if enemy_type == "frost_wisp" else (3.5 if is_boss else 2.4)):
        # Telegraph gives time for a dodge; actual damage only at windup end.
        velocity = Vector3.ZERO
        attack_counter += 1
        slam_active = is_boss and (attack_counter % 2 == 0)
        if enemy_type == "frost_wisp":
            charged_target_pos = target.global_position
        attack_radius = 5.3 if enraged else 4.8
        if slam_active:
            windup = 1.05 if enraged else 1.32
        else:
            windup = (0.66 if enraged else 0.82) if is_boss else (0.9 if enemy_type == "frost_wisp" else (0.43 if enemy_type == "shade_hunter" else 0.54))
        windup_initial = windup
        attack_timer = (2.0 if enraged else 2.55) if is_boss else (2.4 if enemy_type == "frost_wisp" else (1.4 if enemy_type == "shade_hunter" else 1.65))
        name_label.modulate = Color(1.0, 0.35, 0.20)
        get_tree().create_timer(windup).timeout.connect(_refresh_name)
