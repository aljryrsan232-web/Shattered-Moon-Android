extends RefCounted
## Stage 13 human animation controller, per-actor state and continuous gait phase.
## Safe on mobile: vertex motion is entirely performed on GPU; no CPU mesh copying.
const SHADER = preload("res://shaders/hero_motion.gdshader")

static func get_parts(root: Node3D) -> Dictionary:
    for child in root.find_children("*", "MeshInstance3D", true, false):
        var mesh := child as MeshInstance3D
        if mesh == null:
            continue
        var mat := ShaderMaterial.new()
        mat.shader = SHADER
        # Quality-scaled without changing animation state or saving extra settings.
        mat.set_shader_parameter("hair_motion_intensity", 0.64 if OS.has_feature("mobile") else 1.0)
        # Same shader as Stage 45; optional cape deformation is cheaper on mobile.
        mat.set_shader_parameter("cape_motion_intensity", 0.68 if OS.has_feature("mobile") else 1.0)
        # Each GLB actor is a single combined-color surface.
        mesh.set_surface_override_material(0,mat)
        # Stage 43: register the single per-actor shader for infrequent day/night updates.
        # Accessories reuse this ShaderMaterial, so only one update per actor is needed.
        root.add_to_group("moon_stage43_lit_actors")
        root.set_meta("moon_stage43_character_material",mat)
        return {"shader":mat,"walk_blend":0.0,"run_blend":0.0,"dodge_blend":0.0,"hurt_blend":0.0,"turn_blend":0.0,"guard_blend":0.0,"elapsed":0.0}
    return {}

static func animate(parts: Dictionary, phase: float, locomotion: float, attack_left: float, delta: float,
        sprinting: bool = false, dodge_left: float = 0.0, hurt_left: float = 0.0, combo: int = 1, guard_pose: float = 0.0, turn_amount: float = 0.0) -> void:
    if not parts.has("shader"):
        return
    var mat: ShaderMaterial = parts["shader"]
    parts["elapsed"] = float(parts.get("elapsed",0.0))+maxf(0.0,delta)
    var blend := 1.0-exp(-maxf(delta,0.0)*11.0)
    parts["walk_blend"] = lerpf(float(parts.get("walk_blend",0.0)),clampf(locomotion,0.0,1.0),blend)
    parts["run_blend"] = lerpf(float(parts.get("run_blend",0.0)),1.0 if sprinting else 0.0,blend)
    parts["dodge_blend"] = lerpf(float(parts.get("dodge_blend",0.0)),clampf(dodge_left/0.19,0.0,1.0),blend)
    parts["hurt_blend"] = lerpf(float(parts.get("hurt_blend",0.0)),clampf(hurt_left/0.22,0.0,1.0),blend)
    parts["turn_blend"] = lerpf(float(parts.get("turn_blend",0.0)),clampf(turn_amount,-1.0,1.0),blend)
    # Stage 47: guard rises and falls smoothly, then the identical value drives
    # the body and the weapon. This does not alter parry timing or invulnerability.
    var guard_speed := 19.0 if guard_pose > float(parts.get("guard_blend",0.0)) else 13.0
    var guard_blend_amount := 1.0-exp(-maxf(delta,0.0)*guard_speed)
    parts["guard_blend"] = lerpf(float(parts.get("guard_blend",0.0)),clampf(guard_pose,0.0,1.0),guard_blend_amount)
    var strike_progress := 1.0-clampf(attack_left/0.42,0.0,1.0) if attack_left>0.0 else 0.0
    mat.set_shader_parameter("gait_phase",phase)
    mat.set_shader_parameter("locomotion",parts["walk_blend"])
    mat.set_shader_parameter("sprint",parts["run_blend"])
    mat.set_shader_parameter("strike",strike_progress)
    mat.set_shader_parameter("combo_side",-1.0 if combo==2 else 1.0)
    mat.set_shader_parameter("dodge",parts["dodge_blend"])
    mat.set_shader_parameter("recoil",parts["hurt_blend"])
    mat.set_shader_parameter("breathing",.5+.5*sin(float(parts["elapsed"])*2.1))
    mat.set_shader_parameter("motion_time",float(parts["elapsed"]))
    mat.set_shader_parameter("guard",parts["guard_blend"])
    mat.set_shader_parameter("turn_lean",parts["turn_blend"])
