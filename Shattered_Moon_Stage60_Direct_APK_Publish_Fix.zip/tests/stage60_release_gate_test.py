#!/usr/bin/env python3
"""Stage 60 CI/release tests. Purely static; not a Godot runtime or APK build."""
from pathlib import Path
import json, hashlib, subprocess, sys, yaml
root=Path(__file__).resolve().parents[1]
yml=(root/'.github/workflows/build-android-apk.yml').read_text()
config=(root/'export_presets.cfg').read_text()
checks=[]
def check(msg,cond):checks.append((msg,bool(cond)))
parsed=yaml.safe_load(yml)
check('GitHub YAML can be parsed',isinstance(parsed,dict) and 'jobs' in parsed)
check('Android job is configured','android' in parsed.get('jobs',{}))
check('manual publication option is disabled by default', 'publish_direct_apk' in yml and 'default: false' in yml)
check('publication restricted to successful manual opt-in',"success() && github.event_name == 'workflow_dispatch' && inputs.publish_direct_apk" in yml)
check('automatic push never creates a published release', 'github.event_name == \'workflow_dispatch\'' in yml)
check('release is explicitly marked untested', 'UNTESTED' in yml and '--prerelease' in yml)
check('release not stuck as a draft', '--draft' not in yml)
check('direct download URL recorded', 'gh release view "$TAG" --json url --jq .url' in yml)
check('no publish prior to engine, signature and APK checks',yml.index('python3 tools/verify_apk.py builds/')<yml.index('apksigner" verify --verbose')<yml.index('name: Publish direct verified APK'))
check('unsigned APK never uploaded', 'if: success()' in yml)
check('run-time smoke still required','STAGE59_LAUNCH_SMOKE: PASS' in yml and 'stage59_launch_smoke.gd' in yml)
check('version in APK preset','version/code=60' in config and 'version/name="0.60.0"' in config)
check('Android ARM64','architectures/arm64-v8a=true' in config)
check('Android package identifier stable','package/unique_name="org.shatteredmoon.rebuild"' in config)
check('user data save scope stable', 'config/name="Shattered Moon — Stage 41 — Performance Preflight"' in (root/'project.godot').read_text())
check('no fake APK shipped',not list(root.rglob('*.apk')))
check('no signing secret shipped',not list(root.rglob('*.keystore')) and not list(root.rglob('*.jks')))
protected=json.loads((root/'docs/STAGE60_PROTECTED_BASELINE_SHA256.json').read_text())
for path,digest in protected.items():
 p=root/path
 check('protected '+path,p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==digest)
problems=[name for name,pass_ in checks if not pass_]
print(json.dumps(dict(stage=60,checks=len(checks),passed=len(checks)-len(problems),failed=problems,apk_built=False,godot_runtime_tested=False),ensure_ascii=False,indent=2))
sys.exit(bool(problems))
