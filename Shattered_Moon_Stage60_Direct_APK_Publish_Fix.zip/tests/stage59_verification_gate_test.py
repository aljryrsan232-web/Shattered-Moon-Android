#!/usr/bin/env python3
"""Negative APK integrity gates, run even when Godot/SDK is unavailable."""
from pathlib import Path
import sys, zipfile, tempfile, importlib.util
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('moon_apk',root/'tools/verify_apk.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
cases=[]
def record(name, path):
    try:
        m.verify(path)
        cases.append((name,False))
    except (ValueError,zipfile.BadZipFile):
        cases.append((name,True))
with tempfile.TemporaryDirectory() as d:
    d=Path(d)
    p=d/'not_an_apk.apk';p.write_bytes(b'not a real apk'*100000)
    record('reject arbitrary bytes',p)
    p=d/'renamed_zip.apk'
    with zipfile.ZipFile(p,'w') as z:
        z.writestr('AndroidManifest.xml',b'<manifest>fake</manifest>')
        z.writestr('classes.dex',b'dex\n'+b'X'*1200000)
        z.writestr('resources.arsc',b'x'*24)
    record('reject renamed source zip',p)
    p=d/'missing_game_assets.apk'
    with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_STORED) as z:
        z.writestr('AndroidManifest.xml',b'\x03\x00\x08\x00'+b'a'*32)
        z.writestr('classes.dex',b'dex\n'+b'0'*1024*1024)
        z.writestr('resources.arsc',b'\x02\x00'+b'x'*200)
        z.writestr('lib/arm64-v8a/libgodot_android.so',b'\x7fELF'+b'a'*200)
    record('reject apk missing game content',p)
    p=d/'invalid_native_lib.apk'
    with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_STORED) as z:
        z.writestr('AndroidManifest.xml',b'\x03\x00\x08\x00'+b'a'*32)
        z.writestr('classes.dex',b'dex\n'+b'0'*1024*1024)
        z.writestr('resources.arsc',b'\x02\x00'+b'x'*200)
        z.writestr('lib/arm64-v8a/libgodot_android.so',b'not ELF')
        for i in range(4): z.writestr(f'assets/game{i}.bin',b'data')
    record('reject non-ELF native engine',p)
    # A minimal AArch64 ELF header for the positive *structural-only* case.
    elf=bytearray(64);elf[:6]=b'\x7fELF\x02\x01';elf[18:20]=(183).to_bytes(2,'little')
    p=d/'well_structured_unsigned.apk'
    with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_STORED) as z:
        z.writestr('AndroidManifest.xml',b'\x03\x00\x08\x00'+b'a'*32)
        z.writestr('classes.dex',b'dex\n'+b'0'*1024*1024)
        z.writestr('resources.arsc',b'\x02\x00'+b'x'*200)
        z.writestr('lib/arm64-v8a/libgodot_android.so',bytes(elf)+b'a'*200)
        for i in range(4): z.writestr(f'assets/game{i}.bin',b'data')
    # This passes *structural* checks only, never Android cryptographic signing.
    try:
        result=m.verify(p)
        cases.append(('structural test sample passes, signature unverified',result['signature']=='verify separately'))
    except Exception: cases.append(('structural test sample passes, signature unverified',False))
    (p.parent/(p.name+'.sha256')).unlink(missing_ok=True)
failures=[k for k,v in cases if not v]
for k,v in cases: print(('PASS' if v else 'FAIL')+' '+k)
print(f'STAGE59 APK NEGATIVE-GATE TEST: {len(cases)-len(failures)}/{len(cases)}')
raise SystemExit(1 if failures else 0)
