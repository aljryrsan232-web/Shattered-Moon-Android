#!/usr/bin/env python3
"""Stage 59 pipeline source integrity and simulated-log tests (NOT an actual APK build)."""
from pathlib import Path
import importlib.util, os, subprocess, sys, tempfile, json, struct, re
root=Path(__file__).resolve().parents[1]
w=(root/'.github/workflows/build-android-apk.yml').read_text()
pre=(root/'export_presets.cfg').read_text()
checks=[]
def check(name,value):checks.append((name,bool(value)))
check('workflow and job blocks defined', w.startswith('name: Build Shattered Moon APK - Stage 59') and '\njobs:\n  android:' in w and '\n      - name: Export signed Android debug APK' in w)
check('only manual run creates draft direct download',"github.event_name == 'workflow_dispatch' && inputs.publish_direct_apk" in w and '--draft --prerelease' in w)
check('manual input defaults false','publish_direct_apk' in w and 'default: false' in w)
check('release not created without valid signed apk', w.index('name: Export signed Android debug APK')<w.index('name: Draft direct APK download'))
check('Android package identity stable','package/unique_name="org.shatteredmoon.rebuild"' in pre)
check('Android build version updated','version/code=59' in pre and 'version/name="0.59.0"' in pre)
check('app internal name stable', 'config/name="Shattered Moon — Stage 41 — Performance Preflight"' in (root/'project.godot').read_text())
check('arm64 enabled', 'architectures/arm64-v8a=true' in pre)
check('log check imported scene', 'python3 tools/check_engine_log.py build_logs/import.log' in w)
check('log check runtime test', 'python3 tools/check_engine_log.py build_logs/launch_smoke.log' in w)
check('log check export', 'python3 tools/check_engine_log.py build_logs/export.log' in w)
check('success must validate APK', 'python3 tools/verify_apk.py builds/Shattered_Moon_Stage59_Debug.apk' in w and '--print-certs' in w)
check('never upload invalid APK', 'if: success()' in w)
check('no native apk faked', not list(root.rglob('*.apk')))
check('no private signing key shipped',not list(root.rglob('*.keystore')) and not list(root.rglob('*.jks')))
check('required workflow resources exist', (root/'tests/stage59_launch_smoke.gd').is_file() and (root/'tools/check_engine_log.py').is_file())
spec=importlib.util.spec_from_file_location('scan',root/'tools/check_engine_log.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as temp:
    good=Path(temp)/'good.log';good.write_text('Godot Engine 4.4.1\nSceneTree ready\n')
    bad=Path(temp)/'bad.log';bad.write_text('SCRIPT ERROR: Parse Error: Unexpected token\n')
    broken=Path(temp)/'broken.log';broken.write_text('Failed to load resource res://assets/foo.glb\n')
    try:mod.inspect(good);check('normal log accepted',True)
    except Exception:check('normal log accepted',False)
    for name,pth in [('invalid script rejected',bad),('missing asset rejected',broken)]:
        try:mod.inspect(pth);check(name,False)
        except ValueError:check(name,True)
# ensure 100% byte equality for protected gameplay sources against known stage57 baseline supplied by builder
baseline=root/'docs/STAGE58_PROTECTED_BASELINE_SHA256.json'
if baseline.is_file():
    import hashlib
    for relative,digest in json.loads(baseline.read_text()).items():
        check('unchanged '+relative, (root/relative).is_file() and hashlib.sha256((root/relative).read_bytes()).hexdigest()==digest)
fails=[name for name,passed in checks if not passed]
print(json.dumps({'stage':59,'checks':len(checks),'passed':len(checks)-len(fails),'failures':fails,'godot_runtime_tested':False,'apk_built':False},ensure_ascii=False,indent=2))
sys.exit(1 if fails else 0)
