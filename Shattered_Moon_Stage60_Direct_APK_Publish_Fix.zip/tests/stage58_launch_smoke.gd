extends SceneTree
## ACTUAL Godot scene startup smoke test, NOT an offline/static source check.
## Use only in an isolated test profile (CI overrides XDG_DATA_HOME only during this test).
func _initialize() -> void:
    call_deferred("_run")
func _fail(message: String) -> void:
    push_error("STAGE58_RUNTIME_SMOKE_FAIL: " + message)
    quit(1)
func _run() -> void:
    var packed: PackedScene = load("res://Main.tscn") as PackedScene
    if packed == null:
        _fail("Main.tscn failed to load")
        return
    var game: Node3D = packed.instantiate() as Node3D
    if game == null:
        _fail("Main.tscn failed to instantiate")
        return
    root.add_child(game)
    await physics_frame
    await process_frame
    if not is_instance_valid(game.get("player") as Node3D):
        _fail("Player did not initialize")
        return
    if not is_instance_valid(game.get("view_camera") as Camera3D):
        _fail("Camera did not initialize")
        return
    if not is_instance_valid(game.get("rayan_ally") as Node3D):
        _fail("Companion controller did not initialize")
        return
    if not is_instance_valid(game.get("hero_weapon_mount") as Node3D):
        _fail("Hero weapon mount did not initialize")
        return
    game.queue_free()
    await process_frame
    print("STAGE58_LAUNCH_SMOKE: PASS")
    quit(0)
