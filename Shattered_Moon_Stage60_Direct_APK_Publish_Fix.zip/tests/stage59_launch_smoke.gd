extends SceneTree
## ACTUAL Godot scene startup smoke test, NOT an offline/static source check.
## Use only in an isolated test profile (CI overrides XDG_DATA_HOME only during this test).
func _initialize() -> void:
    call_deferred("_run")
func _fail(message: String) -> void:
    push_error("STAGE59_RUNTIME_SMOKE_FAIL: " + message)
    quit(1)
func _run() -> void:
    var packed: PackedScene = load("res://Main.tscn") as PackedScene
    if packed == null:
        _fail("Main.tscn failed to load")
        return
    var game: Node3D = packed.instantiate() as Node3D
    if game == null:
        _fail("Main.tscn failed to instantiate")
        return
    root.add_child(game)
    await physics_frame
    await process_frame
    if not is_instance_valid(game.get("player") as Node3D):
        _fail("Player did not initialize")
        return
    if not is_instance_valid(game.get("view_camera") as Camera3D):
        _fail("Camera did not initialize")
        return
    if not is_instance_valid(game.get("rayan_ally") as Node3D):
        _fail("Companion controller did not initialize")
        return
    if not is_instance_valid(game.get("hero_weapon_mount") as Node3D):
        _fail("Hero weapon mount did not initialize")
        return
    # Exercise actual gameplay input for multiple physics frames, not only scene creation.
    # Keep the test profile isolated from the user's save files.
    if not InputMap.has_action("move_forward"):
        _fail("Movement action was not installed")
        return
    var input_before: Vector3 = game.get("player").global_position
    Input.action_press("move_forward")
    for _frame in range(10):
        await physics_frame
    Input.action_release("move_forward")
    await physics_frame
    var hero: Node3D = game.get("player") as Node3D
    if not is_instance_valid(hero):
        _fail("Hero disappeared during movement simulation")
        return
    if input_before.distance_to(hero.global_position) < 0.015:
        _fail("Hero did not travel during held forward input")
        return
    if not is_instance_valid(game.get("rayan_ally") as Node3D):
        _fail("Rayan disappeared during movement simulation")
        return
    game.queue_free()
    await process_frame
    print("STAGE59_LAUNCH_SMOKE: PASS")
    quit(0)
