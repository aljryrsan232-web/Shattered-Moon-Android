# Shattered Moon — المرحلة 57 — بناء Android

**هذه حزمة مشروع وليست APK.** لم نتمكن من بناء أو اختبار APK في بيئة الإنشاء الحالية لأن Godot وقوالب التصدير وأدوات Android غير متاحة.

## أسرع طريقة لبناء APK

1. فك الضغط وارفع **محتويات** الحزمة إلى جذر مستودع GitHub، بما فيها `.github` المخفي.
2. من تبويب **Actions** شغّل `Build Shattered Moon APK - Stage 57`.
3. إذا نجحت المهمة، نزّل `Shattered-Moon-Android-APK` من **Artifacts**، ثم فك الحزمة للحصول على `Shattered_Moon_Stage57_Debug.apk`.
4. ثبّت APK على جهازك. إذا كان هناك إصدار سابق ورفض Android التحديث بسبب اختلاف توقيع التطبيق، فلا تحذف الإصدار القديم قبل نسخ بياناتك احتياطيًا.

## مهم جدًا للحفظ وتحديث النسخ

عند عدم ضبط السر `MOON_ANDROID_KEYSTORE_B64` ستنشئ المهمة مفتاحًا تجريبيًا **جديدًا في كل عملية بناء**، وقد يرفض الهاتف تحديث نسخة سابقة بها تقدم محفوظ. للحفاظ على التوقيع بين الإصدارات:

- أنشئ **مرة واحدة** ملف `debug.keystore` على جهاز موثوق (لا تضعه في المستودع):

  `keytool -genkeypair -noprompt -keystore debug.keystore -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US"`

- حوّل محتواه إلى Base64 (Linux/macOS): `base64 -w0 debug.keystore` (على macOS: `base64 < debug.keystore | tr -d '\n'`).
- خزّن النتيجة في **Settings → Secrets and variables → Actions → New repository secret** باسم `MOON_ANDROID_KEYSTORE_B64`.
- احتفظ بمفتاح التوقيع الأصلي في مكان آمن؛ إذا ضاع لن تستطيع إصدار تحديث على النسخة المثبتة بنفس الهوية دون إعادة التثبيت.

هذا **مفتاح اختبار فقط** وليس توقيع إنتاج أو توزيع متجر. لا تنشر مفتاح التوقيع أو محتوياته في ملفات المشروع.

## فحوص يمكن تنفيذها محليًا

`python3 tools/preflight.py`

`python3 tests/stage57_pipeline_check.py`

اختبار المشهد الرئيسي وبناء APK والتحقق من توقيعه وتشغيل اللعبة نفسها تتم فقط عند تشغيل مهمة البناء على نظام مزود بالأدوات اللازمة. لم يحدث ذلك هنا.
