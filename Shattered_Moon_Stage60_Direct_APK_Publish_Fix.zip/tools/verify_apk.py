#!/usr/bin/env python3
"""Check exported APK structure; Android SDK apksigner performs actual signature validation."""
from pathlib import Path
from zipfile import ZipFile, BadZipFile
import hashlib, sys, json

def verify(path):
    path = Path(path)
    if path.suffix.lower() != '.apk' or not path.is_file() or path.stat().st_size < 1024*1024:
        raise ValueError('No APK or output suspiciously small')
    try:
        with ZipFile(path) as zip_file:
            corrupted = zip_file.testzip()
            if corrupted: raise ValueError('Damaged APK entry: '+corrupted)
            names = set(zip_file.namelist())
            needed = {'AndroidManifest.xml','classes.dex','resources.arsc'}
            if not needed.issubset(names): raise ValueError('Missing Android components: '+str(needed-names))
            # Android APK internals must be compiled, not arbitrary ZIP files.
            if zip_file.read('AndroidManifest.xml')[:4] != b'\x03\x00\x08\x00':
                raise ValueError('Android manifest not binary AXML')
            if zip_file.read('classes.dex')[:4] != b'dex\n':
                raise ValueError('DEX bytecode missing or malformed')
            if zip_file.read('resources.arsc')[:2] != b'\x02\x00':
                raise ValueError('Android resource table missing or malformed')
            engine_libs=[n for n in names if n.startswith('lib/arm64-v8a/') and n.endswith('.so')]
            if not engine_libs:
                raise ValueError('No ARM64 native Godot engine library')
            # ELF class 64, little-endian, e_machine=183 (AArch64).
            def arm64_elf(lib: str) -> bool:
                with zip_file.open(lib) as fd:
                    header=fd.read(20)
                return (len(header)>=20 and header[:6] == b'\x7fELF\x02\x01'
                        and int.from_bytes(header[18:20], 'little') == 183)
            if not any(arm64_elf(lib) for lib in engine_libs):
                raise ValueError('No valid AArch64 ELF library')
            game_assets=[n for n in names if n.startswith('assets/') and not n.endswith('/')]
            if len(game_assets)<3:
                raise ValueError('No exported game asset payload in APK')
    except BadZipFile as exc: raise ValueError('Invalid ZIP/APK') from exc
    with path.open('rb') as f: digest = hashlib.file_digest(f,'sha256').hexdigest()
    (path.parent/(path.name+'.sha256')).write_text(f'{digest}  {path.name}\n',encoding='utf-8')
    return {'file':str(path),'size':path.stat().st_size,'sha256':digest,'structure':'valid','signature':'verify separately','installed':False}

if __name__ == '__main__':
    if len(sys.argv)!=2: sys.exit('Usage: verify_apk.py file.apk')
    try: print(json.dumps(verify(sys.argv[1]),indent=2))
    except Exception as exc: sys.exit('APK CHECK FAILED: '+str(exc))
