#!/usr/bin/env python3
"""Fail the build on Godot's reported script/resource failures, even when CLI exits 0."""
import pathlib, re, sys
ERRORS = [
    re.compile(r'\bSCRIPT ERROR\b', re.I),
    re.compile(r'\bParse Error\b', re.I),
    re.compile(r'\bFailed to (?:load|open|import) (?:the )?(?:script|scene|resource|asset)\b', re.I),
    re.compile(r'\bCannot (?:open|load) resource\b', re.I),
    re.compile(r'\bshader (?:compilation|compile) (?:error|failed)\b', re.I),
    re.compile(r'\bERROR:.*(?:parse|script|load|import|shader|invalid resource)\b', re.I),
]
def inspect(path):
    data=pathlib.Path(path).read_text(encoding='utf-8',errors='replace')
    matches=[(n, line.strip()) for n,line in enumerate(data.splitlines(),1) if any(r.search(line) for r in ERRORS)]
    if matches:
        for n,line in matches[:25]: print(f'GODOT ERROR line {n}: {line}',file=sys.stderr)
        raise ValueError(f'{len(matches)} Godot parse/resource errors in {path}')
    print(f'Godot log gate OK: {path}')
if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('Usage: check_engine_log.py <log>')
    try: inspect(sys.argv[1])
    except Exception as exc: raise SystemExit(str(exc))
