#!/usr/bin/env python3
"""Offline source checks only, NOT Godot runtime validation."""
from pathlib import Path
import json, re, struct
base=Path(__file__).resolve().parents[1]
checks=[]
def check(label, good): checks.append((label,bool(good)))
check('project', (base/'project.godot').is_file())
check('main scene', (base/'Main.tscn').is_file())
check('export preset', (base/'export_presets.cfg').is_file())
for extension in ('*.gd','*.gdshader','*.tscn','*.tres'):
    for source in base.rglob(extension):
        for relative in re.findall(r'res://([^"\n]+)',source.read_text(encoding='utf-8')):
            relative=relative.split('::')[0]
            check(f'{source.relative_to(base)} resource {relative}', (base/relative).is_file())
for glb in (base/'assets').rglob('*.glb'):
    raw=glb.read_bytes()
    check(str(glb.relative_to(base)),len(raw)>20 and raw[:4]==b'glTF' and struct.unpack_from('<I',raw,4)[0]==2 and struct.unpack_from('<I',raw,8)[0]==len(raw))
for icon in ('stage52_launcher_icon.png','stage52_adaptive_foreground.png','stage52_adaptive_background.png'):
    check(icon, (base/'assets/ui'/icon).is_file())
preset=(base/'export_presets.cfg').read_text(encoding='utf-8')
for needle in ['platform="Android"','architectures/arm64-v8a=true','gradle_build/use_gradle_build=false','version/code=60']:
    check(needle, needle in preset)
failures=[label for label, good in checks if not good]
result={'stage':60,'static_checks':len(checks),'passed':len(checks)-len(failures),'failures':failures,
        'godot_runtime_tested':False,'apk_created':False}
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(1 if failures else 0)
