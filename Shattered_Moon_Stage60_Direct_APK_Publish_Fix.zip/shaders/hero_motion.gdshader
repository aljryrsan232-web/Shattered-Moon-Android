shader_type spatial;
render_mode cull_disabled, diffuse_burley, specular_schlick_ggx;
// Stage 23: extended-leg adult skeleton proportions in GPU vertex animation.
// COLOR.a encodes immutable body region tags. COLOR.rgb contains actual garment/skin colors.
// No new skeleton nodes or per-vertex CPU updates: 1 surface per actor.
uniform float gait_phase = 0.0;
uniform float locomotion : hint_range(0.0,1.0) = 0.0;
uniform float sprint : hint_range(0.0,1.0) = 0.0;
uniform float strike : hint_range(0.0,1.0) = 0.0;
uniform float combo_side : hint_range(-1.0,1.0) = 1.0;
uniform float dodge : hint_range(0.0,1.0) = 0.0;
uniform float recoil : hint_range(0.0,1.0) = 0.0;
uniform float guard : hint_range(0.0,1.0) = 0.0;
uniform float breathing : hint_range(0.0,1.0) = 0.0;
uniform float motion_time = 0.0;
uniform float turn_lean : hint_range(-1.0,1.0) = 0.0;
// Stage 43: color grading only. Updated at 1Hz, no extra shadow-casting lights.
uniform float night_blend : hint_range(0.0,1.0) = 0.0;
uniform float fabric_detail : hint_range(0.0,1.0) = 0.8;
// Stage 45: selective, bounded hair movement using head vertex color and location.
// Mobile uses a smaller amplitude; no skeleton CPU vertices or simulation particles.
uniform float hair_motion_intensity : hint_range(0.0,1.0) = 1.0;
// Stage 46: limited garment inertia (only cape-tagged vertices: alpha 190/255).
// Upper cape stays attached to shoulders; zero effect on facial vertices.
uniform float cape_motion_intensity : hint_range(0.0,1.0) = 1.0;
float tag(float v,float mark){return 1.0-smoothstep(0.016,0.065,abs(v-mark));}
vec3 pitch_about(vec3 v, vec3 pivot, float a){
  vec3 d=v-pivot; float c=cos(a),s=sin(a);
  return pivot+vec3(d.x,d.y*c-d.z*s,d.y*s+d.z*c);
}
vec3 yaw_about(vec3 v, vec3 pivot, float a){
  vec3 d=v-pivot;float c=cos(a),s=sin(a);
  return pivot+vec3(d.x*c+d.z*s,d.y,-d.x*s+d.z*c);
}
float ease_in_out(float x){return x*x*(3.0-2.0*x);}
void vertex(){
  // Smooth blend masks for split-free motion at the shoulder and knee joints.
  float a=COLOR.a;
  float leg_l=tag(a,65.0/255.0),leg_r=tag(a,90.0/255.0);
  float arm_l=tag(a,130.0/255.0),arm_r=tag(a,155.0/255.0);
  float cape=tag(a,190.0/255.0),core=tag(a,30.0/255.0),head=tag(a,235.0/255.0);
  vec3 v=VERTEX;
  float walk=clamp(locomotion,0.0,1.0);
  float run=clamp(sprint,0.0,1.0)*walk;
  float wave=sin(gait_phase),opp=sin(gait_phase+3.14159265);
  float hip_swing=(.29+.13*run)*walk;
  // Avoid costly trig/matrix work on face, torso and cape vertices.
  // Each authored triangle belongs to exactly one animated region.
  if(leg_l>0.5 || leg_r>0.5){
    float side=(leg_l>0.5)?-1.0:1.0;
    float step_wave=(leg_l>0.5)?wave:opp;
    vec3 hip=vec3(side*.27,1.64,.02);
    v=pitch_about(v,hip,(.29+.13*run)*walk*step_wave);
    float below_knee=1.0-smoothstep(.84,1.18,VERTEX.y);
    float lift=max(0.0,step_wave);
    float knee_bend=(.17+.23*run)*lift*walk;
    vec3 knee=vec3(side*.28,.90,.03);
    vec3 folded=pitch_about(v,knee,knee_bend);
    v=mix(v,folded,below_knee);
    v.y+=below_knee*.025*walk*lift;
  }
  // Spine turns with the strike but face keeps a stable direction during walking.
  float chest=core*smoothstep(1.96,2.23,VERTEX.y)*(1.0-smoothstep(2.77,3.04,VERTEX.y));
  float attack_arc=sin(strike*3.14159265);
  v=mix(v,yaw_about(v,vec3(0.0,2.08,0.0),.27*attack_arc*combo_side-.09*guard),chest);
  v.z+=core*smoothstep(2.02,2.25,VERTEX.y)*(1.0-smoothstep(2.70,3.04,VERTEX.y))*.010*breathing;
  v.x+=core*smoothstep(1.30,2.42,VERTEX.y)*.060*turn_lean*walk;
  // Two shoulder/forearm transformations only for arm vertices.
  if(arm_l>0.5 || arm_r>0.5){
    float side=(arm_l>0.5)?-1.0:1.0;
    float swing=(-.18-.10*run)*walk*side*wave;
    swing+=(arm_r>0.5)?(-.55*attack_arc-.85*guard):(-.23*attack_arc-.53*guard);
    vec3 shoulder=vec3(side*.68,2.70,.01);
    v=pitch_about(v,shoulder,swing);
    float forearm=1.0-smoothstep(1.90,2.32,VERTEX.y);
    vec3 elbow=vec3(side*.86,2.24,.09);
    float bend=.09+.26*run*walk+.39*attack_arc*((arm_r>0.5)?1.0:.25);
    vec3 bent=pitch_about(v,elbow,-bend);
    v=mix(v,bent,forearm);
  }
  // Small head turns and nods add life without sacrificing the human proportions.
  if(head>0.5){
    vec3 neck=vec3(0.0,2.96,0.01);
    vec3 head_turn=yaw_about(v,neck,.036*sin(motion_time*.77)+.027*strike*combo_side);
    v=pitch_about(head_turn,neck,.023*sin(motion_time*1.15)-.035*recoil);
    v.x+=.023*turn_lean*walk;
    // Side/back hair tips sway independently; scalp, skin and central facial features stay rigid.
    // Character heads occupy x ~= [-.34,.34], y ~= [2.98,3.62] in the authored GLBs.
    float dark_pigment=1.0-smoothstep(.35,.57,COLOR.r);
    float side_strand=smoothstep(.13,.23,abs(VERTEX.x));
    float strand_tip=smoothstep(3.18,3.28,VERTEX.y)*(1.0-smoothstep(3.40,3.54,VERTEX.y));
    float strand_mask=dark_pigment*side_strand*strand_tip;
    float run_sway=.018*walk*sin(gait_phase*.82 + VERTEX.y*4.0);
    float breeze=.010*sin(motion_time*2.6 + VERTEX.x*11.0 + VERTEX.y*5.0);
    v.x+=strand_mask*hair_motion_intensity*(breeze+run_sway+.012*turn_lean*walk);
    v.z-=strand_mask*hair_motion_intensity*(.010*walk+.010*run+.008*sin(motion_time*2.1+VERTEX.x*8.0));
  }
  // Stage 46: cape inertia follows gait, turn, dodge, blade swing and parry.
  // Vertex alpha tag isolates cloak geometry; top vertices are anchored.
  float cape_end=1.0-smoothstep(1.60,2.74,VERTEX.y);
  if(cape>0.5){
    float cape_weight=cape_end*cape_motion_intensity;
    float wind=.024*sin(motion_time*2.5+VERTEX.y*1.3);
    float side_sway=.052*walk*sin(gait_phase*.62)+.037*turn_lean*walk;
    float strike_pull=.022*attack_arc*combo_side+.012*recoil*combo_side;
    v.x+=cape_weight*(wind+side_sway+strike_pull);
    // Stage 47: nudge the lower right-hand cape hem away from a drawn sword.
    // Small, bounded visual clearance only, not a true cloth collision solver.
    float right_hem=smoothstep(0.05,0.31,VERTEX.x);
    float sword_clearance=cape_weight*right_hem*(.026*attack_arc+.019*guard);
    v.x-=sword_clearance;
    float back_sweep=.028+.075*walk+.050*run+.042*attack_arc+.026*guard+.075*dodge;
    v.z-=cape_weight*(back_sweep+.015*sin(motion_time*2.3+VERTEX.y));
    v.y+=cape_weight*(.018*run*sin(gait_phase+.4)-.025*dodge+.016*recoil);
  }
  // Short dodge crouch and recoil; bounded so boots never fall through terrain.
  float upper=smoothstep(.77,2.18,VERTEX.y);
  v.y-=.095*dodge*upper+.045*guard*upper;
  v.z+=upper*(.12*dodge-.065*recoil);
  v.x+=upper*.055*dodge*combo_side;
  VERTEX=v;
}
// Stage 24: subtle material response (skin, fabric, leather, polished highlights)
// based on the original vertex palette; no texture lookup required on low-end devices.
float grain(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
void fragment(){
  vec3 col=COLOR.rgb;
  float skin=step(.07,col.r-col.g)*step(.045,col.g-col.b)*step(.48,col.r)*step(.30,col.g);
  float fibers=sin(VERTEX.x*170.0)*sin(VERTEX.y*150.0);
  float pores=grain(floor(VERTEX*350.0));
  // Keep the existing per-vertex palette; do not alter COLOR.a motion region tags.
  // Stage 44: small hair-fiber variation only in darker head-region colors.
  // Head rig mask remains untouched; this affects shading, not animations.
  float head_region = tag(COLOR.a,235.0/255.0);
  float dark_hair = 1.0-smoothstep(.29,.55,col.r);
  float hair_mask = head_region * dark_hair;
  float hair_fibers = sin(VERTEX.y*123.0 + VERTEX.x*58.0)*sin(VERTEX.z*91.0);
  col *= 1.0 + .025 * hair_mask * hair_fibers;
  // Faint woven response on the cape, without adding texture fetches.
  float cape_fabric=tag(COLOR.a,190.0/255.0);
  float garment_weave=sin(VERTEX.y*109.0+VERTEX.z*13.0)*sin(VERTEX.x*126.0);
  col*=1.0+.018*cape_fabric*garment_weave*fabric_detail;
  float cloth = 1.0-skin;
  float yarn = .024*fibers*cloth*fabric_detail;
  float complexion = .020*(pores-.5)*skin;
  col*=1.0+yarn+complexion;
  ALBEDO=col;
  float hardware=step(.55,col.r)*step(.49,col.g)*step(.42,col.b)*(1.0-skin);
  METALLIC=.015+hardware*.32;
  // Restrained sheen on darker hair; metals and skin retain their prior response.
  ROUGHNESS=mix(clamp(mix(.80,.89,skin)-hardware*.22+.025*cloth*fabric_detail,.44,.94),.72,hair_mask*.60);
  SPECULAR=mix(mix(.23,.35,hardware),.40,hair_mask*.55);
  // Mild view-dependent night edge light; readable silhouettes without adding lights.
  float edge=pow(1.0-clamp(dot(normalize(NORMAL),normalize(VIEW)),0.0,1.0),2.8);
  vec3 edge_tint=mix(vec3(.15,.18,.22),vec3(.21,.33,.54),night_blend);
  EMISSION=vec3(.024,.050,.09)*guard + edge*edge_tint*(.035+.21*night_blend);
}
