shader_type spatial;
render_mode unshaded, blend_add, depth_draw_never, cull_disabled, shadows_disabled;

void vertex() {
    // One GPU batch: independent drifting and flicker using instance custom seeds.
    float seed = INSTANCE_CUSTOM.r * 6.28318;
    VERTEX.x += sin(TIME * 0.83 + seed) * 0.42;
    VERTEX.y += sin(TIME * 1.23 + seed * 1.8) * 0.24;
    VERTEX.z += cos(TIME * 0.71 + seed * 2.2) * 0.33;
    // Camera-facing sprite without a CPU billboard node for each insect.
    MODELVIEW_MATRIX = VIEW_MATRIX * mat4(INV_VIEW_MATRIX[0], INV_VIEW_MATRIX[1], INV_VIEW_MATRIX[2], MODEL_MATRIX[3]);
}

void fragment() {
    float radius = length(UV - vec2(0.5));
    float halo = 1.0 - smoothstep(0.04, 0.49, radius);
    float flicker = 0.68 + 0.32 * sin(TIME * 3.1 + INSTANCE_CUSTOM.g * 12.0);
    ALBEDO = vec3(1.0, 0.83, 0.32);
    EMISSION = vec3(1.0, 0.70, 0.18) * 2.0;
    ALPHA = halo * flicker * INSTANCE_CUSTOM.b * 0.60;
}
