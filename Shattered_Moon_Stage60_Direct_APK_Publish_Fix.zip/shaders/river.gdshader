shader_type spatial;
render_mode blend_mix, depth_draw_never, cull_disabled;

// One inexpensive water surface — no screen-space reflection or refraction passes.
uniform vec4 deep_color : source_color = vec4(0.075, 0.30, 0.39, 0.89);
uniform vec4 glint_color : source_color = vec4(0.39, 0.76, 0.82, 1.0);
uniform float wave_speed : hint_range(0.0,3.0) = 0.8;

void vertex() {
    VERTEX.y += 0.045*sin(VERTEX.x*0.8 + TIME*wave_speed)*cos(VERTEX.z*1.1 - TIME*0.7);
}
void fragment() {
    float flow = sin(UV.x * 64.0 + TIME * wave_speed * 3.4 + sin(UV.y*22.0));
    float ripples = sin(UV.y*47.0 - TIME*2.6);
    float crest = smoothstep(0.78, 0.95, flow*.5 + ripples*.5 + .5);
    ALBEDO = mix(deep_color.rgb, glint_color.rgb, crest*0.38);
    ROUGHNESS = 0.19;
    METALLIC = 0.06;
    EMISSION = glint_color.rgb * crest * 0.1;
    ALPHA = deep_color.a;
}
