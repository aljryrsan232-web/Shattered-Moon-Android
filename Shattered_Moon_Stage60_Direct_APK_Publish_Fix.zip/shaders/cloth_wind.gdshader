shader_type spatial;
render_mode cull_disabled, diffuse_burley;
uniform vec4 cloth_tint : source_color = vec4(0.54,0.20,0.20,1.0);
uniform float wind_strength : hint_range(0.0,0.20) = 0.09;
void vertex() {
    // Godot PlaneMesh lies in XZ. Its lower part moves less than the top edge.
    float height_mask = smoothstep(-0.65,0.65,VERTEX.z);
    VERTEX.y += sin(TIME*1.45 + VERTEX.z*4.5 + VERTEX.x*1.7) * wind_strength * (0.18+height_mask*0.82);
}
void fragment() {
    ALBEDO = cloth_tint.rgb;
    ROUGHNESS = 0.93;
}
