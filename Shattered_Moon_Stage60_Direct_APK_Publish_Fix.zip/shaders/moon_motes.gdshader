shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;

// GPU-only gentle drift for instanced moon dust. No animation loops on CPU.
void vertex() {
    float phase = INSTANCE_CUSTOM.r * 6.2831853;
    VERTEX.x += sin(TIME * 0.47 + phase) * 0.53;
    VERTEX.y += sin(TIME * 0.82 + phase * 1.7) * 0.28;
    VERTEX.z += cos(TIME * 0.36 + phase * 1.4) * 0.37;
}
void fragment() {
    float twinkle = 0.66 + 0.34 * sin(TIME * 2.7 + INSTANCE_CUSTOM.g * 11.0);
    ALBEDO = vec3(0.35, 0.69, 0.95);
    EMISSION = ALBEDO * (0.75 + twinkle * 1.15);
    ALPHA = INSTANCE_CUSTOM.a * twinkle * 0.74;
}
