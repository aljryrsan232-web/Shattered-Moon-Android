shader_type spatial;
render_mode diffuse_burley;
// Reuse mesh vertex colors — no additional texture reads or shadow-casting lights.
void fragment() {
    vec3 tint = COLOR.rgb;
    ALBEDO = tint;
    float lunar_glow = smoothstep(0.10, 0.46, tint.b - tint.r);
    EMISSION = tint * lunar_glow * 1.15;
    METALLIC = 0.16;
    ROUGHNESS = mix(0.73, 0.31, lunar_glow);
}
