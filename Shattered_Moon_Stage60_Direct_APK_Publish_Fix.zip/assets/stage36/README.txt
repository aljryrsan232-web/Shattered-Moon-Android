Stage 36 original coloured-vertex GLB accessories. Model-space positions align to Stage 35 characters, head/torso only. No external image textures, no skin rig. Runtime adjustment may be needed.
